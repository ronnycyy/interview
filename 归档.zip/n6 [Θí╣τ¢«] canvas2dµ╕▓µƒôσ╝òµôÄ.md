# canvas2D渲染引擎
该项目是一个公司级别的 canvas 2D 渲染引擎库，用于支持公司的各种网页设计器, 项目提供了快速拾取、交互式图形对象、事件系统、平移缩放等功能。

# f项目时间 f开发时间 f时间
2021.06～2021.12  [6个月:1个月设计,4个月开发,1个月测试]

# f技术选型
Canvas + Typescript

# f团队配置
5 人前端团队:
1. 陈继航: 负责人，技术选型、项目架构搭建、人员安排
2. 陈允翼: 拾取、事件系统、封装图形类。
3. 廖鹏: 平移、缩放、旋转等动态效果。
4. 张勇: 序列化、反序列化、图片格式支持。
5. 孙奇: 图形类 draw 方法调研。

# f项目背景
1. 公司有会场设计、屏幕设计、门禁设计等一系列 2D 图形设计需求，而网上的渲染引擎不满足我们对渲染引擎的要求，所以我们自己做了一个。
2. 满足公司定制化的需求 (会议特制图形、硬件特定格式)
3. 经过实践，在我们的场景下，现有的引擎库性能不够好 (比如 Fabric.js 的拾取方案)

# f负责内容
1. 拾取方案的设计与实现 [f负责内容1]
2. 事件系统的设计与实现 [f负责内容2]
3. 封装矩形、三角形、圆形等基础交互式图形类 [f负责内容3]

# f项目亮点
1. 通过双层 canvas 设计，提供时间复杂度 O(1)的拾取功能。 [f项目亮点1]
2. 基于双向链表结构实现事件系统，提供时间复杂度 O(1)的订阅/退订功能。 [f项目亮点2]

# f项目成果
基于本渲染引擎，公司实现了各种网页设计器项目，如会场设计器、屏幕设计器等，服务于北京市人大常委会、政协常委会、联合国日内瓦办事处等国内外会场。

# f负责内容1 f拾取 f项目亮点1
**背景**
1. 我们想实现这样一个功能: 根据用户在 canvas 上点击的位置，获取到绘制的图形对象。
2. 网上有一个库 fabric.js 比较符合我们的需求, 但是我去读了 fabric.js 的源码后发现, 它的拾取方案的时间复杂度是 O(N)。[fFabricJS的拾取方案]
3. 经过团队讨论觉得不太好, 于是我们自己设计了一套拾取方案。 
**做法**
1. 初始化的时候绘制两层canvas，一层`隐藏`(visibility: hidden)，一层`可见`，两层的宽高一致，onMouseDown 事件监听在`可见层`。
2. 绘制图形时，在可见层和隐藏层都绘制一次，两者形状一模一样，但是隐藏图形`填充`满一个随机颜色，建立 Map 映射`随机颜色->图形对象`。
3. 在 onMouseDown 中获取点击位置的 e.clientX, e.clientY, 然后通过 hiddenCtx.getImageData(x,y,1,1).data 取得隐藏层该像素点的颜色。
4. 通过 Map 查到是否有映射的图形:     [f重叠咋办]
  - 如果有，就`拾取`到了这个图形。
  - 如果没有，就代表该点没有图形, 返回 null。
**时间复杂度**
1. 通过鼠标点击的位置，获取颜色 getImageData O(1)
2. 通过 Map 从颜色值获取图形 O(1)

# fFabricJS的拾取方案
1. 获取鼠标点击的位置 (x,y)。
2. 遍历所有图形: 判断点击的这个位置是否在某一个图形中，用的是`点射线法`。[https://juejin.cn/post/6844903834179878925]
3. 如果有，返回该图形，如果没有，返回 null。
**点是否在图形中** [f点射线法]
沿着该点的 x 轴作一条射线，检查该射线和图形的边的相交点数:
  如果是奇数: 点在射线内;
  如果是偶数: 点不在图形内;
**时间复杂度** 
1. 首先`遍历`这一步就要 O(N) 了。
2. 然后判断`点是否在图形中`这一步，需要找到图形的边, 然后找射线和边的交点，这些又要增加常数时间。


# 拾取的时候, 如果 2 个图形重叠到一起, 选中的是哪个?  f重叠咋办
1. 重叠的话, 选中的是上面的图形。
2. 因为选中的图形对象是以隐藏层的颜色为准的, 绘制的时候后绘制的颜色在`隐藏层`里会盖上之前绘制的, 所以选中的是后绘制的图形, 也就是上面的图形。


# 获取上下文 fctx
```js
const canvas = document.querySelector('canvas');
const context = canvas.getContext('2d');
```

# CanvasRenderingContext2D的API  fapi
1. ctx.save        保存当前 canvas 状态并放在栈的最上面。 [fsave]
2. ctx.restore     依次从栈上方弹出存储的 canvas 状态。 [frestore]
3. ctx.fillStyle   给 canvas 的各种图形填充颜色, 默认颜色是黑色。
4. ctx.fillRect    (x,y,w,h) 画一个填充满 fillStyle 颜色的矩形。
5. ctx.arc         (x,y,radius,startAngle,endAngle)  用来绘制圆弧。由于圆本质上就是个封闭圆弧，因此，此方法也可以用来绘制正圆。
6. ctx.moveTo      (x,y) 定义路径绘制的起始点。
7. ctx.lineTo      绘制直线以连接当前最后的子路径点和 lineTo 指定的点。
8. ctx.stroke      对路径进行描边。
9. ctx.beginPath   开始一个新的路径, 和之前绘制的路径分开。

# fmoveTo
**举例子**
1. 绘制直线一条。
```js
ctx.beginPath();
ctx.moveTo(50, 20);
ctx.lineTo(200, 100);
ctx.stroke();
```

# fsave 和 frestore
**讲概念**
1. ctx.save     保存当前 canvas 状态并放在栈的最上面。
2. ctx.restore  依次从堆栈上方弹出存储的 canvas 状态。
**举例子**
1. 设置 ctx.fillStyle = 'red' 为红色。
2. 通过 ctx.save() 保存状态。
3. 设置填充颜色 ctx.fillStyle = 'blue' 为蓝色。
4. 再 ctx.fillRect(0,0,100,100) 画一个填充满颜色的矩形, 这个矩形就是蓝色的。
5. 🔥这时候, 通过 ctx.restore() 从栈里弹出上次的状态覆盖当前状态, 那么这时的 ctx.fillStyle 就是上次的红色了。
6. 再次 ctx.fillRect(200,200,100,100) 画一个矩形, 这个矩形就是红色的。


# f负责内容2 f项目亮点2 f事件系统 f双向链表
**背景**
渲染引擎需要提供一套事件注册与发布的机制，提供如`鼠标按下`, `鼠标移动`, `选中图形对象`、 `移除图形对象`等事件给开发者使用。
**结构**
```ts
class EventSystem {
  private _map: Map<EVENT_NAME, DoubleList>;  // 事件名称-双向链表(回调函数)
  public emit(eventName: EVENT_NAME, payload: EventPayload): void;  // 发布 - 遍历双向链表
}
class DoubleList {
  public head: Node;
  public tail: Node;
}
export class Node {
  public last: Node | null;
  public next: Node | null;
  private _callback: Function;  // 回调
  public off(): void;  // 退订 - 删除双向链表结点
}
```
**步骤**
1. 在 EventSystem 类中维护一个 Map, key 是事件名称(mouse:down等)，value 是一条双向链表，双向链表上的每个结点都保存了用户注册的回调函数。
2. 当用户在某个事件上注册回调时，通过的 Map 取出事件对应的 listener 链表，把这个回调函数封装成一个结点，加入双向链表，返回一个句柄。
3. 通过这个句柄可以退订，退订的时候通过 x.last -> x.next 把某个结点移出链表即可。
4. 当发布事件时，只需要通过 Map，以该事件为 key, 找到 value 这条链表，遍历链表执行所有的回调函数即可。
这个结构中，订阅、退订都只需要操作双向链表断开结点、链接结点，时间复杂度 O(1)。
**事件**
mouse:down
mouse:up
mouse:move
object:selected
object:moving
object:scaling
**何时触发事件**
这个要看是什么事件，比如`选中图形对象`这个事件，首先是在`可见层canvas`监听的 mousedown 事件触发，执行回调，然后通过拾取方案检查是否获取了图形，如果获取了，就调用事件系统的 emit 方法，传入一个字符串`object:selected` 代表有图形被选中这个事件，然后遍历双向链表来发布事件。


# f负责内容3 f封装图形类
**背景**
渲染引擎提供一些开箱即用的交互式图形类，比如 矩形、圆形、三角形等。
**用法**
```ts
const circle = new Circle({ radius: 20 });
canvas.add(circle);
circle.on('selected', () => console.log('我被选中了'));
circle.set('left', 10);
circle.get('radius');  // 20
```
**结构**
```ts
export class Circle extends TD_Object {
  constructor(options: ICircleOptions): void;  // 整合用户配置+默认配置
  public render(ctx: CanvasRenderingContext2D, hiddenCtx: CanvasRenderingContext2D): void; // 绘制上下两层canvas
  public drawControls(ctx: CanvasRenderingContext2D, hiddenCtx: CanvasRenderingContext2D): void; // 绘制控制点
  public on(eventName: EVENT_NAME, callback: Function): void;  // 注册事件
  public emitEvent(eventName: EVENT_NAME, payload: EventPayload): void;  // 发布事件
  private _draw(ctx: CanvasRenderingContext2D): void; // 每个图形都要实现的核心绘制逻辑
}
```
**绘制步骤**
1. 整合配置，用户配置+默认配置，比如圆形的默认半径，圆心位置等。
2. 获取自身在隐藏层的随机颜色，然后上下两层 canvas 都绘制，常用的 API 是 ctx.save, beginPath, bezierCurveTo, closePath, restore 等。
**事件机制**
1. 通过事件系统提供事件机制, 每个对象都有一个 _eventSystem 的引用，用于提供事件机制。比如 circle.on('selected', fn), 图形可以知道自己是否被选中了。
**API**
render
drawControls
get
set
on
emit


# f功能
1. 提供交互式图形对象。
2. 通过鼠标对图形对象进行平移、放缩、旋转。
3. 高效的事件机制。
4. 序列化/反序列化。

# f打包
通过 rollup 打包，主要使用的功能是 Tree Shaking 以及通过插件支持 TypeScript。
```js
export default {
  input: ['./src/index.ts'],
  output: [
    {
      file: './dist/tdEngine.js',
      name: 'tdEngine',
      format: 'iife',
      exports: 'default'
    },
    {
      file: './dist/tdEngine.min.js',
      name: 'tdEngine',
      format: 'iife',
      plugins: [terser()],
      exports: 'default'
    }
  ],
  plugins: [
    json(),
    ts({})
  ]
};
```

# f体积 f打出来的包有多大
td-engine.js: 1MB
td-engine.min.js: 312KB
