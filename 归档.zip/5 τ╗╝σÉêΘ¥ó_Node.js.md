# Node.js
**讲概念**
Node.js 是一个基于 Chrome v8 引擎的 JavaScript 运行时环境，同时结合 libuv 扩展了 JavaScript 的功能。它使得 JavaScript 具有了后端语言才有的 I/O, 文件读写, 操作数据库的能力。

# node-gyp
gyp 的含义是 generate your project

node-gyp install 下载 Node.js 头文件
node-gyp configure 针对某个 C++ 项目生成 构建配置 (Makefile)
node-gyp build 将 C++ 代码编译成二进制文件 (xx.node)
node-gyp clean 清理掉 Release 目录
node-gyp rebuild 等于 clean + configure + build

# 为什么要写C++模块
C++ 比 JavaScript 解释器高效。在 JavaScript 解释器中执行 JS 代码的效率，通常比直接执行一个 C++ 编译好的二进制文件要低。

# 为什么 require 不用写后缀
Node.js 运行时会一次枚举后缀名进行寻径，其中就包含后缀名为 .node 的模块，这是一个 C++ 模块的二进制文件。

# C++ 模块本质
一个编译好的 C++模块，以 *.node 为扩展名，其实就是一个系统的动态链接库，相当于 windows 下的 *.dll。
在 Node.js 中引入一个 C++ 模块的过程，实际上就是 Node.js 在运行时引入了一个动态链接库的过程。
运行时接受 JavaScript 代码中的调用，解析出来具体是扩展中的哪个函数需要被调用，在调用完获得结果之后，再通过运行时返回给 JavaScript 代码。

# C++原生 vs C++扩展
调用 Node.js 的原生 C++ 函数和调用 C++ 扩展函数的区别就在于，前者的代码会直接编译进 Node.js 可执行文件中，而后者的代码则位于一个动态链接库中。

# Node.js模块加载原理
## 用户源码模块
Node.js 用户源码模块载入流程:
1. 开发者调用 require() 这在某种意义上等同于调用 Module._load
2. 闭包化对应文件的源码，并传入相关参数执行（若有缓存，则直接返回）
3. 通常在执行过程中 module.exports 或者 exports 会被赋值
4. Module.prototype._load 在最后返回这个模块的 exports 给上游

*用户调用`require`的步骤 Module._load: *
1. 生成文件路径
2. 从 Module._cache 中检查是否有缓存:
   2.1 有缓存，直接返回 cacheModule.exports
   2.2 无缓存，检查是否是内置模块:
     2.2.1 是内置模块，返回 NativeModule.require(filename) 的调用结果
     2.2.2 非内置模块，调用 new Module(..) 实例化一个模块，标记是否入口模块，存入缓存 Module._cache[filename] = module,
           尝试加载模块(调用tryModuleLoaded()，本质还是执行 module.load)，返回 module.exports, 也就是用户写的 module.exports = xxx。

*闭包化源码*
```js
(function(exports, require, module, __filename, __dirname) {
   // `用户源码`
   // 这里的 require 就是经包装后的 Module.prototype.require, 在某种意义上等同于调用 Module._load。
   const a = require('./a');
   // 这里的 module 是 Module 类的对象实例，所以对 module.exports 赋值实际上是对这个传入的 module 对象赋值。
  module.exports = { id: 1, name: 'v8' };
});
```

## Node.js 内置模块， 如 fs
1. C++ 层初始化 (位于 src/node.cc 的 Start 函数)
2. 逐层深入 Start, 最后 node::LoadEnvironment 载入 bootstrap_node.js 的入口函数 (~/lib/internal/bootstrap_node.js)
3. 传入 process 对象执行 bootstrap_node.js 函数
4. 传给 bootstrap_node.js 的是 env->process_object(), 也就是 process 对象，这个 process 对象就是我们常用的 process 对象。

**源码 传递 process 对象给 bootstrap_node.js**
```c++
// src/node.cc::Start -> .. -> LoadEnvironment
Local<Value> arg = env->process_object();
f->Call(Null(env->isolate()), 1, &arg);
```