# fwebpack生命周期 f工作流程 f构建流程
1. 读取`配置文件`, 合并`默认配置`, 得到`合并配置`。 [f初始化阶段]
2. 用`合并配置`新建 Compiler 对象, 遍历`配置`中的所有插件，执行 apply 方法注册事件回调。
3. 调用 compiler.compile 开始构建。 [f构建阶段]
4. 在 beforeCompile 事件触发时创建 compilation 对象, 然后发布 make 事件。
5. 内置的 EntryPlugin 注册了 make 事件回调，此时触发, 调用 compilation.addEntry 创建入口模块。
6. make 事件完毕后, 发布 finishMake 事件, 执行 compilation.seal 函数，开始封装 Chunk，生成产物。[f生成阶段]
7. seal 函数结束后，触发 afterCompile 钩子，开始执行收尾逻辑。

# f初始化阶段
1. 首先将 `process.args参数`(命令行参数) 与 `webpack.config.js` 文件合并成用户配置;
2. 调用 validateSchema 校验配置对象（validateSchema 底层依赖于 schema-utils 库）;
3. 调用 getNormalizedWebpackOptions + applyWebpackOptionsBaseDefaults 合并出最终配置;
4. 调用 createCompiler 函数创建 compiler 对象。
5. 遍历 配置中的 plugins 集合，执行插件的 apply 方法注册钩子事件回调。
6. 调用 new WebpackOptionsApply().process 方法，根据`配置`动态注入相应插件，包括:
   - 注入 EntryOptionPlugin 插件，该插件根据 entry 值注入 DynamicEntryPlugin 或 EntryPlugin 插件;
   - 根据 devtool 值注入 Sourcemap 插件，包括：SourceMapDevToolPlugin、EvalSourceMapDevToolPlugin 、EvalDevToolModulePlugin;
   - 注入 RuntimePlugin, 用于根据代码内容动态注入 webpack 运行时。
7. 最后，调用 compiler.compile 方法，进入「构建阶段」。

**compile搭建起webpack工作流程**
虽然 compile 方法并没有任何实质的功能逻辑，但它搭建起了后续构建流程框架:
1. 调用 newCompilation 方法创建 compilation 对象;
2. 发布 make 钩子事件。
3. 插件 EntryPlugin 在 make 这个钩子事件中调用 compilation 对象的 addEntry 方法创建入口模块，进入「构建阶段」;
4. make 执行完毕后，发布 finishMake 钩子事件;
5. 执行 compilation.seal 函数，进入「生成阶段」，开始封装 Chunk，生成产物;
6. seal 函数结束后，触发 afterCompile 钩子，执行收尾逻辑。
```js
// webpack/lib/compiler.js 
class Compiler {
  // ...
  compile(callback) {
    const params = this.newCompilationParams();
    this.hooks.beforeCompile.callAsync(params, err => {
      // ...
      const compilation = this.newCompilation(params);
      this.hooks.make.callAsync(compilation, err => {
        // ...
        this.hooks.finishMake.callAsync(compilation, err => {
          // ...
          process.nextTick(() => {
            compilation.finish(err => {
              // ...
              compilation.seal(err => {
                // ...
                this.hooks.afterCompile.callAsync(compilation, err => {
                    if (err) return callback(err);
                    return callback(null, compilation);
                });
              });
            });
          });
        });
      });
    });
  }
}
```


# f构建阶段
**转换过程**
file ... => module => JavaScript文本 => AST => dependences => module => ...
**讲概念**
1. 从 entry 模块开始递归解析模块内容、找出模块依赖，模块依赖再次递归地构建模块。
2. 直到构建出项目整体 module 集合以及 module 之间的 依赖关系图。
3. 这个阶段的主要作用就是读入并理解所有原始代码。
**说步骤**
1. 调用 `handleModuleCreation`，根据文件类型构建 module 子类, 一般是`NormalModule`。
2. 调用 `loader-runner` 转译 module 内容，将各类资源类型转译为 Webpack 能够理解的标准 JavaScript 文本。
3. 调用 `acorn` 将 JavaScript 代码解析为 AST 结构。
4. 在 `JavaScriptParser` 类中遍历 AST，调用 module.addDependency 把这个过程发现的依赖添加到 module 的依赖数组中。
5. 对于 module 新增的依赖，再次调用 `handleModuleCreate`, 控制流回到第一步，递归构建 module 对象。
6. 所有依赖都解析完毕后，构建阶段结束。
**总结**
1. 模块源码会经历 module => ast => dependences => module 的流转。
2. 先将源码解析为 AST 结构，再在 AST 中遍历 import 等模块导入语句，收集模块依赖数组 —— dependences。
3. 遍历 dependences 数组将 Dependency 转换为 Module 对象。
3. 递归处理这些新的 Module，直到所有项目文件处理完毕。


# f生成阶段
**转换过程**
module => chunk => assets✅
**讲概念**
1. `生成阶段`负责根据一系列内置规则，将上一步构建出的所有 Module 对象拆分编排进若干 Chunk 对象中。
2. 以 Chunk 粒度将源码转译为适合在目标环境运行的产物形态，并写出为产物文件。
**说步骤**
1. 在 webpack 的 make 阶段末尾, 调用 compilation.seal 进入生成阶段。
2. 创建本次构建的 ChunkGraph 对象。
3. 遍历 入口集合 compilation.entries:
   - 调用 addChunk 方法为每一个入口 创建 对应的 Chunk 对象 [fInitial_Chunk];
   - 遍历 该入口对应的 Dependency 集合，找到 相应 Module 对象并 关联 到该 Chunk。
4. 到这里可以得到若干 Chunk，之后调用 buildChunkGraph 方法将这些 Chunk 处理成 Graph 结构，方便后续处理。
5. 发布 optimizeModules/optimizeChunks 等钩子事件, 由插件 如[fSplitChunksPlugin] 进一步修剪、优化 Chunk 结构。
6. 一直到最后一个 Optimize 钩子 optimizeChunkModules 执行完毕后，开始调用 compilation.codeGeneration 方法生成 Chunk 代码，
7. 所有 Module 都执行完 codeGeneration，生成模块资产代码后，开始调用 createChunkAssets 函数，为每一个 Chunk 生成资产文件。
8. 调用 compilation.emitAssets 函数“提交”资产文件，注意这里还只是记录资产文件信息，还未写出磁盘文件。
9. 上述所有操作正常完成后，触发 callback 回调，控制流回到 compiler 函数。
10. 最后，调用 compiler 对象的 emitAssets 方法，输出资产文件。
**Seal**
1. `seal`的意思是`密封、上锁`, 在 Webpack 语境下接近于`将模块装进chunk`的意思。
2. `seal`很复杂，重点在于将 Module 按入口组织成多个 Chunk 对象, 之后发布 optimizeXXX 钩子事件, 交由插件根据不同需求对 Chunk 做进一步修剪、整形、优化，最后按 Chunk 为单位做好代码合并与转换，输出为资产文件。
3. `optimizeXXX`钩子常被用于优化最终产物代码，例如`SplitChunksPlugin`就可以在这里分析 Chunk、Module 关系，将使用率较高的 Module 封装进新的 Chunk，实现 Common Chunk 效果。
**总结**
1. 简单理解，Entry 与 Chunk 一一对应，而 Chunk 与最终输出的资源一一对应。


# fTreeShaking f摇树优化
**讲概念**
1. Tree-Shaking 是一种基于 ES Module 规范的 无用代码清除(Dead Code Elimination) 技术。
2. 它会在运行过程中静态分析模块之间的导入导出，确定 ESM 模块中哪些导出值未曾其它模块使用，并将其删除，以此实现打包产物的优化。
**开启TreeShaking**
1. 使用 ESM 规范编写模块代码。
2. 配置 optimization.usedExports 为 true，启动标记功能。
3. 启动代码优化功能，可以通过如下方式的任意一种实现:
  - 配置 mode = production
  - 配置 optimization.minimize = true
  - 提供 optimization.minimizer 数组
**原理**
Webpack 中，Tree-shaking 分为两步:
1. 第一步、先标记出模块导出值中哪些没有被用过。
2. 第二步、使用 Terser或UglifyJS 等 DCE工具 删掉这些没被用到的导出语句。
标记过程大致可划分为三个步骤:
  - Make 阶段，收集模块导出变量并记录到模块依赖关系图 ModuleGraph 变量中。
  - Seal 阶段，遍历 ModuleGraph 标记模块导出变量有没有被使用。
  - 生成产物时，若变量没有被其它模块使用则删除对应的导出语句。
**举例子1. 开启TreeShaking**
例如, 在 webpack.config.js 中:
```js
module.exports = {
  entry: "./src/index",
  mode: "production",
  devtool: false,
  optimization: {
    usedExports: true,
  },
};
```
**举例子2. TreeShaking结果**
```js
{
  // bar 模块
  "./src/bar.js":  ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
    __webpack_require__.d(__webpack_exports__, {
      "bar": () => (/* binding */ bar)
      // 这里就没有导出 foo，因为根本没用到。
      // 后面 Terser 插件的 DCE 功能，会把 const foo = 'foo' 摇掉。
    });
    /* unused harmony export foo */
    const bar = 'bar';
    const foo = 'foo';
  })
}
```


# fES6模块特点 fESM规范
1. 只能作为模块顶层的语句出现。
2. 导入导出的模块名只能是字符串常量。
3. 导入的值是不可变的。
以上三点，决定了 ESM 是完全静态的，跟运行时无关，所以可以在编译时，从代码字面量中就推断出哪些模块值未被使用，这是实现 Tree Shaking 技术的必要条件。
```js
// index.js 主模块
import {bar} from './bar';
console.log(bar);  // 仅使用了 bar, 没有使用 foo
// bar.js 模块
export const bar = 'bar';
export const foo = 'foo';   // foo 未被使用, 会被视作无用代码而删除。
```


# f缓存 fwebpack缓存

1. cache-loader
2. hard-source-webpack-plugin
3. babel-loader
## hard-source-webpack-plugin
模块解析的阶段，用于中间的缓存。
第一次是正常的构建速度，但是会保存缓存数据到 xxx 里。
第二次使用缓存来构建，速度提升。
## babel-loader
运行以后，会增加 node_modules/.cache/babel-loader 这个文件夹，存放缓存的文件
```js
{
  loader: 'babel-loader',
  options: {
    cacheDirectory: true // 开启缓存
  }
}
```

# f热更新🔥 fdevServer
安装 webpack-dev-server, 然后在开发环境下配置:
```js
devServer: {
  contentBase: join(__dirname, '../dist'),
  hot: true,
  port: 3000
}
```
TODO: 原理

# f系统级通知
按下 Ctrl+S, 无需查看 terminal, 系统会通知你成功/失败。只需安装 webpack-build-notifier, 配置插件:
```js
plugins: [
  new WebpackBuildNotifierPlugin({
    title: "My Webpack Project",
    logo: path.resolve("./img/favicon.png"),
    suppressSuccess: true,
  })
]
```


# 常见的 loader
1. raw-loader 将文件导入为字符串。 [fraw-loader]
2. url-loader 将文件作为 data URI 内联到 bundle 中。 [furl-loader]
3. file-loader 将文件发送到输出目录。[ffile-loader]
4. less-loader 将 Less 代码转译为 CSS 代码。 [fless-loader]
5. css-loader 将 CSS 内容包装成`module.exports = "${css}"`的 JavaScript 代码片段。 [fcss-loader]
6. style-loader 在运行时调用`injectStyle`等函数，将`css内容`注入到页面的 style 标签。



# floader
**讲概念**
1. Loader 是 webpack 中用来加载和解析项目资源的`加载器`, 将`资源内容`翻译成 Webpack 能够理解、处理的 JavaScript 代码。
2. Webpack 将⼀切⽂件视为模块，但是 webpack 原⽣只能解析 js ⽂件，如果想将其他⽂件也打包的话，就会⽤到 loader。 
3. 在配置中，通过 module.rules 来配置 loader。
4. 一般来说，webpack 将这个功能交给第三方来完成。
**背景** [f为什么需要loader]
1. 计算机世界中的文件资源格式实在太多, 不可能一一穷举, 于是 webpack 创造了 loader, 将"解析"资源这部分任务开放出去由第三方实现。
2. Loader 为了将文件资源的“读”与“处理”逻辑解耦，Webpack 内部只需实现对标准 JavaScript 代码解析/处理能力，由第三方开发者以 Loader 方式补充对特定资源的解析逻辑。
3. 注意: Webpack5 之后增加了 Parser 对象，事实上已经内置支持图片、JSON 等格式的内容。
**说原理** [floader是怎么实现的]
1. 实现上，Loader 通常是一种 mapping 函数形式，接收原始代码内容，返回翻译结果。(souce => modifySource)
2. 在 Webpack 进入构建阶段后，首先会通过 IO 接口读取文件内容，之后调用 LoaderRunner 并将文件内容以 source 参数形式传递到 Loader 数组。
3. source 数据在 Loader 数组内可能会经过若干次形态转换，最终以标准 JavaScript 代码提交给 Webpack 主流程，以此实现内容翻译功能。
4. 为了避免加载时间过长, webpack默认会缓存 loader 的执行结果直到资源变化, 如果不需要缓存, 可以使用 this.cacheable(false) 声明。
```js
module.exports = function MyLoader(source) {
  // 执行各种代码计算
  return modifySource;
};
```
**函数签名**
Loader 函数接收 3 个参数, 返回 1 个翻译后的 JS 代码, 3  个参数分别为:
1. source: 资源输入。对于第一个执行的`Loader`为资源的内容; 后续执行的`Loader`则为前一个的执行结果, 可能是`字符串/AST对象`。
2. sourceMap?: 可选参数，代码的 sourcemap 结构。
3. data?: 可选参数，其它需要在 Loader 链中传递的信息，比如 posthtml/posthtml-loader 就会通过这个参数传递额外的 AST 对象。
```js
module.exports = function(source, sourceMap?, data?) {
  return source;
};
```
**举例子1. raw-loader**
1. 比如 webpack 团队发布的一个`raw-loader`, 这是一个将`文件内容`转译成`JS字符串`的 loader。
2. 本质上就是将文本内容包裹成 JavaScript 模块, 如文本内容: `I am Ronny`, 转译后就是`module.exports = "I am 范文杰"`。
```js
function rawLoader(source) {
  const json =  JSON.stringify(source)
                    .replace(/\u2028/g, '\\u2028')
                    .replace(/\u2029/g, '\\u2029');
  const esModule = typeof options.esModule !== 'undefined' ? options.esModule : true;
  return `${esModule ? 'export default' : 'module.exports ='} ${json};`;
}
```

**如何配置**
1. 在 module.rules 数组中, 通过一个对象, 对象的 test 声明文件名后缀, use 声明 loader 数组。
```js
module.exports = {
  mode: 'development',
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [
          'style-loader',
          'css-loader',
          'postcss-loader',
        ]
      }
    ]
  }
}
```


# f自定义loader
**如何写一个自定义的Loader?**
1. 准备测试脚本: 先利用`loader-runner`这个库，写一个打印 loader 执行结果的脚本。 [f测试自定义loader]
2. 编写loader: 写一个函数, 接收资源内容, 返回转译结果。[f编写loader] (source => newSource)
3. 编写 loader 的过程, 可以利用 webpack 提供给 loader 的上下文对象接入 webpack 体系, 如: [loader的context] 
   - this.getOptions: 获取 webpack.config.js 中写给 loader 的配置对象。
   - this.async: 返回一个函数, 用来异步返回 loader 的转译结果。
   - this.emitFile: 用于直接写出一个产物文件，例如 file-loader 依赖该接口写出 Chunk 之外的产物。
**f编写loader**
```js
// 以 raw-loader 为例
// 功能: 将文件内容包裹一个 export default，转成 JavaScript 模块。
module.exports = function(source) {
  // 接收 loader 的配置 { use: [{ loader: xx, options: { id:1,name:"loader的配置对象" } }] }
  // option 得到 { id:1,name:"loader的配置对象" }
  const option = this.getOptions();
  // 关掉缓存
  this.cacheable(false);
  // 这个 loader 异步返回转译结果
  const callback = this.async();
  // loader 的转译主逻辑: source 转字符串
  const json = JSON.stringify(source)
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');

  // 封装成 JavaScript 的模块
  const result = `${esModule ? 'export default' : 'module.exports ='} ${json};`;
  // result 返回到 loader-runner 回调的 result。
  // 如果是同步，直接 return result 即可。
  callback(err, result);
}
```
**f测试自定义loader**
```js
const { runLoaders } = require("loader-runner");

runLoaders(
  {
    // 指定资源
    resource: './src/target.txt',
    // 指定 loader
    loaders: [path.resolve(__dirname, './loaders/custom-loader')],
    // 指定读取资源的方式，此处用 fs.readFile 去读取 target.txt 的文件内容
    readResource: fs.readFile.bind(fs)
  },
  (err, result) => {
    if (err) throw errr;
    console.log('loader转译结果:', result);
  }
);
```


# f自定义Plugin f自定义插件
**讲概念**
1. 从形态上看，插件通常是一个带有 apply 函数的类。
**举例子**
```js
class SomePlugin {
  apply(compiler) {
    compiler.hooks.thisCompilation.tap("SomePlugin", (compilation) => {
      compilation.addModule(/* ... */);
    });
  }
}
```

# fPlugin
**讲概念**
1. Plugin 是将逻辑内嵌到 webpack 工作流程的一种机制, 通过插件的形式`可插拔`地嵌入自定义的逻辑。
2. Webpack 内部通过 Tappable 会发布一系列事件，插件在 apply 方法里可以监听这些事件，等事件触发时，在回调里执行自己的逻辑。



# f代码分离 f分离 f分割 f分包
**讲概念**
代码分离是一种方法，把大的 chunk 分离成小的 chunk, 通过缩小后的 chunk 生成体积小的 bundle 文件。
**说用途**
1. 代码分离能够把代码分离到不同的 bundle 中，然后可以按需加载或并行加载这些文件。
2. 代码分离可以用于获取更小的 bundle，以及控制资源加载优先级，如果使用合理，会极大影响加载时间。
**举例子**
1. 把 css 从 入口chunk 中分离出来，如 mini-css-extract-plugin 做的事情，也是一种代码分离。
2. 把 公共库如lodash 从 多个chunk 中分离出来，成为一个共享的 chunk。
**常用的代码分离方法有三种**
1. 入口起点：使用 entry 配置手动地分离代码。
2. 防止重复：使用 Entry dependencies 或者 SplitChunksPlugin 去重和分离 chunk。
3. 动态导入：通过模块的内联函数调用来分离代码。
**利用缓存1**
三方库如 react 或 antd 很少修改，所以通过 optimization.splitChunks.cacheGroups 单独分离出这些库的 bundle, 使得 client 命中缓存。
**利用缓存2**
配置输出的文件名一般通过哈希实现，如`[name].[contenthash].js`, 增加 optimization.moduleIds = 'deterministic' 使得 src 改变后只影响 main 的 hash 而不影响 vendor 的 hash, 从而不改变打包后的 vendor bundle 的文件名, 这样 client 的缓存才能够生效。


# fsplitChunks
optimization.splitChunks 可以将公共的依赖模块提取到一个新生成的 chunk 里，从而分离出公共的 bundle 文件。

# fmodule
module 是我们在项目里用的各种资源，比如 js,css,image,font 等，在 webpack 眼里它们都是模块。

# fasset
**讲概念**
1. asset 是对图像、字体、媒体和任何其他类型文件的统称，通常用于网站和其他应用程序中。
2. 这些文件通常在 output 中最终输出为单独的文件，但也可以通过诸如 style-loader 或 url-loader之类的方法内联。

# fbundle
**讲概念**
1. bundle 由 chunk 组成，包含已经经过加载和编译过程的源文件的最终版本，是最终在浏览器中运行的代码。
2. 通常 chunk 和 bundle 是一一对应的，但是也有例外，比如 1 个`入口chunk`可以分离出 entry.bundle.js 和 entry.bundle.css。
**css in bundle**
```js
o.push([n.id,".hello {\n  color: red;\n}",""]);
```
**image in bundle**
```js
n.exports=r.p+"a8d01b53c94bcb7ea158.jpeg"
```

# fchunk
**讲概念**
1. chunk 是指 webpack 在处理 module 的过程中产生的数据结构，它是 module 的集合。
2. 从一个 entry module 开始寻找它的依赖，并将它们组合在一起成为 chunk。
比如 app.js 依赖 app.css 和 common.js，那么这些模块就都在 webpack 里成为一个 app 的 chunk。
3. 1个`chunk组`可以有多个chunk, 1个chunk可以有多个模块。
**chunk分两种**
1. initial chunk  [fInitial_Chunk]
initial chunk 是入口起点的 main chunk, 会立即加载, 此 chunk 包含入口起点指定的所有模块及其依赖项。
2. non-initial chunk
non-initial chunk 是可以延迟加载的块。可能会出现在使用`动态导入`或者`SplitChunksPlugin`时。
**chunk例子**
```js
// webpack.config.js
module.exports = {
  mode: 'production',
  entry: {
    main: './src/index.jsx',
  },
  output: {
    filename: '[name].[contenthash:8].initial-bundle.js',
    chunkFilename: '[name].[contenthash:8].non-initial-bundle.js',
    path: path.resolve(__dirname, 'dist'),
  },
  optimization: {
    runtimeChunk: {
      name: '__webpack_runtime_🚀_chunk__'
    }
  }
}
// ./src/index.jsx
import React from 'react';
import ReactDOM from 'react-dom';
import('./app.jsx').then((App) => {
  ReactDOM.render(<App />, document.getElementById('root'));
});
```
**生成的chunk**
1. chunk组1: 包含 1 个名为 main 的 initial chunk, 其中包含 index.jsx, react, react-dom 这些模块。
2. chunk组2: 包含 1 个名为 app 的 non-initial chunk, 包含 app.jsx 模块。
**生成的bundle**
1. main 这个 chunk组 成为一个 bundle ---- `main.bundle.js`。
2. non-initial 的 chunk 会单独成为一个 bundle ---- `app.bundle.js`。
3. optimization.untimeChunk 将 webpack 的运行时 chunk 分离出来，所以多了一个 `__webpack_runtime_🚀_chunk__.bundle.js`。


# fHMR
**讲概念**
模块热替换(Hot Module Replacement) 功能会在应用程序运行过程中，替换、添加或删除 模块，而无需重新加载整个页面。
**说用途**
保存源码后立即在浏览器看到效果，无需刷新浏览器，这样显著地提升开发效率。
**说原理**
1. 保留在完全重新加载页面期间丢失的应用程序状态。
2. 只更新变更内容，以节省宝贵的开发时间。
3. 在源代码中 CSS/JS 产生修改时，会立刻在浏览器中进行更新，这几乎相当于在浏览器 devtools 直接更改样式。

# fsourceMap
**讲概念**
sourceMap 是从 bundle 映射回源码的一种机制。
**说用途**
sourceMap 可以很方便地追踪到源码的 error 和 warning。
**缺点**
打包后的文件会变大，降低编译速度。

# manifest
保存所有 module 到 bundle 之间的映射，提供给 webpack 查阅。
```json
{
  "index.js": "auto/index.bundle.js",
  "print.js": "auto/print.bundle.js",
  "index.html": "auto/index.html"
}
```

# foutput
这份配置会输出 2 个 bundle 文件，分别是 index.bundle.js 和 print.bundle.js。
```js
module.exports = {
  entry: {
    index: 'xxx',
    print: 'xxx'
  },
  output: {
    filename: '[name].bundle.js'
  }
}
```

# fhtml-webpack-plugin
1. webpack 日志会加上 index.html 资源。(asset index.html 276 bytes [emitted])
2. 生成的 html 文件会自动加上 script 文件，其中会加载 bundle 文件。
```html
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>管理输出</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script defer="defer" src="index.bundle.js"></script>
  <script defer="defer" src="print.bundle.js"></script>
</head>
<body></body>
</html>
```


# fCSS f如何配置CSS处理流程
1. [loader] postcss-loader 处理现代 css 语法，如变量、嵌套等。 (less-loader/sass-loader)
2. [loader] css-loader css 处理 @import/url(..), 处理 css 模块化。
3. [loader] mini-css-extract-plugin.loader 将处理好的内容提取成 css 文件。 (style-loader将style标签插入到head里)
4. [plugin] purgecss-webpack-plugin 摇树优化 css。
5. [plugin] optimize-css-assets-webpack-plugin 压缩 css 代码。
*optimize-css-assets-webpack-plugin*
在 webpack 构建期间搜索 css 资源，并将最小化 css, 默认情况下，它使用 cssnano, 但可以自定义 css 处理器。
*mini-css-extract-plugin*
将 css 提取成文件，以内容哈希来命名，这样项目内容更新时，文件名也会改变，使前端缓存失效而刷新。
*css-loader*
1. 处理 @import 和 url(...), 就像 import 和 require 一样。
2. 处理 css 模块化。
*postcss-loader*
处理现代 css 语法，如嵌套规则、变量、函数，且自动加上浏览器前缀。
*webpack配置*
```js
module.exports = {
  mode: 'production',
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [
          MiniCssExtractPlugin.loader,
          {
            loader: 'css-loader',
            options: { modules: true }
          },
          'postcss-loader',
        ]
      }
    ]
  },
  plugins: [
    postcssPresetEnv({
      stage: 3,
      features: { 'nesting-rules': true },
      autoprefixer: true
    }),
    new MiniCssExtractPlugin({
      filename: '[name]_[contenthash:8].css'
    }),
    new PurgeCSSPlugin({
      paths: () => glob.sync(path.resolve(__dirname, 'src') + '/**/*', { nodir: true });
    }),
    new OptimizeCSSAssetsPlugin({
      assetNameRegExp: /\.css$/g,
      cssProcessor: require('cssnano'),
    })
  ]
}
```


# f调试方法
**安装**
npm install --global node-nightly
**预执行**
node-nightly
**打断点**
在 ./node_modules/webpack/xx 中写 debugger。
**执行**
1. sudo node-nightly --inspect --inspect-brk ./node_modules/webpack/bin/webpack.js --config ./webpack.config.js
2. 打开 chrome://inspect/#devices, 在 Remote Target 里找到一个 target。
3. 点开以后，在 Chrome DevTools 里即可找到 debugger 调试。
**参考**
https://webpack.js.org/contribute/debugging/






📒官网项目笔记
# 起步
1. 执行 webpack，会将我们的脚本 src/index.js 作为 入口起点，也会生成 dist/main.js 作为 输出。
2. webpack 能够开箱即用般支持 import 和 export。事实上是对它们进行了转译。

# 管理资源
1. webpack 期望 loader 链中的最后的 loader 返回 JavaScript。
2. style-loader 会在 head 标签中插入 css 样式。
3. css-loader 会对 @import 和 url() 进行处理，就像 js 解析 import/require() 一样，然后可以在 src 中直接 import css 文件。
4. css打包后会在 bundle.js 里。
5. 图片打包后也在 bundle.js 里。
6. 各种 loader 处理对应的资源，但是要保证它们能输出到 bundle.js 中。比如 xml-loader 把 Xml 转成 js 的 JSON 对象，可以直接在 js 中处理。
7. 任意的资源(xml/css/yaml/csv/font/img/...)在 webpack 眼里都是 module, 他们通过 loader 输出到 bundle.js 里。

# 管理输出
1. 一个 entry 的键值对是一个`入口chunk`，一个`入口chunk`产生一个 bundle 文件。
2. output.filename 的 [name] 对应 `入口chunk` 的名称，执行构建后会自动给 bundle 文件命名。
3. HtmlWebpackPlugin 用你给的配置生成一份 index.html 文件。
4. webpack 通过 manifest，可以追踪所有 module 到 bundle 之间的映射。

# 开发环境
1. optimization.runtimeChunk = 'single';
提取 webpack 运行时代码成为一份 chunk。
如果有多个 entry 的话，应该把 webpack 的运行时代码单独抽成一个 chunk 出来，避免每个 entry 都写入一份。
2. devServer.hot = true;
按需热更新模块，比如: css 修改以后只改变 css 的 bundle 部分，而无需刷新浏览器，即可生效!