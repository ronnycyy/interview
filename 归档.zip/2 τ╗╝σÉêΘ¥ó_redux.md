# fredux
Redux 是 JavaScript 状态容器，提供可预测化的状态管理。 

Redux 可以用这三个基本原则来描述:
1. 单一数据源
整个应用的 state 被储存在一棵 object tree 中，并且这个 object tree 只存在于唯一一个 store 中。
这让同构应用开发变得非常容易。来自服务端的 state 可以在无需编写更多代码的情况下被序列化并注入到客户端中。由于是单一的 state tree ，调试也变得非常容易。在开发中，你可以把应用的 state 保存在本地，从而加快开发速度。此外，受益于单一的 state tree ，以前难以实现的如“撤销/重做”这类功能也变得轻而易举。

2. State 是只读的
唯一改变 state 的方法就是触发 action，action 是一个用于描述已发生事件的普通对象。
这样确保了视图和网络请求都不能直接修改 state，相反它们只能表达想要修改的意图。因为所有的修改都被集中化处理，且严格按照一个接一个的顺序执行，因此不用担心 race condition 的出现。 Action 就是普通对象而已，因此它们可以被日志打印、序列化、储存、后期调试或测试时回放出来。

3. 使用纯函数来执行修改
为了描述 action 如何改变 state tree ，你需要编写 reducers。
Reducer 只是一些纯函数，它接收先前的 state 和 action，并返回新的 state。刚开始你可以只有一个 reducer，随着应用变大，你可以把它拆成多个小的 reducers，分别独立地操作 state tree 的不同部分，因为 reducer 只是函数，你可以控制它们被调用的顺序，传入附加数据，甚至编写可复用的 reducer 来处理一些通用任务，如分页器。

## 手写源码
https://github.com/ronnycyy/state-manager/tree/main/redux

### fcreateStore.js
观察者模式: 订阅、取消订阅、发布。
```js
export default function createStore(reducer, initState, rewriteCreateStoreFunction) {
  if (rewriteCreateStoreFunction) {
    const newCreateStore = rewriteCreateStoreFunction(createStore);
    return newCreateStore(reducer, initState);
  }

  let state = initState;
  let listeners = [];

  function subscribe(listener) {
    // 订阅
    listeners.push(listener);
    // 取消订阅
    return function unsubscribe(listener) {
      const index = listeners.indexOf(listener);
      listeners.splice(index, 1);
    }
  }

  function getState() {
    return state;
  }

  function dispatch(action) {
    // 通知用户定义的 reducer 得到新的状态
    state = reducer(state, action);
    // 发布 
    // 无论哪个小状态变化，都将全量通知
    for (let i = 0, len = listeners.length; i < len; i++) {
      const listener = listeners[i];
      listener();
    }
  }

  // 执行所有的 reducer，使得 `以reducer为key的每个store`，在总状态里初始化。
  // 使用 symbol 避免和用户的 action.type 重名
  dispatch({ type: Symbol('__init_store__') });
  /**
   * 实现一个 Symbol?
   * 
   * function MySymbol(name) {
   *    const obj = Object.create({
   *      toString: function() {
   *         return name;
   *      }
   *    })
   *    return obj;
   * }
   */

  function replaceReducer(nextReducer) {
    reducer = nextReducer;
    dispatch({ type: Symbol('__init_store__') });
  }

  return {
    subscribe,
    getState,
    dispatch,
    replaceReducer,
  }
}
```




### fcombineReducer.js
组合用户所有的 reducer，每个 reducer 维护自己的那份 state (totalState[key])，但是每次更新都会创建一个全体的新的 state 返回。
如果确实没有变更，(非常少见，比如发了一个所有 reducer 都不受理的 action)，才会返回之前的 state 引用。
```js
export default function combineReducers(reducers) {
  const reducerKeys = Object.keys(reducers);

  // 最后合并好的 reducer
  return function combine(state = {}, action) {
    // 所有的 action, 都是执行这个 combine 函数，改变自己的 state (state[key])，返回整体的 state 中，最后改变整体的 state (引用)。
    const nextState = {}
    // 遍历所有 reducer
    for (let i = 0; i < reducerKeys.length; i++) {
      const key = reducerKeys[i];
      const reducer = reducers[key];  // counterReducer, infoReducer
      // 某个 reducer 的旧库
      const prevStateForKey = state[key];
      // 执行动作，状态改变，得到该 reducer 的新库
      const nextStateForKey = reducer(prevStateForKey, action);
      // reducer的key和state的key要保持一致
      // 该 reducer 的保存到一份新的总状态里
      nextState[key] = nextStateForKey;
    }
    return nextState;
  }
}
```


### fapplyMiddleware.js  f中间件原理 (中间件们把store.dipatch作为`🧅的最内核`包裹起来)
redux的中间件原理是:
1. 先把 store 传入每一个中间件，它们都返回一个函数，这个函数接受一个next函数，返回另一个函数，如 `(next) => (action) => {...}`
2. 把这些函数通过 compose 组合起来，得到一个总体的函数，也是接受一个next函数，返回另一个函数: `(next) => ex(time(log(next)))`
3. 把 `store.dispatch` 作为 `next` 参数，传给这个函数，执行，最终返回一个符合洋葱模型🧅的函数，洋葱模型最内层就是原始的 store.dispatch:
`(action) => { ex1(next前),  time1,log1,store.dispatch,log2,time2 (next),  ex2(next后)  }`

如果传入的顺序是 applyMiddleware(左1,左2,左3),  那么最终的执行顺序是 左1,左2,左3,store.disptach,左3,左2,左1。

```js
// dispatch 的时候，依次执行所有的 middleware。
const applyMiddleware = function (...middlewares) {

  // 返回这个函数，给 createStore.js 里的 rewriteCreateStoreFunction 调用，再返回一个新的 createStore 函数
  return function (oldCreateStore) {

    // 这个玩意儿是新的 createStore 函数，把中间件嵌入到 dispatch 流程中。
    return function (reducer, initState) {
      const store = oldCreateStore(reducer, initState);
      const simpleStore = { getState: store.getState };

      // 中间件先依次执行一遍，转成 (next) => xxx, 结果放到链中，形成数组
      // 每一个 middleware 变成一个 m(simpleStore) 的执行结果 ----> 一个函数: (next) => (action) => {...}
      // [
      //  (next) => (action) => {...log...}, 
      //  (next) => (action) => {...exception...},
      //  ...
      // ]
      const chain = middlewares.map(m => m(simpleStore));
      // 现在中间件已经变成了 (next) => (action) => xxx 这个鬼样子,
      // 然后 compose 从右到左把中间件组合起来:
      // ex, time, log 三个转成 (next) => .. 的中间件，变成 (...args) => ex(time(log(...args))) 

      // 传入 store.dispatch 执行，返回 ex(time(log(store.dispatch))) 的执行结果, 执行过程是:

      // 1. log 中间件 ”(next) => (action) => xxx“ 执行，返回一个函数，作为 next 给 time 中间件
      // ex(time(   (action) => {..log1..., store.dispatch, ..log2...}       ))

      // 2. time 中间件执行，返回一个函数，作为 next 给 exception 中间件
      // ex(   (action) => {..time..}   )

      // 3. 最后返回一个函数，给 dispatch
      // (action) => { 错误处理(next之前)...,  time中间件执行传过来的函数(action) => {...} (next),  xxx(next之后)  }

      // 所以，在 dispatch 的时候，中间件根据传入 applyMiddleware 的顺序，从左往右，按洋葱模型🧅执行。(左1,左2,左3,store.disptach,左3,左2,左1)
      const dispatch = compose(...chain)(store.dispatch);

      console.log('dispatch', dispatch);

      return {
        ...store,
        dispatch
      }
    }
  }
}
export default applyMiddleware;
```

### fbindActionCreators.js
把所有创建 action 的函数集中到一个对象上，使用时可以直接调用。
比如 const actions = bindActionCreators({ Add, setName }, store.dispatch);  
使用时 actions.Add(); 相当于 store.dispatch({ type: 'ADD' });
```js
/**
 * @param {Function} actionCreator 用户定义的 action 函数，比如 setName 函数。
 * @param {Function} dispatch store.dispatch
 */
function bindActionCreator(actionCreator, dispatch) {
  return function () {
    return dispatch(actionCreator.apply(null, arguments));
  }
}
export default function bindActionCreators(actionCreators, dispatch) {
  const b = {};
  // 把所有创建 action 的函数集中到一个对象上，使用时可以直接调用。
  // for..in  遍历所有可枚举属性，它会把原型上的属性也找出来，只不过 Object.prototype 上的属性是不可枚举的，所以没出来。
  for (const key in actionCreators) {
    const action = actionCreators[key];
    if (typeof action === 'function') {
      b[key] = bindActionCreator(action, dispatch);
    }
  }
  return b;
}
```

## fcompose.js
从右往左组合函数，比如 compose(f, g, h) 返回一个函数: (...args) => f(g(h(...args)))
```js
export default function compose(...funcs) {
  if (funcs.length === 0) {
    return (arg) => arg
  }
  if (funcs.length === 1) {
    return funcs[0]
  }
  // a 相当于之前所有组合好的函数, b 是本次要组合的函数, 
  // 比如: (f(g(...args)), h) => (...args) => f(g(h(...args)))
  return funcs.reduce((a, b) => (...args) => a(b(...args)))
}
```


# fRedux-Toolkit fredux-toolkit fToolkit
redux 官方推荐的工具集，比 redux 更加轻量。最佳实践。

# react-redux
`react-redux`是将`Redux store`和`React UI`相结合的`官方绑定层`。
它使 react 组件可以从 redux store 读取数据，也可以向 store 发起 action 以更新状态。
基于 context API 封装。
## 手写源码
https://github.com/ronnycyy/state-manager/tree/main/react-redux (【手写源码系列】40分钟带你从0到1实现一个react-redux)



# fRecoil frecoil f原子化
Recoil 是 React 的状态管理库，只能用在 React 里边。
## 目标
redux太复杂, 得创建 store, reducer, action, ..., 和 react 合起来还得创建 react-redux。项目复杂时，会有多层 Provider 树🌲.
因此，Recoil的目标是: 最小化state，不要有包装，不要多层次的Provider。
## 核心
原子状态变化(text) -> 衍生状态变化(text.length) -> 视图更新。
## 手写源码
https://github.com/ronnycyy/state-manager/tree/main/recoil  (前端中的数据结构和算法2)


# 前端状态管理库的对比
Redux `时间旅行`的理念非常经典，由这个理念发展出了很多状态管理库。
应该怎么选择 React 状态管理库？从两个角度说:
1. 项目规模
2. 项目类型

## 项目规模
1. 很小的项目，玩具项目，没必要用库了，直接 context API 就行。
2. 大一丢丢的项目，但还是一个人写的，比如短期的活动页，可以用一些迷你的库，比如 unstated(基于context封装)
3. 再大一点，需要几个小伙伴合作的，就可以用 dva, mobx, jotai, recoil 等基于`原子状态`理念的。

## 项目类型
1. 普通的后台管理页，要填很多表单 => 双向数据绑定 => 适合用 mobx。
2. 富文本编辑器，我需要完成 `撤销/重做` 这样的功能，那就适合用 redux 系列的`时间旅行`的库。

