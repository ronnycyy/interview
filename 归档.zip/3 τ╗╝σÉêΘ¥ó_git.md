# fgit
**讲概念**
1. git 是一个免费的、开源的分布式版本控制系统，旨在以快速高效的方式处理从小型到大型的所有项目。
2. git 易于学习、占用空间小、性能极快。它具有方便的工作区、暂存区、本地库和多个工作流分支等特性。

## 你们之前用的是啥
1. 我们用的是 github, 建立一个私有库，然后开始开发。
2. 我平时用的是 vscode 来使用 git 命令，有些时候会用命令行比如 git log[flog]/ git status[fstatus]，我觉得命令行更直观。

## 你 git push 的时候冲突了咋办？
1. 先 git pull 拉取最新的更改，这一步会在 vscode 里看到尖括号, 显示远程库代码和你的工作区代码冲突的部分。
2. 尖括号的代码合并好以后, 再 git push 推送回远程库。

## 冲突合并
1. 尖括号之间的部分就是冲突代码。
2. 一排等于号上面是你的代码, 下面是别人的代码, 把尖括号删掉，合并好代码再 git push 回去。
<<<HEAD
<当前工作区的代码>
======
<别人的代码>
>>>>> hot-fix


## 架构
**远程库**
git fpush (将本地分支推送到远程服务器的某个分支上)
git fpull (拉取远程库的更新到本地)
git fclone (克隆项目到本地如 git clone git@github.com:ronnycyy/interview.git 或 https://github.com/ronnycyy/interview.git)
git fremote add <远程别名如origin> <远程链接> (本地已经有项目,添加一个远程库)

**本地库**  [本地库就好像远程中心库一样，可以增删改分支，维护分支的提交记录，最后push到远程库即可，实现分布式!]
git fcommit (将修改提交到本地库，本分支上新增一个提交结点, 如 `git commit -m "本次提交的信息"`) 
git freset --hard [commitCode]  (回到某一个提交历史，作出修改后在提交，这条分支回有一个最新修改。实现回到过去，逆转现在!)
git fbranch <分支名>  (查看分支情况，或新建`分支名`)
git fmerge <其他分支>   (其他分支合并到当前分支, 最后 2 个分支分出又汇聚, 2 个分支结构都保留)
git frebase <其他分支>  (把`当前分支和其他分支的分开的那一段`断开, 嫁接到`其他分支后面`, 最后 2 条分支合并成 1 条分支)
git fcheckout <分支名> (切换到`分支名`)
git flog     (当前分支的提交日志)
git freflog  (所有分支的提交日志)

**暂存区**
git fadd  (添加`修改`到`暂存区`, 如 git add . 把所有`修改`添加到暂存区)
git frestore --stage [file] (取消添加到暂存区)

**工作区**  [我们平时写代码的区域]
git fstatus: 查看工作区的文件相对于上次 commit 的修改状态, 比如新建了什么文件，修改了什么文件。



# fmerge vs frebase   git merget 和 git rebase 有什么区别?
**共同点**
这两个命令都是将 2 个分支合并。
**不同点**
1. merge 是把 2 个分支的`最近公共祖先`和`最新提交`结合, 当前分支产生一个最新的提交结点，最后 2 个分支结构都保留着。
2. rebase 是从`最近公共祖先`开始，沿着`当前分支`的提交链截取到最新提交, 然后把这段提交嫁接到`其他分支`上，最后只形成 1 条分支。
**举例子1 git merge developer**
在 master 分支上执行 git merge developer, 这一步会结合 3,4,7 建立新提交结点 8。
```js
(master分支)   1->2->3------>5---->7    =======>     1->2->3------>5--->7--->8(新!)
(developer分支)        v--4--->6                             v--4--->6----^
```
**举例子2 git rebase developer**
在 master 分支上执行 git rebase developer
1. 找到 master 和 developer 的最近公共祖先 3 结点。
2. 截取下 master 分支在 3 号结点以后的所有提交结点 5-->7。
3. 嫁接到 developer 分支的最新提交 6 结点之后，也就是 developer 分支形成 v-->4-->6->5->7。
```js
(master分支)   1->2->3------>5---->7    =======>     1->2->3->4(合并!)->6(合并!)->5’(合并!)->7‘(合并!)
(developer分支)        v-->4---->6                             
```



## 本地库结构
-------- commit1 ----------- commit2 -------- commit3  ---------------- commit 4 -----------------------   分支一
            |                                                                      | 合并给分支一
            -------- commit1 --------------------------------   分支二              |
                              |                                                    | 分支三可以继续走，无影响
                              ------- commit 1 ------------------------------------|-------- 分支三 

### 分支
多个分支是本地库中的多个工作流，每个分支独立管理自己的提交历史。

当前所在的分支，是由 HEAD 决定的。
master,hot-fix 这两个分支其实是两个指针，HEAD 指向谁，谁就是当前分支，切换分支的本质就是改变 HEAD 指向。

#### 例子
两个分支，每个分支有独立的提交历史:
first ---- second  ---- third --- fourth ----- fifth  [master]   
                          |
                        third --------- fourth        [hot-fix]   <= HEAD (当前分支是 hot-fix)
 
#### 优点
1. 同时并行推进多个功能开发，提高开发效率。
2. 各个分支在开发过程中，如果某一个分支开发失败，不会对其他分支造成影响。失败的分支删除了，重新开始即可。

#### 合并冲突的分支
在当前分支下，合并其他分支的修改。(注意合并只会影响当前分支的内容，对其他分支毫无影响)

##### 背景
1. 合并分支时，两个分支在同一个文件的同一个位置有两套完全不同的修改，Git无法帮我们作出决定，这时就有冲突。
2. 冲突发生时，需要人为决定新代码的内容。

#### 步骤
1. 执行合并
git merge <其他分支>

```shell
Auto-merging test.md  // 正在自动合并 test.md...
CONFLICT (content): Merge conflict in test.md   // test.md 里有合并冲突
Automatic merge failed; fix conflicts and then commit the result.   // 自动合并失败
```

2. vim test.md 查看冲突文件
<<<HEAD
<当前分支的代码>
======
<要合并进来的分支的代码>
>>>>> hot-fix

3. 手动修改
修改`<<<HEAD`和`======`中间的内容，留下你要的部分，然后把分割线删掉。

4. 保存
wq, git add, git commit, 完成以后，`其他分支`的修改就合并到`本分支`了。


## 分支内版本穿梭 (回到某一个提交历史)  f版本穿梭
回到某一个提交历史，作出修改后，再提交到最新修改的后面。 实现回到过去，逆转现在!

first ---- second  ---- third --- fourth ----- fifth                当前在 fifth 提交
                                              [master]

first ---- second  ---- third --- fourth ----- fifth                回到 third 提交
                      [master]       

first ---- second  ---- third --- fourth ----- fifth ---- sixth     基于 third 修改，提交 sixth
                                                        [master]                
### 命令
git reset --hard [commitCode]


# finit git init
1. 创建一个新的存储库。
2. 设置一个 .git 子目录。
3. 创建一个新的主分支。




