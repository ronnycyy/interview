# f数据类型 fJS有哪些数据类型
一共有 8 种数据类型，分别是:
* Undefined  [原始数据类型,存放在栈]
* Null       [原始数据类型,存放在栈]
* Boolean    [原始数据类型,存放在栈]
* String     [原始数据类型,存放在栈]
* Number     [原始数据类型,存放在栈]
* BigInt     [原始数据类型,存放在栈]   [ES6]
* Symbol     [原始数据类型,存放在栈]   [ES6]
* Object                          [引用数据类型,如对象,数组和函数,存放在堆]  

# f判断数据类型
## 方法一: ftypeof
typeof 操作符返回一个字符串，表示操作数的类型。
### 结果
      类型	             执行 typeof 的结果
      Undefined        	"undefined"
      Null              "object"      [typeofnull为啥是"object"]
      Boolean           "boolean"
      Number            "number"
      BigInt            "bigint"
      String            "string"
      Symbol            "symbol"
      Function          "function"
      其他任何对象        "object"
### typeof 缺点
**缺点1**
1. 对 Object/Array/Map/Set/Null 都是返回 "object"，无法进一步细分类型。
**缺点2**
为什么 `typeof null` 是 "object":  [typeofnull为啥是"object"]
1. 在 JavaScript 最初的实现中，JavaScript 中的`值`是用`表示类型的标签`和`实际数据值`表示的。
2. 它用一个`32bit`的数据存储，其中用了 `3个bit` 来存储类型，`对象`的类型是 `000`。
3. 而由于`null`代表的是空指针，值为`0x00`，所以 `null`的类型标签也是`000`，所以 `null` 也被认为是一个 `对象`。

## 方法二: Object.prototype.toString.call
1. 这个方法判断类型比较准确，它同样返回一个字符串，值为 "[object Constructor]"。
2. 比如一个数组的结果就是 "[object Array]", Map 结果是 '[object Map]', undefined 是 '[object Undefined]', null 是'[object Null]'。

## 方法三: finstanceof
instanceof 运算符用于检测构造函数的 prototype 属性是否出现在某个实例对象的原型链上。
### instanceof 缺点
1. 如果表达式 obj instanceof Foo 返回 true，则并不意味着该表达式会永远返回 true，因为 Foo.prototype 属性的值有可能会改变，改变之后的值很有可能不存在于 obj 的原型链上，这时原表达式的值就会成为 false。
2. 另外一种情况下，原表达式的值也会改变，就是改变对象 obj 的原型链的情况，虽然在目前的ES规范中，我们只能读取对象的原型而不能改变它，但借助于非标准的 __proto__ 伪属性，是可以实现的。比如执行 obj.__proto__ = {} 之后，obj instanceof Foo 就会返回 false 了。
3. 在浏览器中，我们的脚本可能需要在多个窗口之间进行交互。多个窗口意味着多个全局环境，不同的全局环境拥有不同的全局对象，从而拥有不同的内置类型构造函数。这可能会引发一些问题。比如，表达式 [] instanceof window.frames[0].Array 会返回 false，因为 Array.prototype !== window.frames[0].Array.prototype，并且 [] 是从 Array.prototype 而不是 window.frames[0].Array 继承的。
### instanceof 的坑爹题
instanceof 检查`右边这个构造函数的prototype`也就是原型，是否在`左边这个对象`的原型链上(`__proto__`)，是就返回`true`，不是就返回`false`。
```js
// 目标:  检查 Function.prototype 是否在 Object 的原型链上。
// 思路:  把 Object 看成一个对象，它是由 Function 构造的，于是 Object.__proto__ === Function.prototype。
// 答案:  true;
Object instanceof Function  // true;

// 目标:  检查 Object.prototype 是否在 Function 的原型链上。
// 思路:  把 Function 看成一个对象，它是由 Function 构造的，于是 Function.__proto__ === Function.prototype，
//    然后 Function.prototype 是一个普通的对象，它是由 Object 构造的，所以 Function.prototype.__proto__ === Object.prototype。
//    所以 Function.__proto__.__proto___ === Object.prototype。
// 答案: true;
Function instanceof Object  // true;  
```


# fBigInt
**概念**
1. BigInt 是 ES6 提供的一种数据类型，用来表示大于`Number.MAX_SAFE_INTEGER`(值为2^53 - 1)的整数。
2. BigInt 能更加安全地存储和操作大整数。
## fBigInt 和 fNumber 的区别
* BigInt 不能用于 Math 对象中的方法;
* BigInt 不能和任何 Number 实例混合运算;
## 为什么有 BigInt 的提案？
JS 超过 Number.MAX_SAFE_INTEGER 时 (2^53-1 [9007199254740991])，会出现计算不准确的情况，这使得 JavaScript 不适合进行科学和金融方面的精确计算。因此官⽅提出了BigInt来解决此问题。 
## 注意
JS 的原始 Number 是双精度浮点数，是 64 位的。
## 使用
可以用在一个整数字面量后面加 n 的方式定义一个 BigInt ，如：10n，或者调用函数 BigInt()（但不包含 new 运算符）并传递一个整数值或字符串值。
```js
const theBiggestInt = 9007199254740991n;
const alsoHuge = BigInt(9007199254740991);  // 9007199254740991n
const hugeString = BigInt("9007199254740991");  // 9007199254740991n
const hugeHex = BigInt("0x1fffffffffffff");  // 9007199254740991n
const hugeBin = BigInt("0b11111111111111111111111111111111111111111111111111111");  // 9007199254740991n
```


# fSymbol
**讲概念**
1. ES6 引入了一种新的原始数据类型 Symbol，表示独一无二的值。 [f数据类型]
2. Symbol 是一个原始类型的值，不是对象, 只能通过 `Symbol()`, 而不能通过`new`来创建。
**原因** [为什么引入Symbol]
1. ES5 的对象属性名都是字符串，这容易造成属性名的冲突。比如，有一个其他人提供的对象，现在要添加一个方法，方法名字这个对象已经有了，这样就有冲突。
**用途**
1. 一个 symbol 值能作为对象属性的标识符, 这是该数据类型仅有的目的。
**用法**
Symbol() 接收一个 description 字符串，这个是可选的, 作为一个对 symbol 的描述, 返回一个 symbol 原始类型的值。
```js
const obj = {};
const s1 = Symbol('same_name');
const s2 = Symbol('same_name');
obj[s1] = 666;
// 现在 obj 是 { Symbol(same_name): 666 }
console.log(obj[s2]);
// 虽然 s2 和 s1 的字符串描述一样，但是 s1 和 s2 是完全不同的, s2 根本没有在 obj 上, 打印 undefined。
```
**注意**
1. `Symbol()`函数前不能使用`new`命令，否则会报错, 这是因为生成的 Symbol 是一个原始类型的值，不是对象，所以不能使用 new 命令来调用。
2. `Symbol` 值作为对象属性名时，可以通过 obj[symbol] 来调用，但是不能通过用点运算符。
**API**
1. 原型上有一些方法, 如 Symbol.prototype.description(返回描述,如"foo"), toString(如返回"Symbol(foo)")
2. Symbol 有一些静态方法, 如 Symbol.replace, Symbol.search 等。


# fBuffer
Buffer 是内存中的一个存储区域，当数据进行转译时用来临时存放数据。

# fArrayBuffer
1. ArrayBuffer 对象用来表示通用的、固定长度的原始二进制数据缓冲区。它是一个字节数组，通常在其他语言中称为“byte array”。
2. 你不能直接操作 ArrayBuffer 的内容，而是要通过`类型数组对象`或`DataView`对象来操作，它们会将缓冲区中的数据表示为特定的格式，并通过这些格式来读写缓冲区的内容。

# f原型
### 原型
每个由构造函数创建的对象，都拥有一个原型对象，对象以其原型为模板、从原型继承方法和属性。
### 原型链
原型对象也可能拥有原型，并从中继承方法和属性，一层一层往上推导，这样的关系被称为原型链，它解释了为什么在 JS 中一个对象会拥有，定义在其他对象中的属性和方法。
## 注意点
一般来说，对象不应该能够获取到原型，不过现在浏览器中都实现了 __proto__ 属性来访问这个属性，但是最好不要使用这个属性，因为这个属性已经从 Web 标准中删除，虽然一些浏览器目前仍然支持它，但也许会在未来的某个时间停止支持，请尽量不要使用该特性。我们可以使用 Object.getPrototypeOf() 方法来获取对象的原型。
## 缺点
在原型链上查找属性会比较耗时，对性能有副作用，这在性能要求严苛的场景下影响很大。比如，用for...in 遍历对象的属性时，原型链上的每个可枚举属性都会被枚举出来。
## 解决方案
要检查对象是否具有自己定义的属性，而不是其原型链上的某个属性，可以使用从 Object.prototype 继承的 hasOwnProperty 方法，这样避免了查找原型链，可以提升一些性能。

## f坑爹原型题 (聊完 原型 大概率会做这些坑爹题)
关键: 现在操作的是`函数`还是`对象`。
### 函数
1. `函数.__proto__ === Function.prototype`
2. `Foo.constructor === Function` => `Function.constructor === Function`  环
### 对象
1. `xx.prototype.__proto__ === Object.prototype`。
2. `Object.prototype.__proto === null`  单链表


## f继承 (聊完 原型 可能会让我手写)
### 寄生组合继承
这个是用 ES5 实现继承比较好的方式，优点:
1. 没有父类的实例属性。
2. 一个原型对象共享给多个实例。
```js
// 父类
function Father() {}
// 子类
function Son() {}
// 通过寄生方式，砍掉父类的实例属性，避免了组合继承生成两份实例的缺点
Son.prototype = Object.create(Father.prototype);
// 修复构造函数指向
Son.prototype.constructor = Son;
```
### class继承
ECMA-262 规范推荐的写法，注意两点:
1. 使用extends表明继承自哪个父类。
2. 在子类构造函数中必须调用super。
```js
class Son extends Father {
  constructor(name) {
    super(name);
    this.name = name || "son";
  }
}
```

# fthis f上下文
上下文是对"拥有当前执行代码的对象"的引用，它始终是this的值。
this 是执行上下文中的一个属性，它指向最后一次调用这个方法的对象。在实际开发中，this 的指向可以通过四种调用模式来判断。

- 第一种是**函数调用模式**，当一个函数不是一个对象的属性时，直接作为函数来调用时，this 指向全局对象。
- 第二种是**方法调用模式**，如果一个函数作为一个对象的方法来调用时，this 指向这个对象。
- 第三种是**构造器调用模式**，如果一个函数用 new 调用时，函数执行前会新创建一个对象，this 指向这个新创建的对象。
- 第四种是 **apply 、 call 和 bind 调用模式**，这三个方法都可以显示的指定调用函数的 this 指向。其中 apply 方法接收两个参数：一个是 this 绑定的对象，一个是参数数组。call 方法接收的参数，第一个是 this 绑定的对象，后面的其余参数是传入函数执行的参数。也就是说，在使用 call() 方法时，传递给函数的参数必须逐个列举出来。bind 方法通过传入一个对象，返回一个 this 绑定了传入对象的新函数。这个函数的 this 指向除了使用 new 时会被改变，其他情况下都不会改变。

这四种方式，使用构造器调用模式的优先级最高，然后是 apply、call 和 bind 调用模式，然后是方法调用模式，然后是函数调用模式。

# f作用域
作用域是对变量可访问范围的限制，作用域分为全局作用域、函数作用域、以及 ES6 的块级作用域。内层作用域可以访问外层作用域，外层作用域不可以访问内层作用域。
### 作用域链
在当前作用域中查找变量，如果没有找到，就去父级作用域查找，找不到就再往上，一直找到全局作用域为止，这一层层关系形成了一条链，这就是作用域链。
### 预解析
预解析(Hoisting) 是伴随作用域的概念。在JS代码执行之前，也就是编译阶段，先把var变量的声明和函数的声明，提升到当前作用域的顶部。这样即使函数声明写在函数使用的后面，也可以正常执行。
注意: 当一个函数遇到一个同名的值为undefined的变量，会忽略掉这个undefined变量，所以同名的变量和函数都提升时，函数会覆盖掉这个变量。
## 说用途
作用域链的作用是保证对`执行环境有权访问的所有变量`和`函数`的`有序访问`，通过作用域链，可以一层层按顺序访问到外层环境的变量和函数。

# f执行上下文 fcontext (很多框架的 context 指的就是执行上下文) (其实是作用域的概念..)
执行上下文是`JS`执行一段代码时的运行环境，该运行环境定义了可访问的变量、函数、以及参数。
比如调用一个函数，就会进入这个函数的执行上下文。执行上下文分为全局执行上下文、函数执行上下文、eval执行上下文。
### 全局执行上下文
任何不在函数内部的都是全局执行上下文，它首先会创建一个全局的window对象，并且设置this的值等于这个全局对象，一个程序中只有一个全局执行上下文。
### 函数执行上下文
当一个函数被调用时，就会为该函数创建一个新的执行上下文，函数的上下文可以有任意多个。
### eval上下文
执行在eval函数中的代码会有属于他自己的执行上下文。
## 说用途
JavaScript解释器分 2 道工序:
1. 预编译阶段
  1. 创建变量 VO (Variable Object, 变量对象)
  2. 变量声明和提升(值为undefined)
  3. 非表达式的函数声明提升
2. 代码执行阶段
  1. 将 VO 转化为 AO (Active Object, 激活对象)
  2. 开始执行代码时，首先会创建全局执行上下文，后面每次调用一个函数，都会创建一个新的执行上下文，添加道调用栈的顶部。
  3. 浏览器总是执行位于调用栈顶部的执行上下文，一旦执行完毕，该执行上下文就会从调用栈中弹出，然后控制权来到栈的下一个执行上下文中。

# f闭包
一个外层函数返回一个内层函数，这个内层函数和`对外层函数作用域的引用`捆绑在一起，这样的组合就是闭包。
## 说用途
闭包有两个用途，一个是创建私有变量，另外一个是延长变量的生命周期。
1. 创建私有变量
外层函数运行结束后，只有它返回的内层函数可以访问外层函数的作用域的变量，其他人不能访问，所以这些变量就成为内层函数的私有变量。(这些变量就好像内层函数的专属背包一样，所以形象地称为闭包)
2. 延长变量的生命周期
具体来说，是使已经运行结束的外层函数上下文中的变量对象继续留在内存中，因为内层函数保留了这个变量对象的引用，所以这个变量对象不会被回收。这样外层函数结束以后，闭包还能继续使用。
3. 业务中闭包的使用场景有: 防抖、节流、柯里化、回调等
## 优缺点
### 优点
就是上面说的用途: 1.创建私有变量 2.延长变量的生命周期
### 缺点
如果闭包使用不正确，很容易造成内存泄漏。

比如引用闭包的函数是一个全局变量，那么闭包会一直存在直到页面关闭；但如果这个闭包以后不再使用的话，就会造成内存泄漏。
所以在使用闭包的时候，我们要尽量注意一个原则: 如果该闭包会一直使用，那么它可以作为全局变量而存在; 但如果使用频率不高，而且占用内存又比较大的话，那就尽量让它成为一个局部变量。
如果引用闭包的函数是个局部变量，等函数销毁后，在下次 JavaScript 引擎执行垃圾回收时，判断闭包这块内容如果已经不再被使用了，那么 JavaScript 引擎的垃圾回收器就会回收这块内存。
(一个很多人都有的误区: 闭包不会造成内存泄漏，代码写错了才会造成内存泄漏!)

# f垃圾回收
JavaScript在创建变量时自动进行了分配内存，并且在不使用它们时“自动”释放。 释放的过程称为垃圾回收。
垃圾回收算法主要依赖于`引用`的概念。在内存管理的环境中，一个对象如果有访问另一个对象的权限，不管是隐式还是显式的，都叫做一个对象引用另一个对象。例如，一个 `Javascript`对象具有对它原型的引用，这是隐式引用，还有对它属性的引用，这是显式引用。
## 说用途
浏览器的垃圾回收算法主要有两种 ——  引用计数 和 标记清除。
### f引用计数
这个是最初级的垃圾收集算法，它的理念是: 把 `对象是否不再需要` 简化定义为 `对象有没有其他对象引用到它`。如果没有`引用`指向该对象，对象将被垃圾回收机制回收。
#### 引用计数的缺点
`引用计数`无法处理`循环引用`的情况。比如在一个函数中，两个对象被创建，并互相引用，形成了一个循环。它们被调用之后会离开函数作用域，所以它们已经没有用了，可以被回收了。然而，引用计数算法考虑到它们互相都有至少一次引用，所以它们不会被回收。
### f标记清除
标记清除是现代浏览器常见的垃圾回收算法。这个算法把`对象是否不再需要`简化定义为`对象是否可以获得`。
算法假定设置一个叫做根（root）的对象（在Javascript里，根是全局对象）。垃圾回收器将定期从根开始，找所有从根开始引用的对象，然后找这些对象引用的对象……。从根开始，垃圾回收器将找到所有可以获得的对象和收集所有不能获得的对象，`不能获取的对象`视为垃圾数据，它们所占的内存就可以回收了。
#### 标记清除的优点
`标记清除`可以有效解决`循环引用`的问题: 从全局对象触发，无法获取互相引用的两个对象，因此，他们将会被垃圾回收器回收。


## f防抖 f节流
防抖是 短时间内多次触发，只执行最后一次。
节流是 短时间内多次触发，每隔一段时间执行一次。
```js
// 防抖: 短时间内多次触发，只执行最后一次  (immediate参数控制首次是否触发)
function debounce(fn, time, immediate = false) {
  let timer = null;
  return function () {
    if (immediate) {
      fn();
      immediate = false;
      return;
    }
    if (timer !== null) {
      clearTimeout(timer);  // 清除上次延时任务，重新设置一次
    }
    timer = setTimeout(() => {
      fn();
      timer = null;
    }, time);
  }
}
// 节流: 持续触发，每隔一段时间执行一次
function throttle(fn, time) {
  let last = new Date();
  return function () {
    const now = new Date();
    if (now - last >= time) {  // 间隔时间后才触发
      fn();
      last = now;
    }
  }
}
```
### 防抖和节流的使用场景
1. 连续在 input 框里输入字符，希望实时显示搜索结果，这时候用防抖不要让请求一直发送，而是短时间内多次触发，只发送最后一次。


# f内存泄漏
## 1.讲概念
内存泄漏是指程序中已分配的堆内存由于某种原因程序未释放或无法释放，造成系统内存的浪费，导致程序运行速度减慢甚至系统崩溃。
## 2.特点
内存泄漏缺陷具有隐蔽性、积累性的特征，比其他内存非法访问错误更难检测。因为内存泄漏的产生原因是内存块未被释放，属于遗漏型缺陷而不是过错型缺陷。
内存泄漏通常不会直接产生可观察的错误症状，而是逐渐积累，降低系统整体性能，极端的情况下可能使系统崩溃。
## 3.如何防止内存泄漏
1. 检查是否有意外的全局变量没有清除。
2. 清除定时器内部的变量。比如设置了 setInterval 而忘记取消，如果循环函数有对外部变量的引用的话，那么这个变量会被一直留在内存中无法被回收。
3. 在低版本的浏览器环境下，要防止循环引用。某些低版本浏览器的垃圾回收机制还在使用引用计数，循环引用的内存无法释放，会造成内存泄漏。


# fbind fcall fapply
## 讲概念
### bind
bind 方法创建一个新的函数，在 bind 被调用时，这个新函数的 this 被指定为 bind 的第一个参数，而其余参数将作为新函数的参数，供调用时使用。
### call
call 方法使用一个指定的 this 值和单独给出的一个或多个参数来调用一个函数。
### apply
apply 方法调用一个具有给定this值的函数，以及以一个数组（或类数组对象）的形式提供的参数。
## 注意点
### 连续的 bind 以哪个为准？
第一个。我的理解是, 底层就是这么实现的。
TODO: 看一下
### 已经被 bind 的函数，再 call/apply 不会改变 this
已经被 bind 绑定 this 的函数，再通过 call或者 apply 传入 this 来执行，传入的 this 是不会生效的，生效的只有 bind 的 this。包括连续的 bind，也只有第一次 bind 会生效， this 永远指向第一次 bind 的参数。
## 手写 (大概率会写)
```js
Function.prototype.myApply = function () {
  // 要判断一下，因为有可能有这种情况:
  // const o = {};  Object.setPrototypeOf(o, Function.prototype);
  if (typeof this !== 'function') {
    throw new TypeError('this is not a function');
  }
  // 没传就是 window
  const ctx = arguments[0] || window;
  // arguments[1] 传的必须是数组
  const args = arguments[1] ? [...arguments[1]] : [];
  // 挂到 context 上，使 fn 以 context 为 this 执行。
  // 担心 context 会有重复变量名，为了不覆盖它，用 Symbol 生成一个唯一的属性名
  // 这样既不影响原对象，又能达到 apply 的目的
  const fnName = Symbol('fnName');
  ctx[fnName] = this;
  // 执行
  const result = ctx[fnName](...args);
  // 删掉挂上去的属性
  delete ctx[fnName];
  // 返回结果
  return result;
}
Function.prototype.myCall = function () {
  // 要判断一下，因为有可能有这种情况:
  // const o = {};  Object.setPrototypeOf(o, Function.prototype);
  if (typeof this !== 'function') {
    throw new TypeError('this is not a function');
  }
  // 没传就是 window
  const ctx = arguments[0] || window;
  // 传的必须是数组，没传就是空数组
  // arguments 不是数组，没有 slice 方法，所以要借用空数组
  const args = [].slice.call(arguments, 1);
  // 挂到 context 上，使 fn 以 context 为 this 执行。
  // 担心 context 会有重复变量名，为了不覆盖它，用 Symbol 生成一个唯一的属性名
  // 这样既不影响原对象，又能达到 apply 的目的
  const fnName = Symbol('fnName');
  ctx[fnName] = this;
  // 执行
  const result = ctx[fnName](...args);
  // 删掉挂上去的属性
  delete ctx[fnName];
  // 返回结果
  return result;
}
// 注意 bind 的特性:
// 1. 当成普通函数使用，此时 bind 生效。
// 2. 当成构造函数使用，此时 bind 无效。
Function.prototype.myBind = function (context) {
  // 要判断一下，因为有可能有这种情况:
  // const o = {};  Object.setPrototypeOf(o, Function.prototype);
  if (typeof this !== 'function') {
    throw new TypeError('this is not a function');
  }
  // 待绑定的函数
  const fToBind = this;
  // 用于绑定原型链
  const fNop = function () { };
  // 转成数组
  const outerArgs = [].slice.call(arguments, 1);
  // 返回新的绑定函数
  function fBound() {
    // 将 arguments 转成 真正的数组
    const innerArgs = [].slice.call(arguments);
    // 如果是 new，this 是以 fBound 为构造函数，创建的实例（类比于 [] instanceof Array）
    // 如果不是 new，this 一般是 window
    // 检查是不是 new，从而决定用不用外来 this (context)
    return fToBind.apply(this instanceof fBound ? this : context, outerArgs.concat(innerArgs));
  }
  // 将"待绑定函数"视为构造函数，保存它的原型链，以防后续的 new 操作
  if (fToBind.prototype) {
    fNop.prototype = fToBind.prototype;
  }
  fBound.prototype = new fNop();

  return fBound;
}
```

# fNew
## 1. 讲概念 --  new 的时候发生了什么
1. 以 构造函数的原型对象为原型，创建一个对象。
2. 以该对象为上下文，执行构造函数，同时传递实参。
3. 判断执行构造函数返回的值:
  a. 如果是一个引用类型，就返回这个引用。
  b. 如果不是引用类型，返回创建的对象。
## 手写new
```js
// constructor: new的目标函数，也就是构造函数
function _new(constructor, ...args) {
  // 注意健壮性
  if (Object.prototype.toString.call(constructor) !== '[object Function]') {
    console.error('第一个参数请传入函数');
    return;
  }
	// 创建一个继承构造函数原型的对象，即将把它作为构造函数的执行背景。
  const context = Object.create(constructor.prototype);
  // 以该对象为this，执行构造函数
  // 构造函数往往会有this.name = name之类的语句，也就是说这一步在填充对象。
  const result = constructor.apply(context, args);
  // 如果有执行结果，返回执行结果；如果没有，返回该对象。
  return (typeof result === 'object' && result !== null) ? result : context;
}
```
### 手写以后的追问
1. 为什么不用 Object.setPrototypeOf 来修改原型？
mdn上介绍过，由于现代 JavaScript 引擎优化属性访问所带来的特性的关系，更改对象的原型在各个浏览器和 JavaScript 引擎上都是一个很慢的操作，如果开发者关心性能，应该避免设置一个对象的原型。相反，应该使用 Object.create() 来创建带有您想要的原型的新对象。
2. 为什么源码里有很多 const o = Object.create(null) ，不能直接 const o = {} 吗？
Object.create(null)可以创建一个纯净的对象，对象上没有从 Object.prototype 继承来的属性。


# f箭头函数
箭头函数表达式的语法比`函数表达式`更简洁，并且没有自己的this, 没有arguments, 没有 constructor, 也没有prototype。
## 用途
箭头函数表达式更适用于那些本来需要匿名函数的地方，比如 并且它不能用作构造函数。 (因为它没有 constructor，也就是构造器)
## 箭头函数的this指向哪里
箭头函数没有属于⾃⼰的this，它只会从自己的作用域链的上一层继承`this`，这个this也不会被改变。
## 箭头函数和普通函数的区别
1. 箭头函数比普通函数写法更简洁。
2. 箭头函数没有自己的this。
3. 箭头函数继承来的this永远不会改变。(call/apply/bind 都不能改)
4. 箭头函数不能作为构造函数使用，强行new会报错。
5. 箭头函数没有自己的arguments对象。在箭头函数中访问arguments实际上获得的是它外层函数的arguments值。
6. 箭头函数没有prototype。
7. 箭头函数不能用作Generator函数，不能使用yeild关键字。
## new一个箭头函数会怎么样 (箭头函数能作为构造函数/构造器吗)
new 一个箭头函数会报错，因为箭头函数没有自己的prototype，也就没有constructor, 所以不能用作构造函数。 
```js
const Foo = () => {};
const foo = new Foo(); // TypeError: Foo is not a constructor
```
## 特点
* 没有自己的 this，只有继承的 this
* 没有 arguments
* 没有 constructor
* 没有 prototype
### 没有自己的 this，只有继承的 this
箭头函数不会创建自己的`this`,它只会从自己的作用域链的上一层继承`this`。
由于箭头函数没有自己的`this`指针，通过 call 或 apply 方法调用一个函数时，第一个参数会被忽略，第二个往后的参数才会生效。
```js
function Person(){
  this.age = 0;
  setInterval(() => {
    this.age++; // |this| 正确地指向 p 实例
  }, 1000);
}
var p = new Person();
```
### 没有 constructor
new 一个箭头函数会报错，因为箭头函数不能用作构造器，和 new一起用会抛出错误。 为啥？它没有 prototype，也就没有 constructor。
```js
var Foo = () => {};
var foo = new Foo(); // TypeError: Foo is not a constructor
```
### 没有 prototype
箭头函数没有prototype属性。
```js
var Foo = () => {};
console.log(Foo.prototype); // undefined
```


# ffor..in  fforin  遍历key
`for...in`语句迭代一个对象的除`Symbol`以外的`可枚举属性`，包括`继承`的可枚举属性。
(
  1. 通过 `Object.prototype.hasOwnProperty` 只遍历自身属性
  2. Object.keys() 方法会返回一个由一个给定对象的自身可枚举属性组成的数组，数组中属性名的排列顺序和正常循环遍历该对象时返回的顺序一致 。
)
## 用途
`for...in`是为遍历对象属性而构建的，不建议与数组一起使用，数组可以用`Array.prototype.forEach`和`for...of`。
`for...in`最常用的地方应该是用于调试，可以更方便的去检查对象属性（通过输出到控制台或其他方式）。尽管对于处理存储数据，数组更实用些，但是你在处理有key-value数据（比如属性用作“键”），需要检查其中的任何键是否为某值的情况时，还是推荐用`for...in`。
## 代码
```js
var prototypeObject = {a: 1, b: 2, c: 3};
function ColoredTriangle() {
  this.color = 'red';
}
ColoredTriangle.prototype = prototypeObject;
var obj = new ColoredTriangle();
for (var prop in obj) {
  // 只拿自己本身的属性，不要原型对象上的属性。
  if (obj.hasOwnProperty(prop)) {
    console.log(`obj.${prop} = ${obj[prop]}`);
  }
}
// Output:
// "obj.color = red"
```
## 不要遍历初原型对象上的某个属性，除了 hasOwnProperty, 还有什么方案?
1. Obejct.keys(obj)
2. 把原型对象该属性描述符的 enumerable 设置为 false, 前提是该属性描述符的 configurable 为 true。
```js
var o = {};
// 初始化 prop1 属性是可枚举的
Object.defineProperty(o, 'prop1', {
  value: 6,   // 属性值
  configurable: true,  // 该属性的描述符才能够被改变，同时该属性也能从对应的对象上被删除。
  enumerable: true,  // 该属性会出现在对象的枚举属性中，可用于 for..in 和 Object.keys
  writable: true,   // 值能被赋值运算符改变
});
// 修改 prop1 属性为不可枚举, 这样就不会被遍历出来了
Object.defineProperty(o, 'prop1', {
  enumerable: false,
});
```

# ffor..of  遍历value
`for...of`语句在`可迭代对象`上创建一个迭代循环，调用自定义迭代钩子，并为每个不同属性的`值`执行语句.
`可迭代对象`包括 Array，Map，Set，String，TypedArray，arguments 对象等。
```js
// 迭代map例子
const map = new Map([["a", 1], ["b", 2], ["c", 3]]);
for (const entry of map) {
  console.log(entry);
}
// ["a", 1]
// ["b", 2]
// ["c", 3]
```
## 用途
实现迭代接口[Symbol.iterator]，自定义被迭代的数据。
```js
const iterable = {
  [Symbol.iterator]() {
    return {
      i: 0,
      next() {
        return  this.i < 3 ? { value: this.i++, done: false } : { value: undefined, done: true };
      }
    };
  }
};
for (const value of iterable) {
  console.log(value);
}
// 0
// 1
// 2
```

# ffor..in 和 for..of 的区别
无论是for...in还是for...of语句都是迭代一些东西。它们之间的主要区别在于它们的迭代方式。
1. 一个是 `key`，一个是 `value`。
* for...in 语句迭代对象除`Symbol`外的可`枚举属性`。
* for...of 语句遍历可迭代对象定义要迭代的数据。
2. 访问原型链
* `for..in` 会把从原型链上继承的`可枚举属性`也遍历出来
* `for..of` 是按对象`实现的/内置的`迭代接口来遍历，一般不会遍历到原型链上的值。


# fdefineProperty  fObject.defineProperty
Object.defineProperty() 方法会直接在一个对象上定义一个新属性，或者修改一个对象的现有属性，并返回此对象。
## 用法
接收三个参数
1. 对象本身  obj
2. 属性名   'propKey'
3. 描述对象  查看下面的例子
## 例子: 创建属性
```js
var o = {}; // 创建一个新对象
var aValue = 38;
Object.defineProperty(o, "a", {
  value : 37,   // 属性值
  writable : true,  // 值能被赋值运算符改变
  enumerable : true,  // 该属性会出现在对象的枚举属性中，可用于 for..in 和 Object.keys
  configurable : true,  // 该属性的描述符能够被改变，同时该属性也能从对应的对象上被删除。
  get: function() { return aValue; },  // 当访问该属性时，会调用此函数。该函数的返回值会被用作属性的值。
  set: function(data) { aValue = data; },  // 当属性值被修改时，会调用此函数。
});
```
## 例子: 修改属性
```js
Object.defineProperty(o, 'a', {
  value: 37,
  writable: false  // 该属性被称为“不可写的”。它不能被重新赋值。
});
```

# fmap  这是数组的map方法, 不是 Map 数据结构
## 1.讲概念
map 方法`创建一个新数组`，这个新数组由原数组中的`每个元素都调用一次提供的函数`后的返回值组成。
map 方法会给原数组中的每个元素都按顺序调用一次 callback 函数。callback 每次执行后的返回值（包括 undefined）组合起来形成一个新数组。 callback 函数只会在`有值的索引`上被调用；那些`从来没被赋过值`或者`使用 delete 删除的索引`则不会被调用。
## 2.说用途
因为map`生成一个新数组`，当你不打算使用返回的新数组却使用map是违背设计初衷的，请用`forEach`或者`for-of`替代。
## 3.注意点
map 方法`处理数组元素的范围是在 callback 方法第一次调用之前就已经确定了`。调用map方法之后追加的数组元素`不会被callback访问`。如果存在的数组元素改变了，那么传给callback的值是map访问该元素时的值。在map函数调用后但在访问该元素前，该元素被删除的话，则无法被访问到。

# fforEach
## 1.讲概念
forEach 方法对数组的每个元素执行一次给定的函数。
forEach 方法按升序为数组中含有效值的每一项执行一次 callback 函数，那些已删除或者未初始化的项将被跳过（例如在稀疏数组上）。
forEach 遍历的范围在第一次调用 callback 前就会确定。调用 forEach 后添加到数组中的项不会被 callback 访问到。如果已经存在的值被改变，则传递给 callback 的值是 forEach 遍历到他们那一刻的值。
已删除的项不会被遍历到，如果已访问的元素在迭代时被删除了，比如使用 shift，之后的元素将被跳过。
## 2.注意点
除了抛出异常以外，没有办法中止或跳出 forEach循环。如果你需要中止或跳出循环，forEach() 方法不是应当使用的工具。
若你需要提前终止循环，你可以使用：every/some/find/findIndex。
## 3.手写forEach
```js
// Production steps of ECMA-262, Edition 5, 15.4.4.18
// Reference: http://es5.github.io/#x15.4.4.18
if (!Array.prototype.forEach) {

  Array.prototype.forEach = function(callback, thisArg) {

    var T, k;

    if (this == null) {
      throw new TypeError(' this is null or not defined');
    }

    // 1. Let O be the result of calling toObject() passing the
    // |this| value as the argument.
    var O = Object(this);

    // 2. Let lenValue be the result of calling the Get() internal
    // method of O with the argument "length".
    // 3. Let len be toUint32(lenValue).
    var len = O.length >>> 0;

    // 4. If isCallable(callback) is false, throw a TypeError exception.
    // See: http://es5.github.com/#x9.11
    if (typeof callback !== "function") {
      throw new TypeError(callback + ' is not a function');
    }

    // 5. If thisArg was supplied, let T be thisArg; else let
    // T be undefined.
    if (arguments.length > 1) {
      T = thisArg;
    }

    // 6. Let k be 0
    k = 0;

    // 7. Repeat, while k < len
    while (k < len) {

      var kValue;

      // a. Let Pk be ToString(k).
      //    This is implicit for LHS operands of the in operator
      // b. Let kPresent be the result of calling the HasProperty
      //    internal method of O with argument Pk.
      //    This step can be combined with c
      // c. If kPresent is true, then
      if (k in O) {

        // i. Let kValue be the result of calling the Get internal
        // method of O with argument Pk.
        kValue = O[k];

        // ii. Call the Call internal method of callback with T as
        // the this value and argument list containing kValue, k, and O.
        callback.call(T, kValue, k, O);
      }
      // d. Increase k by 1.
      k++;
    }
    // 8. return undefined
  };
}

```

# 如何跳出 map 或 forEach 循环
map 和 forEach 不能被中断: 一旦开始就不能 break，如果想中途跳出循环，可以在遍历的外层加一个 try...catch，然后中途 throw 一个 Error。
```js
const a = [1,2,3,4,5,6];
try {
  a.forEach(v => {
    if (v === 3) {
      throw new Error('break');
      // break;  // Uncaught SyntaxError: Illegal break statement
    }
    console.log(v);
  })
} catch(e) {
  console.error(e);
}
```

# f拷贝  fcopy  fdeepClone fclone
拷贝对象分为两种情况，一种是`浅拷贝`，一种是`深拷贝`。
## f浅拷贝
`浅拷贝`指的是简单地将一个对象的属性值复制到另一个对象，如果有的属性的值为`引用`类型的话，那么会将这个引用的地址复制给对象，因此两个对象会有同一个引用类型的引用。
### 实现
浅拷贝可以使用 `Object.assign` 和 `展开语法` 来实现。
### 缺点
如果拷贝的属性是引用，无法新建一个引用，还是用的旧引用，所以拷贝之后的引用如果修改了属性，会影响到原始对象。
```js
const obj = {
  inObj: {a: 1, b: 2}
}
const clone = {...obj}   // 或  Object.assign({}, obj);
clone.inObj.a = 2;   // 原始对象也变了
console.log(obj) // {inObj: {a: 2, b: 2}}
```
## f深拷贝
为了解决`浅拷贝对象的引用影响原始对象`的问题，我们可以使用`深拷贝`的方式。
深拷贝相对浅拷贝而言，如果遇到属性值为引用类型的时候，它`新建一个引用类型`并将对应的值复制给它，因此对象获得的一个新的引用类型而不是一个原有类型的引
用。
### 实现
1. 可以用 JSON 的两个 api: `JSON.parse(JSON.stringify())` 实现深拷贝，但是由于 JSON 的对象格式比 js 的对象格式更加严格，所以如果属性值里边出现`函数`或者`Symbol类型`的值时，会转换失败。
```js
const o = { fn: function() {}, [Symbol.for('react')]: "我是Symbol值" };
const clone = JSON.parse(JSON.stringify(o));
console.log(clone);  // {}
```
2. 递归。针对 `JSON` 的问题，可以用 `递归` 实现深拷贝，具体的思路是:
遍历原始对象自身的属性，如果是原始类型直接复制，如果是引用类型，则递归地调用`深拷贝`函数，区分不同类型的对象进行处理，然后进行拷贝。
#### 简单版
```js
function deepCopy(object) {
  if (!object || typeof object !== "object") return object;

  const newObject = Array.isArray(object) ? [] : {};
  for (const key in object) {
    if (object.hasOwnProperty(key)) {
      newObject[key] =
        typeof object[key] === "object" ? deepCopy(object[key]) : object[key];
    }
  }
  return newObject;
}
```
#### 全面版
拷贝对象的所有属性
遍历属性，根据属性值:
1. 对象: 递归(根据构造函数，新建不同对象、处理，返回)
2. 非对象: 拷贝原对象的属性值
```js
function isObject(obj) {
  return typeof obj === "object" && obj !== null;
}
function cloneDeep(data, hash = new WeakMap()) {
  if (!isObject(data) || !data || !data.constructor) {
    return data
  }
  let copyData   // 存储各种类型的对象
  const Constructor = data.constructor
  switch (Constructor) {
    case RegExp:
      // 正则表达式: 用原数据新建一个正则对象  new RegExp(...原正则数据) 
      copyData = new Constructor(data)
      break
    case Date:
      // Date: 用时间戳新建一个 Date 对象
      copyData = new Constructor(data.getTime())
      break
    default:
      // 解决循环引用  (obj.circle = obj)
      // 如果遇到过这个引用，返回之前拷贝好的引用s
      // 最原始对象的引用，也在 hash 里
      if (hash.has(data)) {
        return hash.get(data)
      }
      copyData = new Constructor()
      if (Constructor === Map) {
        data.forEach((value, key) => {
          // 原始 Map 的元素，一个一个加入到 拷贝的 Map 中
          copyData.set(key, isObject(value) ? cloneDeep(value) : value)
        })
      }
      if (Constructor === Set) {
        data.forEach(value => {
          // 原始 Set 的元素，一个一个加入到 拷贝的 Set 中
          copyData.add(isObject(value) ? cloneDeep(value) : value)
        })
      }
      // 拷贝过的引用都记录一下
      // WeakMap弱引用，不计入GC的引用中，不干扰垃圾回收的判断
      hash.set(data, copyData)
  }
  // 解决 for..in 不能遍历 Symbol 属性的问题
  const symbols = Object.getOwnPropertySymbols(data)
  if (symbols && symbols.length) {
    symbols.forEach(symkey => {
      copyData[symkey] = isObject(data[symkey]) ? cloneDeep(data[symkey], hash) : data[symkey]
    })
  }
  // 遍历基本属性
  for (var key in data) {
    copyData[key] = isObject(data[key]) ? cloneDeep(data[key], hash) : data[key]
  }
  // 拷贝完成✅
  return copyData
}
```

# f== vs f===  f双等号和f三等号的区别
双等号会尝试类型转换，三等号不会尝试类型转换。

# f==
等于运算符（==）检查其两个操作数是否相等，它会尝试强制类型转换并且比较不同类型的操作数，并返回Boolean结果。
## 实现
根据 ECMA-262规范，相等运算符（`==`和`!=`）使用`抽象相等比较算法`比较两个操作数。
概括如下:
1. 如果两个操作数`都是对象`，则仅当两个操作数都`引用同一个对象`时才返回`true`。
2. 如果一个操作数是`null`，另一个操作数是`undefined`，则返回`true`。
3. 如果两个操作数是`不同类型的`，就会尝试在比较之前将它们转换为`相同类型`：
  * 当数字与字符串进行比较时，会尝试将字符串转换为数字值。
  * 如果操作数之一是`Boolean`，则将布尔操作数转换为`数字1`或`数字0`。如果是true，则转换为1。如果是 false，则转换为0。
  * 如果操作数之一是`对象`，另一个是`数字或字符串`，会先尝试使用对象的`valueOf`方法, 再尝试使用`toString`方法，将对象转换为`原始值`。
4. 如果操作数具有`相同的类型`，执行全等比较。
**总结**
如果两个都是引用，那就对比引用;
如果有一个不是引用，就尽量转成数字来比较，如果不能转成数字，就转成字符串。
**错题集**
1. 面文思海辉的时候问了`[]==[]`, 结果是啥, 我有点恍惚...答案是 false, 因为两个操作数都是对象，需要引用同一个对象才会返回`true`。

# f===
全等运算符`===`会检查它的两个操作数是否相等，并且返回一个布尔值结果。与相等运算符`==`不同，全等运算符总是认为`不同类型的操作数是不同的`。
## 实现
全等运算符（===和 !==）使用全等比较算法来比较两个操作数。
1. 如果操作数的类型不同，则返回 false。
2. 如果两个操作数都是对象，只有当它们指向同一个对象时才返回 true。
3. 如果两个操作数都为 null，或者两个操作数都为 undefined，返回 true。
4. 如果两个操作数有任意一个为 NaN，返回 false。
5. 否则，比较两个操作数的值：
  * 数字类型必须拥有相同的数值。+0 和 -0 会被认为是相同的值。
  * 字符串类型必须拥有相同顺序的相同字符。
  * 布尔运算符必须同时为 true 或同时为 false。
### 例子
```js
NaN === NaN;  // false (NaN这家伙急眼了连自己都不认识)
+0 === -0;    // true  (全等认为正负零是一样的)
```

# fObject.is
## 1.讲概念
Object.is() 方法判断两个值是否为同一个值。
## 2.说用途
`Object.is`与全等运算符`===`不相同。差别是它们对待`有符号的零`和`NaN`不同。
全等运算符`===`将数字`-0`和`+0`视为`相等`，而将`NaN`与`NaN` 视为不相等。`Object.is`刚好相反。
## 3.说实现
Object.is() 方法判断两个值是否为同一个值，如果满足以下任意条件则两个值相等：
1. 都是 undefined
2. 都是 null
3. 都是 true 或都是 false
4. 都是相同长度、相同字符、按相同顺序排列的字符串
5. 都是相同对象（意味着都是同一个对象的值引用）
6. 都是数字且
  * 都是 +0
  * 都是 -0
  * 都是 NaN
  * 都是同一个值，非零且都不是 NaN
## 4.例子
```js
// 有符号的0
Object.is(+0, -0);    // false
Object.is(0, -0);     // false
Object.is(-0, -0);    // true
Object.is(0n, -0n);   // true
// NaN
Object.is(NaN, NaN)    // true
Object.is(NaN, 0/0);   // true
```
## 4.polyfill
```js
if (!Object.is) {
  Object.defineProperty(Object, "is", {
    value: function (x, y) {
      if (x === y) {
        // 同类型并且同值
        // true: ”不等于0“ 或 "等于0但必须相同符号“
        return x !== 0 || 1 / x === 1 / y;
      } else {
        // 不同类型或不同值
        // 返回true:  x,y 都是 NaN  (Number.NaN, 0/0, NaN)
        // 返回false: 剩余所有情况
        return x !== x && y !== y;
      }
    }
  });
}
```

# fquerySelector
只返回第一个匹配的对象。
文档对象模型Document引用的**querySelector()**方法返回文档中与指定选择器或选择器组匹配的第一个 Element对象。 如果找不到匹配项，则返回 null。
```js
element = document.querySelector(selectors);
```

# fconst f常量
const 会创建一个常量，其作用域可以是全局或本地声明的块。与var变量不同，全局常量不会变为 window 对象的属性。 
const 的值是无法通过重新赋值改变的，也不能被重新声明，但这并不意味着它所持有的值是不可变的，只是变量标识符不能重新分配。例如，在引用内容是对象的情况下，可以改变对象的属性。一个常量不能和它所在作用域内的其他变量或函数拥有相同的名称。

# flet f变量
let 允许你声明一个作用域被限制在块作用域中的变量、语句或者表达式。与 var 关键字不同的是，var 声明的变量作用域是全局或者整个函数块的。 var 和 let 的另一个重要区别，let 声明的变量不会在作用域中被提升，它是在编译时才初始化。
就像 const 一样，let 不会在全局声明时（在最顶层的作用域）创建 window 对象的属性。
与 var 不同的是，let 只是开始声明，而非一个完整的表达式。这意味着你不能将单独的 let 声明作为一个代码块的主体, 这是有道理的，因为声明的变量无法被访问:
```js
if (true) let a = 1; // SyntaxError: Lexical declaration cannot appear in a single-statement context
```

# f暂时性死区 fTDZ fTemporal dead zone
从一个代码块的开始直到代码执行到声明变量的行之前，let 或 const 声明的变量都处于“暂时性死区”（Temporal dead zone，TDZ）中。

当变量处于暂时性死区之中时，其尚未被初始化，尝试访问变量将抛出 ReferenceError。当代码执行到声明变量所在的行时，变量被初始化为一个值。如果声明中未指定初始值，则变量将被初始化为 undefined。

与 var 声明的变量不同，如果在声明前访问了变量，变量将会返回 undefined。


# f变量的解构赋值 f解构赋值
解构赋值语法是一种 Javascript 表达式。通过解构赋值，可以将属性/值从对象/数组中取出，赋值给其他变量。
## 只要某种数据结构具有 Iterator 接口，都可以采用数组形式的解构赋值。
* 数组:
`let [a, b, c] = [1, 2, 3];`
* Set:
`let [x, y, z] = new Set(['a', 'b', 'c']);`
如果解构不成功，变量的值就等于undefined。
### 将剩余数组赋值给一个变量
当解构一个数组时，可以使用剩余模式，将数组剩余部分赋值给一个变量。
```js
var [a, ...rest] = [1, 2, 3];
console.log(a); // 1
console.log(rest); // [2, 3]
```
注意：如果剩余元素右侧有逗号，会抛出 SyntaxError，因为剩余元素必须是数组的最后一个元素。
## 解构赋值允许指定默认值
`let [foo = true] = [];`
如果默认值是一个表达式，那么这个表达式是惰性求值的，即只有在用到的时候，才会求值。
```js
function f() {
  console.log('aaa');
}
let [x = f()] = [1];
```
# 对象的解构赋值
`let { foo, bar } = { foo: 'aaa', bar: 'bbb' };`
对象的解构与数组有一个重要的不同。数组的元素是按次序排列的，变量的取值由它的位置决定；而对象的属性没有次序，变量必须与属性同名，才能取到正确的值。
## 对象的解构也可以指定默认值
`var {x, y = 5} = {x: 1};`
# 字符串的解构赋值
```js
const [a, b, c, d, e] = 'hello';
a // "h"
b // "e"
c // "l"
d // "l"
e // "o"
```
# 数值和布尔值的解构赋值
```js
let {toString: s} = 123;
s === Number.prototype.toString // true
```

# fSet
Set 类似于数组，但是成员的值都是唯一的，没有重复的值。
Set对象是值的集合，你可以按照插入的顺序迭代它的元素。Set 中的元素只会出现一次，即 Set 中的元素是唯一的。
因为 Set 中的值总是唯一的，所以需要判断两个值是否相等。在 ECMAScript 规范的早期版本中，这不是基于和===操作符中使用的算法相同的算法。具体来说，对于 Set，+0（+0 严格相等于 -0）和 -0 是不同的值。然而，在 ECMAScript 2015 规范中这点已被更改。有关详细信息，请参阅浏览器兼容性表中的 “Key equality for -0 and 0”。
另外，NaN 和 undefined 都可以被存储在 Set 中，NaN 之间被视为相同的值（NaN 被认为是相同的，尽管 NaN !== NaN）。
```js
const set = new Set([1, 2, 3, 4, 4]);  // Set(3) {1, 2, 3}
[...set]  // [1, 2, 3, 4]
```
## 用途
### 数组去重
```js
const array = [2,3,4,4,2,3,3,4,4,5,5,6,6,7,5,32,3,4,5]
console.log([...new Set(array)])  // [2, 3, 4, 5, 6, 7, 32]
console.log(Array.from(new Set(array)))  // [2, 3, 4, 5, 6, 7, 32]
```
## API
size       返回Set实例的成员总数。
add(v)     添加某个值，返回 Set 结构本身。
delete(v)  删除某个值，返回一个布尔值，表示删除是否成功。
has(v)     返回一个布尔值，表示该值是否为Set的成员。
clear()    清除所有成员，没有返回值。
keys       返回键名的遍历器 (keys和valus方法完全一致)
values     返回键值的遍历器
entries    返回键值对的遍历器
forEach    使用回调函数遍历每个成员

# fWeakSet
WeakSet 对象允许我们将`弱引用对象`存储在一个集合中。
WeakSet 对象是一些对象值的集合，并且其中的每个对象值都只能出现一次。在WeakSet的集合中是唯一的。
## 它和 Set 对象的区别有两点：
1. 与Set相比，WeakSet 只能是`对象`的集合，而不能是任何类型的任意值。
2. WeakSet持弱引用：集合中对象的引用为弱引用。 如果没有其他的对WeakSet中对象的引用，那么这些对象会被当成垃圾回收掉。 这也意味着 WeakSet 中没有存储当前对象的列表。 正因为这样，WeakSet 是不可枚举的。 (弱引用:垃圾回收机制不会考虑WeakSet对该对象的引用)
## 用途
### 检测循环引用
递归调用自身的函数需要一种通过跟踪哪些对象已被处理，来应对循环数据结构的方法。
为此，WeakSet 非常适合处理这种情况：
```js
// 对 传入的 subject 对象 内部存储的所有内容执行回调
function execRecursively(fn, subject, _refs = null){
	if(!_refs)
		_refs = new WeakSet();
	// 避免无限递归
	if(_refs.has(subject))
		return;
	fn(subject);
	if("object" === typeof subject){
		_refs.add(subject);
		for(let key in subject)
			execRecursively(fn, subject[key], _refs);
	}
}
const foo = {
	foo: "Foo",
	bar: {
		bar: "Bar"
	}
};
foo.bar.baz = foo; // 循环引用！
execRecursively(obj => console.log(obj), foo);
```
在第一次运行时创建WeakSet，并将其与每个后续函数调用一起传递（使用内部参数_refs）。 对象的数量或它们的遍历顺序无关紧要，因此，WeakSet 比Set更适合（和执行）跟踪对象引用，尤其是在涉及大量对象时。

# fMap
Map 对象保存键值对，并且能够记住键的原始插入顺序。任何值（对象或者基本类型）都可以作为一个键或一个值。
一个 Map 对象在迭代时会根据对象中元素的插入顺序来进行——一个 for...of 循环在每次迭代后会返回一个形式为 [key，value] 的数组。
## 用途
1. 用于算法，提供高性能的增删改查。
2. 方便迭代，Map 本身就实现了迭代接口，而且 Map 的键是有序的。
## 键的相等
* 键的比较基于零值相等算法。
与同值相等类似，不过会认为 +0 与 -0 相等。
* NaN 是与 NaN 相等的（虽然 NaN !== NaN），剩下所有其它的值是根据 === 运算符的结果判断是否相等。
## Objects 和 maps 的比较
### 共性
Object 和 Map 类似的是，它们都允许你按键存取一个值、删除键、检测一个键是否绑定了值。
因此（并且也没有其他内建的替代方式了）过去我们一直都把对象当成 Map 使用。
### 区别
不过 Map 和 Object 有一些重要的区别，在下列情况中使用 Map 会是更好的选择:
1. 排除意外的键
Map 默认情况不包含任何键。只包含显式插入的键。
一个 Object 有一个原型，原型链上的键名有可能和你自己在对象上的设置的键名产生冲突。
2. 键的类型
一个 Map 的键可以是任意值，包括函数、对象或任意基本类型。
一个 Object 的键必须是一个 String 或是 Symbol。
3. 键的顺序
Map 中的键是有序的。因此，当迭代的时候，一个 Map 对象以插入的顺序返回键值。
虽然 Object 的键目前是有序的，但并不总是这样，而且这个顺序是复杂的。因此，最好不要依赖属性的顺序。
4. Size	
Size	Map 的键值对个数可以轻易地通过 size 属性获取。
Object 的键值对个数只能手动计算.
5. 迭代
Map 是 可迭代的 的，所以可以直接被迭代。
Object 没有实现 迭代协议，所以使用 JavaSctipt 的 for...of 表达式并不能直接迭代对象。
6. 性能
Map 在频繁增删键值对的场景下表现更好。
Object 在频繁添加和删除键值对的场景下未作出优化。
## 缺点
Map通过使其四个 API 方法共用两个数组（一个存放键，一个存放值）来实现。这样会有2个缺点:
1. 赋值和搜索操作都是 O(n) 的时间复杂度（n 是键值对的个数），因为这两个操作都需要遍历全部整个数组来进行匹配。
2. 可能会导致内存泄漏，因为数组会一直引用着每个键和值。这种引用使得垃圾回收算法不能回收处理他们，即使没有其他任何引用存在了。

# fWeakMap
**和Map的区别**
1. 键必须是对象
2. WeakMap 的键所指的对象，不计入垃圾回收机制中。如果该对象的所有引用都失去了，只剩 WeakMap 的引用，那么垃圾回收器可以将它所占内存回收。
**讲概念**
WeakMap 对象是一组键/值对的集合，其中的键是弱引用的。其键必须是对象，而值可以是任意的。
## 为什么要使用 WeakMap？ (用途)
在 JavaScript 里，map API 可以 通过使其四个 API 方法共用两个数组（一个存放键，一个存放值）来实现。给这种 map 设置值时会同时将键和值添加到这两个数组的末尾。从而使得键和值的索引在两个数组中相对应。当从该 map 取值的时候，需要遍历所有的键，然后使用索引从存储值的数组中检索出相应的值。

但这样的实现会有两个很大的缺点：
1. 赋值和搜索操作都是 O(n) 的时间复杂度（n 是键值对的个数），因为这两个操作都需要遍历全部整个数组来进行匹配。
2. 可能会导致内存泄漏，因为数组会一直引用着每个键和值。这种引用使得垃圾回收算法不能回收处理他们，即使没有其他任何引用存在了。

相比之下，原生的 WeakMap 持有的是每个键对象的“弱引用”，这意味着在没有其他引用存在时垃圾回收能正确进行。原生 WeakMap 的结构是特殊且有效的，其用于映射的 key _只有_在其没有被回收时才是有效的。正由于这样的弱引用，WeakMap 的 key 是不可枚举的（没有方法能给出所有的 key）。如果 key 是可枚举的话，其列表将会受垃圾回收机制的影响，从而得到不确定的结果。因此，如果你想要这种类型对象的 key 值的列表，我们应该使用 Map。
## 优点
1. 原生的 WeakMap 持有的是每个键对象的“弱引用”，这意味着在没有其他引用存在时垃圾回收能正确进行。
## 缺点
1. WeakMap 的 key 是不可枚举的, 如果 key 是可枚举的话，其列表将会受垃圾回收机制的影响。
## API
* delete(k)
* has(k)
* set(k,v)
* get(k)
## 实现 clear 方法
```js
class ClearableWeakMap {
  constructor(init) {
    this._wm = new WeakMap(init);
  }
  clear() {
    this._wm = new WeakMap();
  }
  delete(k) {
    return this._wm.delete(k);
  }
  get(k) {
    return this._wm.get(k);
  }
  has(k) {
    return this._wm.has(k);
  }
  set(k, v) {
    this._wm.set(k, v);
    return this;
  }
}
```

# fPromise   
Promise 是一个对象，它代表了一个异步操作的最终完成或者失败。
Promise可以看成一个容器，里面保存着某个未来才会结束的事件（通常是一个异步操作）的结果。从语法上说，Promise 是一个对象，从它可以获取异步操作的消息。Promise 提供统一的 API，各种异步操作都可以用同样的方法进行处理。
## 特点
* 链式调用
连续执行两个或者多个异步操作，在上一个操作执行成功之后，开始下一个的操作，并带着上一步操作所返回的结果。
* 错误传递
通常，一遇到异常抛出，浏览器就会顺着 Promise 链寻找下一个 onRejected 失败回调函数或者由 .catch() 指定的回调函数。
* 对象的状态不受外界影响  (fPromise状态)
Promise对象代表一个异步操作，有三种状态：
1. pending（进行中）
2. fulfilled（已成功）
3. rejected（已失败）。
只有异步操作的结果，可以决定当前是哪一种状态，任何其他操作都无法改变这个状态。这也是Promise这个名字的由来，它的英语意思就是“承诺”，表示其他手段无法改变。
* 一旦状态改变，就不会再变，任何时候都可以得到这个结果
Promise对象的状态改变，只有两种可能：从pending变为fulfilled和从pending变为rejected。只要这两种情况发生，状态就凝固了，不会再变了，会一直保持这个结果，这时就称为 resolved（已定型）。如果改变已经发生了，你再对Promise对象添加回调函数，也会立即得到这个结果。这与事件（Event）完全不同，事件的特点是，如果你错过了它，再去监听，是得不到结果的。
## 为什么 ES6 要推出 Promise?
查看优点
## 优点
1. 有了Promise对象，就可以将异步操作以同步操作的流程表达出来，避免了层层嵌套的回调函数。
2. Promise 使得错误可以集中在一个地方处理。
3. Promise对象提供统一的接口，使得控制异步操作更加容易。
## 缺点
1. 无法取消Promise，一旦新建它就会立即执行，无法中途取消。
2. 如果不设置回调函数，Promise内部抛出的错误，不会反应到外部。
3. 当处于pending状态时，无法得知目前进展到哪一个阶段（刚刚开始还是即将完成）。

## fPromise.all fall  全部完成才完成，一个失败就失败
Promise.all()方法用于将多个 Promise 实例，包装成一个新的 Promise 实例。
Promise.all()方法接受一个数组作为参数，p1、p2、p3都是 Promise 实例，如果不是，就会先调用下面讲到的Promise.resolve方法，将参数转为 Promise 实例，再进一步处理。另外，Promise.all()方法的参数可以不是数组，但必须具有 Iterator 接口，且返回的每个成员都是 Promise 实例。
```js
const p = Promise.all([p1, p2, p3]);
```
p的状态由p1、p2、p3决定，分成两种情况:
（1）只有p1、p2、p3的状态都变成fulfilled，p的状态才会变成fulfilled，此时p1、p2、p3的返回值组成一个数组，传递给p的回调函数。
（2）只要p1、p2、p3之中有一个被rejected，p的状态就变成rejected，此时第一个被reject的实例的返回值，会传递给p的回调函数。

如果作为参数的 Promise 实例，自己定义了catch方法，那么它一旦被rejected，并不会触发Promise.all()的catch方法。

## fPromise.race frace  一个成功就成功，一个失败就失败
Promise.race()方法是将多个 Promise 实例，包装成一个新的 Promise 实例。比如:
```js
const p = Promise.race([p1, p2, p3]);
```
只要p1、p2、p3之中有一个实例率先改变状态，p的状态就跟着改变。那个率先改变的 Promise 实例的返回值，就传递给p的回调函数。
Promise.race()方法的参数与Promise.all()方法一样，如果不是 Promise 实例，就会先调用下面讲到的Promise.resolve()方法，将参数转为 Promise 实例，再进一步处理。
### 使用 Promise.race 模拟HTTP请求超时报错  f超时报错
把原始请求的Promise和包裹定时器的Promise一起传给Promise.race，
如果指定时间内没有获得结果，就将 Promise 的状态变为rejected，否则变为 fulfilled。
```js
const p = Promise.race([
  fetch('/resource-that-may-take-a-while'),
  new Promise(function (resolve, reject) {
    setTimeout(() => reject(new Error('request timeout')), 5000)
    // throw new Error('test'); 也行
  })
]);
p
.then(console.log)
.catch(console.error);
```

## fPromise.allSettled fallSettled   拿到全部成功失败的数组
Promise.allSetttled 用来确定一组异步操作是否都结束了（不管成功或失败）。所以，它的名字叫做”Settled“，包含了”fulfilled“和”rejected“两种情况。

它接受一个数组作为参数，数组的每个成员都是一个 Promise 对象，并返回一个新的 Promise 对象。返回的 Promise 对象一旦发生状态变更，状态总是fulfilled，不会变成rejected。状态变成fulfilled后，它的回调函数会接收到一个数组作为参数，对应前面数组的每个 Promise 对象。

数组里每个成员是一个对象，对象的status属性的值只可能是字符串fulfilled或字符串rejected，用来区分异步操作是成功还是失败。如果是成功（fulfilled），对象会有value属性，如果是失败（rejected），会有reason属性，对应两种状态时前面异步操作的返回值。
```js
const resolved = Promise.resolve(42);
const rejected = Promise.reject(-1);
const allSettledPromise = Promise.allSettled([resolved, rejected]);
allSettledPromise.then(function (results) {
  console.log(results);
});
// [
//    { status: 'fulfilled', value: 42 },
//    { status: 'rejected', reason: -1 }
// ]
```

# f0.1+0.2 为什么不等于 0.3? 如何让其相等？ f浮点数
```js
console.log(0.1+0.2);  // 0.30000000000000004
console.log((0.1+0.2).toFixed(1))  // 0.3  四舍五入，取一位小数
```
小数在计算机中是用二进制表示的，具体到JS是用双精度浮点数, 它是64位。

以0.1为例，它转化为 JS 中 64 位二进制的过程是:

## 第一步 用二进制表达
1. 0.1的整数部分用二进制表达为0。
2. 0.1的小数部分 是进行一个循环：每次乘以 2，然后看看是否超过 1：
   2.1 如果超过 1，我们就记下二进制位 1，并把结果减去 1，然后进一步循环操作。
   2.2 如果没超过 1，就记下二进制位 0。

算式            是否超过1     二进制位     余数
0.1*2 = 0.2       否          0         0.2
0.2*2 = 0.4       否          0         0.4
0.4*2=0.8         否          0         0.8
0.8*2=1.6         是          1       1.6-1=0.6
0.6*2=1.2         是          1       1.2-1=0.2
0.2*2 = 0.4       否          0         0.4
0.4*2=0.8         否          0         0.8
0.8*2=1.6         是          1       1.6-1=0.6
0.6*2=1.2         是          1       1.2-1=0.2
…
把二进制位的结果取下来，得到的结果是  0.000110011…，后面的0011会无限循环下去。
拼接整数和小数部分，就得到 0.000110011… (0011无限循环)这样的结果。

## 第二步 改写为科学计数法，计算 s,e,f
1往前挪4位，得到
1.10011001100… x 10^-4

根据公式
(-1)^s * 1.f * 2^e

由于是正数，所以符号位 s=0   (1位)
指数位e=-4+1023(1023是IEEE定义的偏移量)=1019  (10位) (二进制 1111111011)
有效位f=10011001100… (100[1100循环], 53位)

## 第三步 最后的二进制表达 
根据s,f,e，得到最后的二进制表达:
0        1111111011   1001100110011001100110011001100110011001100110011001
s(1位)   e(10位)        f(53位)
此时0.1已经不是精确的0.1了，0.2也是一样的，所以最后相加的结果不是精确的0.3，而是一个近似值。

## 判断 0.1+0.2 和 0.3 相等
1. 可以用 Number.EPSILON 允许误差范围内的相等，如果 0.1+0.2-0.3小于这个范围，就认为是相等的
2. 可以用toFixed得到精确小数位的结果，比如(0.1+0.2).toFixed(1)

# fNumber.EPSILON
Number.EPSILON 表示 `Number可表示的大于 1 的最小的浮点数`和`1`的差值。它接近于 2^-52。
## 用途
测试浮点数是否相等
```js
function isEqual(x,y) {
  return Math.abs(x-y) < Number.EPSILON;
}
// isEqual(0.1+0.2, 0.3)  // true
```

# f判断一个对象是否是数组  fisArray  fArray.isArray  f判断数组的方式有哪些
五种。
## 1. Object.prototype.toString.call  准确✅
```js
Object.prototype.toString.call(obj) === '[object Array]';
```
## 2. 通过ES6的 Array.isArray  准确✅
```js
// 当检测 Array 实例时，Array.isArray 优于 instanceof，因为 Array.isArray 能检测 iframes。
Array.isArray(obj);
```
## 3. 通过 instanceof 做判断  不准确❌
```js
// instanceof 运算符用于检测构造函数的 prototype 属性是否出现在某个实例对象的原型链上。
// 这种方法的缺点:
// 1. obj 是跨 iframe 取的值时，不是本 window 的 Array 构造的，会返回 false，造成误判。  
// 2. obj.__proto__ 可能被修改, 所以可能造成误判。
obj instanceof Array; 
```
## 4. 检查对象的__proto__  不准确❌
```js
obj.__proto__ === Array.prototype;  // obj.__proto__ 可能被修改, 所以可能造成误判。
```
## 5. Array.prototype.isPrototypeOf   不准确❌
```js
// isPrototypeOf() 方法用于测试一个对象 (Array.prototype) 是否存在于另一个对象 (obj) 的原型链上。
Array.prototype.isPrototypeOf(obj);   // obj.__proto__ 可能被修改, 所以可能造成误判。
```

# f操作数组的方法有哪些? f数组方法
## 增
* fpush     从尾插入
* funshift  从头插入
## 删
* fpop      从尾弹出
* fshift    从头弹出
## 改
* fsplice   index,deleteCount,...items  从index开始删deleteCount个，然后在index处插入各个item(items)
* fsort     改变原数组为有序。默认排序顺序是: 元素按照转换为字符串的各个字符的 Unicode 位点进行排序。(Beluga,Blue,Humpback)
* freverse  颠倒数组中元素的位置，改变原数组，并返回该数组的引用。
## 查
* find
* findIndex
* filter
* indexOf

# fArray.prototype.slice fslice
slice() 方法返回一个新的数组，这个数组是一个由 begin 和 end 决定的原数组的浅拷贝（包括 begin，不包括end）。原始数组不会被改变。
## 注意浅拷贝
slice 不会修改原数组，只会返回一个`浅拷贝`了原数组中的元素的一个新数组。如果拷贝的元素是个对象引用（不是实际的对象），slice 会拷贝这个对象引用到新的数组里。两个对象引用都引用了同一个对象。如果被引用的对象发生改变，则新的和原来的数组中的这个元素也会发生改变。
## 例子
```js
// slice 方法可以用来将一个类数组（Array-like）对象/集合转换成一个新数组。
// 只需将该方法绑定到这个对象上。 
// 函数中的 arguments 就是一个类数组对象。
function list() {
  return Array.prototype.slice.call(arguments);
}
var list1 = list(1, 2, 3); // [1, 2, 3]
```

# fArray.prototype.splice fsplice
splice() 方法通过删除或替换现有元素或者原地添加新的元素来修改数组，并以数组形式返回被修改的内容。此方法会改变原数组。
## 参数
1. start
指定修改的开始位置（从 0 计数）。如果超出了数组的长度，则从数组末尾开始添加内容；如果是负值，则表示从数组末位开始的第几位（从 -1 计数，这意味着 -n 是倒数第 n 个元素并且等价于 array.length-n）；如果负数的绝对值大于数组的长度，则表示开始位置为第 0 位。
2. deleteCount (可选)
整数，表示要移除的数组元素的个数。
* 如果 deleteCount 大于 start 之后的元素的总数，则从 start 后面的元素都将被删除（含第 start 位）。
* 如果 deleteCount 被省略了，或者它的值大于等于array.length - start(也就是说，如果它大于或者等于start之后的所有元素的数量)，那么start之后数组的所有元素都会被删除。
* 如果 deleteCount 是 0 或者负数，则不移除元素。这种情况下，至少应添加一个新元素。
3. item1, item2, ... (可选)
要添加进数组的元素，从start 位置开始。如果不指定，则 splice() 将只删除数组元素。
## 返回值
由被删除的元素组成的一个数组。如果只删除了一个元素，则返回只包含一个元素的数组。如果没有删除元素，则返回空数组。
## 例子
```js
// 删除数组的最后一个元素
var array = ['angel', 'clown', 'mandarin', 'sturgeon'];
var removed = array.splice(array.length-1, 1);
// 运算后的 array: ["angel", "clown", "mandarin"]
// 被删除的元素: ["sturgeon"]
```
```js
// 从索引 2 的位置开始删除所有元素
var myFish = ['angel', 'clown', 'mandarin', 'sturgeon'];
var removed = myFish.splice(2);
// 运算后的 myFish: ["angel", "clown"]
// 被删除的元素: ["mandarin", "sturgeon"]
```
```js
// 从索引 0 的位置开始删除 2 个元素，插入"parrot"、"anemone"和"blue"
var myFish = ['angel', 'clown', 'trumpet', 'sturgeon'];
var removed = myFish.splice(0, 2, 'parrot', 'anemone', 'blue');
// 运算后的 myFish: ["parrot", "anemone", "blue", "trumpet", "sturgeon"]
// 被删除的元素: ["angel", "clown"]
```

# fArray的ES6扩展  fES6数组  fES6Array
* Array.prototype.sort()
* Array.of(...args)
* Array.prototype.includes(item)
* Array.prototype.flat(depth) / Array.prototype.flatMap()

## fArray.prototype.sort的稳定性 fsort
常见的排序算法之中，插入排序、合并排序、冒泡排序等都是稳定的，堆排序、快速排序等是不稳定的。不稳定排序的主要缺点是，多重排序时可能会产生问题。
假设有一个姓和名的列表，要求按照“姓氏为主要关键字，名字为次要关键字”进行排序。开发者可能会先按名字排序，再按姓氏进行排序。
如果排序算法是稳定的，这样就可以达到“先姓氏，后名字”的排序效果。如果是不稳定的，就不行。
早先的 ECMAScript 没有规定`Array.prototype.sort()`的默认排序算法是否稳定，留给浏览器自己决定，这导致某些实现是不稳定的。`ES2019`明确规定，`Array.prototype.sort()`的默认排序算法必须稳定。这个规定已经做到了，现在 JavaScript 各个主要实现的默认排序算法都是稳定的。

## fArray.of 
Array.of()方法用于将一组值，转换为数组。
```js
Array.of(3, 11, 8) // [3,11,8]
Array.of(3) // [3]
Array.of(3).length // 1
```
### 用途
这个方法的主要目的，是弥补数组构造函数Array()的不足。因为参数个数的不同，会导致Array()的行为有差异。
```js
Array() // []
Array(3) // [, , ,]
Array(3, 11, 8) // [3, 11, 8]
```
上面代码中，Array()方法没有参数、一个参数、三个参数时，返回的结果都不一样。只有当参数个数不少于 2 个时，Array()才会返回由参数组成的新数组。参数只有一个正整数时，实际上是指定数组的长度。
Array.of()基本上可以用来替代Array()或new Array()，并且不存在由于参数不同而导致的重载。它的行为非常统一。
```js
Array.of() // []
Array.of(undefined) // [undefined]
Array.of(1) // [1]
Array.of(1, 2) // [1, 2]
```
Array.of()总是返回参数值组成的数组。如果没有参数，就返回一个空数组。
Array.of()方法可以用下面的代码模拟实现。
```js
function ArrayOf(){
  return [].slice.call(arguments);
}
```

# Array.prototype.includes fincludes
includes() 方法用来判断一个数组是否包含一个指定的值，根据情况，如果包含则返回 true，否则返回 false。
## 用法
接收2个参数。
第一个是需要查找的元素值。
第二个是fromIndex。从fromIndex 索引处开始查找 value。如果为负值，则按升序从 array.length + fromIndex 的索引开始搜（即使从末尾开始往前跳 fromIndex 的绝对值个索引，然后往后搜寻）。默认为 0。
```js
[1, 2, 3].includes(2);     // true
[1, 2, 3].includes(4);     // false
[1, 2, 3].includes(3, 3);  // false
[1, 2, 3].includes(3, -1); // true
[1, 2, NaN].includes(NaN); // true
```
## 用途
没有该方法之前，我们通常使用数组的 Array.prototype.indexOf 方法，检查是否包含某个值。
indexOf方法有两个缺点，一是不够语义化，它的含义是找到参数值的第一个出现位置，所以要去比较是否不等于-1，表达起来不够直观。二是，它内部使用严格相等运算符（===）进行判断，这会导致对NaN的误判。includes使用的是不一样的判断算法，就没有这个问题。
```js
[NaN].indexOf(NaN) === -1);  // true  结果没有 NaN ❌
[NaN].includes(NaN);  // true 结果有 NaN ✅
```

# Array.prototype.flat fflat
flat(depth) 方法会按照一个可指定的深度递归遍历数组，并将所有元素与遍历到的子数组中的元素合并为一个新数组返回。
不会改变原数组。
## 参数
* depth
指定要提取嵌套数组的结构深度，默认值为 1。
## 扁平化嵌套数组
```js
console.log([0, 1, 2, [3, 4]].flat());  // [0, 1, 2, 3, 4]
console.log([0, 1, 2, [[[3, 4]]]].flat(4));  // [0, 1, 2, [3, 4]]
[1, 2, [3, 4, [5, 6, [7, [9, 10]]]]];.flat(Infinity);  // 使用 Infinity，可展开任意深度的嵌套数组 [1, 2, 3, 4, 5, 6, 7, 9, 10]
```
## 扁平化移除了数组空项
```js
[1, 2, , 4, 5].flat();  // [1, 2, 4, 5]
```
## 实现 flat
### 展开一层
```js
// 1. reduce 与 concat
arr.flat(1);
arr.reduce((arr, cur) => arr.concat(cur), []);
```
```js
// 2. 扩展运算符
const flattened = arr => [].concat(...arr);
```
### 展开多层
```js
// reduce + concat + isArray + recursivity
// 使用 reduce、concat 和递归展开无限多层嵌套的数组
var arr1 = [1,2,3,[1,2,3,4, [2,3,4]]];
function flatDeep(arr, d = 1) {
   return d > 0 ? arr.reduce((acc, val) => acc.concat(Array.isArray(val) ? flatDeep(val, d - 1) : val), [])
                : arr.slice();
};
flatDeep(arr1, Infinity);
// [1, 2, 3, 1, 2, 3, 4, 2, 3, 4]
```

# Array.prototype.flatMap fflatMap
flatMap() 方法首先使用`map`映射每个元素，然后使用`flat`将结果压缩成一个新数组。如同 arr.map(...args).flat(1)，但是它比这种连续调两个API的方式效率高一些。
```js
const arr = ["it's Sunny in", "", "California"];
arr.flatMap();  // ["it's", 'Sunny', 'in', '', 'California']
// 相当于
arr.map(x => x.split(" ")).flat(1);  // ["it's", 'Sunny', 'in', '', 'California']
```

# f异步加载JS脚本 f脚本 fJS脚本
## JS脚本异步加载怎么做？
在 script 标签里加 async 或者 defer 属性。
### fasync
并行请求JS脚本，不阻塞浏览器解析页面，JS脚本下载完成后，立即执行。
### fdefer
并行请求JS脚本，不阻塞浏览器解析页面，`DOM完成解析`后，触发`DOMContentLoaded`事件前，执行JS脚本。

# 给 script 加 ftype=module 有什么作用？
将type属性设为module，告诉浏览器知道这是一个 ES6 模块。浏览器对于带有type="module"的`script`都是异步加载，不会造成堵塞浏览器，即等到整个页面渲染完，再执行模块脚本，等同于打开了`script`标签的defer属性。如果网页有多个`<script type="module">`，它们会按照在页面出现的顺序依次执行。
`script`标签的async属性也可以打开，这时只要加载完成，渲染引擎就会中断渲染立即执行。执行完成后，再恢复渲染。
```html
<script type="module" src="./foo.js"></script>
<!-- 等同于 -->
<script type="module" src="./foo.js" defer></script>
```
### 特点
对于外部的模块脚本（上例是foo.js），有几点需要注意:
1. 代码是在模块作用域之中运行，而不是在全局作用域运行。模块内部的顶层变量，外部不可见。
2. 模块脚本自动采用严格模式，不管有没有声明use strict。
3. 模块之中，可以使用import命令加载其他模块（.js后缀不可省略，需要提供绝对 URL 或相对 URL），也可以使用export命令输出对外接口。
4. 模块之中，顶层的this关键字返回undefined，而不是指向window。也就是说，在模块顶层使用this关键字，是无意义的。
5. 同一个模块如果加载多次，将只执行一次。

# f模块化 fJS模块化
JS 模块化主要分两种，一种是 ES6 Module, 一种是 CommonJS。
## fCommonJS
`CommonJS`以`require`为输入，以`module.exports`为输出，主要用在服务端nodejs使用, 它是`运行时`加载的，输出的是`对模块的拷贝`，这意味着两点:
1. 它不能 Tree-Shaking
2. 一旦输出一个值，模块内部的变化就影响不到这个输出值了
## fES6 Module
ES6 Module 是浏览器和服务器通用的模块解决方案。它以`import`为输入，以`export`为输出。
`ESM`是对模块的`引⽤`，即`ESM`只读，不能改变其值，也就是指针指向不能变，类似`const`。
`ESM``编译时`就能确定模块的依赖关系，以及输入和输出的变量，所以能够进行静态分析，使用 Tree-Shaking 进行摇树优化。
## fCommonJS 和 fESM 的异同
同: `CommonJS`和`ESM`都可以对引⼊的对象的属性进⾏赋值，即对对象内部属性的值进⾏改变。
异: 它们有三个重大差异:
1. CommonJS 模块输出的是一个值的拷贝，可以改变；ES6 模块输出的是值的引用，是只读的，不能改变。
2. CommonJS 模块是运行时加载，ES6 模块是编译时输出接口。
3. CommonJS 模块的require()是同步加载模块，ES6 模块的import命令是异步加载，有一个独立的模块依赖的解析阶段。
## 扩展
其他还有一些用在浏览器端的模块化解决方案，如 AMD(require.js), CMD(sea.js, define语法), UMD(IIFE), 但不是很常用。

# fES6新特性
* let, const (查看 fconst)
* 变量的解构赋值 (查看 f解构赋值)
* Set, Map 新数据结构 (查看 fSet, fWeakSet, fMap, fWeakMap)
* Promise 对象 (查看 fPromise)
* 数组的扩展 (查看 fArray的ES6扩展)
* 箭头函数 (查看 f箭头函数)
* Proxy (查看 fProxy)
* Symbol (查看 fSymbol)
## fES6 概念
ES6 既是一个历史名词，也是一个泛指，含义是 5.1 版以后的 JavaScript 的下一代标准，涵盖了 ES2015、ES2016、ES2017 等等，而 ES2015 则是正式名称，特指该年发布的正式版本的语言标准。


# fProxy
**讲概念**
Proxy 对象用于创建一个对象的代理，从而实现基本操作的拦截和自定义（如属性查找、赋值、枚举、函数调用等）。
**用法**
1. Proxy 接收一个 target 和 一个 handler，返回一个代理对象。
2. target 是一个使用 Proxy 包装的目标对象（可以是任何类型的对象，包括原生数组，函数，甚至另一个代理）。
3. handler 也是一个对象，不过这个对象的 value 通常是函数, key 是一批特定属性比如 get, set, has 等。
**例子1 has**
```js
var p = new Proxy({}, {
  has: function(target, prop) {
    console.log('called: ' + prop);
    return true;
  }
});
// "called: a"
// true
console.log('a' in p); 
```
**例子2 get/set**
```js
const products = new Proxy({
  browsers: ['Internet Explorer', 'Netscape']
}, {
  get: function(obj, prop) {
    // 附加一个属性
    if (prop === 'latestBrowser') {
      return obj.browsers[obj.browsers.length - 1];
    }
    // 默认行为是返回属性值
    return obj[prop];
  },
  set: function(obj, prop, value) {
    // 附加属性
    if (prop === 'latestBrowser') {
      obj.browsers.push(value);
      return;
    }
    // 如果不是数组，则进行转换
    if (typeof value === 'string') {
      value = [value];
    }
    // 默认行为是保存属性值
    obj[prop] = value;
    // 表示成功
    return true;
  }
});
console.log(products.browsers); // ['Internet Explorer', 'Netscape']
products.browsers = 'Firefox';  // 如果不小心传入了一个字符串
console.log(products.browsers); // ['Firefox'] <- 也没问题，得到的依旧是一个数组
products.latestBrowser = 'Chrome';
console.log(products.browsers);      // ['Firefox', 'Chrome']
console.log(products.latestBrowser); // 'Chrome'
```


# frouter  react-router 
**讲概念**
1. React Router 分为 History Router 和 Hash Router。
**说原理** [f路由原理]
Router 路由原理分为 2 部分, 1 个是监听路由注册回调, 1 个是改变路由以后触发回调。
## 监听路由
1. History路由 window 对象上的 popstate 事件 `window.addEventListener('popstate', fn)`。
2. Hash路由 window 对象上的 hashchange 事件 `window.addEventListener('hashchange', fn)`。
3. react-router-dom 使用了一个 history.js 的库，这个库也是基于这个浏览器的 history 对象封装而成。
执行 history.js 的 listen 方法，保存事件回调, 当 history.js 提供的 push 方法 (原生历史路由的history.pushState 和 哈希模式在页面切换路由) 执行时触发。
## 改变路由触发回调
1. 在 浏览器前进/后退按钮, 执行 history.back/forward/go 造成地址栏改变时触发 popstate 和 hashchange 事件。
2. 用户点击 React Router 提供的 Link 元素来切换路由, 执行 history 库的 push 方法, 
  - 如果是历史路由会先执行 window.history.pushState 保存历史记录，
  - 如果是哈希路由会先改变 window.location.hash 的值。
  然后执行 history.js 的 listen 保存的事件回调 -> setState -> 切换组件。


# History路由 vs 哈希路由  f路由区别  frouter区别   http://www.abc.com/#/id  http://abc.com/user/id
1. 在URL外观上, 哈希路由有'#', 而History路由没有'#'比较美观。       
2. 当我们刷新页面时，哈希路由会加载到`井号锚点`对应的位置, 哈希值不会出现在HTTP请求中, 是否加对后端是没有影响的;
   但是对于 history 路由, 如果后端没有处理这个 path ([scheme]://[domain][path]) 的话, 是会报 404 状态码的。
3. 在兼容性方面, 哈希路由支持低版本的浏览器, 而 history 是 HTML5 新增的 API，需要浏览器支持 HTML5。 [fHTML5支持]


# History路由404 后端如何配置
后端这个我不太熟悉，但是我可以简单说一下想法，比如在 koa 里自定义一个中间件，判断请求的 path 是否是 History路由，如果是就特殊处理一下，比如返回根目录下的 index.html 这样。 [fhistory中间件]
```js
const Koa = require('koa');
const Router = require('@koa/router');
const app = new Koa();
const router = new Router();  // router也是一个中间件

app.use(cors()); //允许跨域
app.use(body({ multipart: true })) //获取post请求体中间件
app.use(async (ctx, next) => {  // fhistory中间件
  const path = '/adminVueElement/' // 需要判断的路径
  await next() // 等待请求执行完毕
  if (ctx.response.status === 404 && ctx.request.url.includes(path)) { // 判断是否符合条件
    ctx.type = 'text/html; charset=utf-8';  // 修改响应类型
    ctx.body= fs.readFileSync('.' + path + 'index.html');  // 修改响应体
  }
})
app.use(static("./"));  //静态文件中间件
app.use(compress({ threshold: 2048 }));  //gzip中间件

app
  .use(router.routes())
  .use(router.allowedMethods());

app.listen(3000);
```


# 支持 HTML5 的浏览器   fHTML5支持
Firefox（火狐浏览器）
IE9及其更高版本
Chrome（谷歌浏览器）
Safari
Opera等；国内的傲游浏览器（Maxthon）
以及基于IE或Chromium（Chrome的工程版或称实验版）所推出的360浏览器
搜狗浏览器
QQ浏览器
猎豹浏览器等国产浏览器同样具备支持HTML5的能力
