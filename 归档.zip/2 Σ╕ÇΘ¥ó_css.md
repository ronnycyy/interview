# f盒子模型 f盒模型
盒子模型分为 标准盒模型 和 IE盒模型。
**区别**
- 标准盒模型的 width/height 不包括 padding 和 border,
- IE盒模型的 width/height 包括 padding 和 border。
**共同点**
这两种模型由里到外都是 content, padding, border, margin。
**切换**
box-sizing: content-box 是标准盒模型;
box-sizing: border-box  是 IE盒模型;

# f权重 fCSS权重 f优先级 fCSS优先级  fweight
CSS优先级由高到低分别是:
1. !important             权重最大            !important 
2. 内联样式                权重1000           style=".."
3. id选择器                权重100            #elementId
4. 类/伪类/属性 选择器       权重10            .classname/:hover/a[title=“eee”]
5. 标签/伪元素 选择器        权重1             div/::before
6. 相邻兄弟/子/后代/通配符    权重0             h1+p, ul>li, li a, \*
注意:
- 如果优先级相同，则最后出现的样式生效；
- 样式表的来源不同时，优先级顺序为：内联样式 > 内部样式 > 外部样式 > 浏览器用户自定义样式 > 浏览器默认样式。 

# fposition
**讲概念**
1. position 属性用于指定一个元素在文档中的定位方式。
2. 通过 top，right，bottom 和 left 属性来决定元素的最终位置。
**属性值**
1. static     默认值，没有定位。top, right, bottom, left 和 z-index 属性无效。处于正常文档流。 [fstatic]
2. fixed      绝对定位。相对于屏幕视口的位置来定位。元素的位置在屏幕滚动时不会改变。移出正常文档流。[ffixed]
3. relative   生成相对定位的元素，相对于其原来的位置进行定位。  [frelative]
4. absolute   绝对定位。相对于最近一个非 static 的父元素定位。 [fabsolute]
5. sticky     粘性定位。 [fsticky]

# position: fabsolute
**讲概念**
1. 元素会被移出正常文档流，并不为元素预留空间，通过指定元素相对于最近的非 static 定位祖先元素的偏移，来确定元素位置。
2. 通过 top，right，bottom 和 left 属性来决定元素的最终位置。
3. 绝对定位的元素可以设置外边距(margins)，且不会与其他边距合并。


# position: frelative
**讲概念**
1. 该关键字下，元素先放置在未添加定位时的位置，再在不改变页面布局的前提下调整元素位置（因此会在此元素未添加定位时所在位置留下空白）。
2. position:relative 对 table-*-group, table-row, table-column, table-cell, table-caption 元素无效。


# position: ffixed
**讲概念**
1. 元素会被移出正常文档流，并不为元素预留空间，而是通过指定元素相对于屏幕视口（viewport）的位置来指定元素位置。
2. 元素的位置在屏幕滚动时不会改变。打印时，元素会出现在的每页的固定位置。fixed 属性会创建新的层叠上下文。
3. 当元素祖先的 transform, perspective 或 filter 属性非 none 时，容器由视口改为该祖先。


# position: fsticky
**讲概念**
1. 粘性定位。
2. 元素根据正常文档流进行定位，然后相对它的`最近滚动祖先`和 最近块级祖先, 基于top, right, bottom, 和 left 的值进行偏移。
3. 偏移值不会影响任何其他元素的位置。 该值总是创建一个新的层叠上下文（stacking context）。
4. 一个 sticky 元素会“固定”在离它最近的一个拥有“滚动机制”的祖先上（当该祖先的overflow 是 hidden, scroll, auto, 或 overlay时），即便这个祖先不是最近的真实可滚动祖先。这有效地抑制了任何“sticky”行为。
**举例子**
1. 在 viewport 视口滚动到元素 top 距离小于 10px 之前，元素为相对定位。
2. 之后，元素将固定在与顶部距离 10px 的位置，直到 viewport 视口回滚到阈值以下。
```css
/* 大于 10px 的时候滚动，到达 10px 的时候`粘`住 */
#stickyDiv { 
  position: sticky; 
  top: 10px;
}
```

# fdisplay
1. none             元素不显示，并且会从文档流中移除。
2. block            块类型。默认宽度为父元素宽度，可设置宽高，独占一行。
3. inline           行内元素类型。默认宽度为内容宽度，不可设置宽高，不独占一行。
4. inline-block     默认宽度为内容宽度，可以设置宽高，不独占一行。
5. list-item        像块类型元素一样显示，并添加样式列表标记。
6. table            此元素会作为块级表格来显示。
7. inherit          规定应该从父元素继承 display 属性的值。 

# fdisply:none vs fvisibility:hidden fnone fhidden
这两个属性都是让元素隐藏, 不可见, 区别如下:
1. 在渲染树中
- `display:none`会让元素完全从渲染树中消失，渲染时不会占据任何空间；
- `visibility:hidden`不会让元素从渲染树中消失，渲染的元素还会占据相应的空间，只是内容不可见。
2. 是否是继承属性
- `display:none`是非继承属性，子孙节点会随着父节点从渲染树消失，通过修改子孙节点的属性也无法显示；
- `visibility:hidden`是继承属性，子孙节点消失是由于继承了`hidden`，通过设置`visibility:visible`可以让子孙节点显示；
3. 是否重排重绘
修改正常文档流中元素的 `display` 会造成文档的重排，修改 `visibility` 属性只会造成本元素的重绘； [f重排]
4. 读屏器
如果使用读屏器，设置为`display:none`的内容不会被读取，设置为`visibility:hidden`的内容会被读取。

# f隐藏元素 fhidden f隐藏元素的方法有哪些
- display: none：渲染树不会包含该渲染对象，因此该元素不会在页面中占据位置，也不会响应绑定的监听事件。
- visibility: hidden：元素在页面中仍占据空间，但是不会响应绑定的监听事件。
- opacity: 0：将元素的透明度设置为 0，以此来实现元素的隐藏。元素在页面中仍然占据空间，并且能够响应元素绑定的监听事件。
- position: absolute：通过使用绝对定位将元素移除可视区域内，以此来实现元素的隐藏。
- z-index: 负值**：来使其他元素遮盖住该元素，以此来实现隐藏。
- clip/clip-path：使用元素裁剪的方法来实现元素的隐藏，这种方法下，元素仍在页面中占据位置，但是不会响应绑定的监听事件。
- transform: scale(0,0)：将元素缩放为 0，来实现元素的隐藏。这种方法下，元素仍在页面中占据位置，但是不会响应绑定的监听事件。


# f重排(也就是f回流)  位置/宽高变了
**讲概念**
当渲染树中部分或者全部元素的尺寸、结构或者属性发生变化时，浏览器会重新渲染部分或者全部文档的过程就称为`重排`。
### 导致`重排`的操作
- 页面的首次渲染
- 浏览器的窗口大小发生变化
- 元素的内容发生变化
- 元素的尺寸或者位置发生变化
- 元素的字体大小发生变化
- 激活CSS伪类
- 查询某些属性或者调用某些方法
- 添加或者删除可见的DOM元素
**说用途**
在触发回流（重排）的时候，由于浏览器渲染页面是基于流式布局的，所以当触发回流时，会导致周围的DOM元素重新排列，它的影响范围有两种：
- 全局范围：从根节点开始，对整个渲染树进行重新布局
- 局部范围：对渲染树的某部分或者一个渲染对象进行重新布局


# f重绘  颜色/背景色变了
**讲概念**
当页面中某些元素的样式发生变化，但是不会影响其在文档流中的位置时，浏览器就会对元素进行重新绘制，这个过程就是`重绘`。
### 导致`重绘`的操作
- color、background 相关属性：background-color、background-image 等
- outline 相关属性：outline-color、outline-width 、text-decoration
- border-radius、visibility、box-shadow
注意： **当触发重排时，一定会触发重绘，但是重绘不一定会引发重排。**


# f避免重排与重绘
- 操作DOM时，尽量在低层级的DOM节点进行操作
- 不要使用`table`布局， 一个小的改动可能会使整个`table`进行重新布局
- 使用CSS的表达式
- 不要频繁操作元素的样式，对于静态页面，可以修改类名，而不是样式。
- 使用absolute或者fixed，使元素脱离文档流，这样他们发生变化就不会影响其他元素
- 避免频繁操作DOM，可以创建一个文档片段`documentFragment`，在它上面应用所有DOM操作，最后再把它添加到文档中
- 将元素先设置`display: none`，操作结束后再把它显示出来。因为在display属性为none的元素上进行的DOM操作不会引发回流和重绘。
- 将DOM的多个读操作（或者写操作）放在一起，而不是读写操作穿插着写。这得益于`浏览器的渲染队列机制`。浏览器会将所有的回流、重绘的操作放在一个队列中，当队列中的操作到了一定的数量或者到了一定的时间间隔，浏览器就会对队列进行批处理。这样就会让多次的回流、重绘变成一次回流重绘。将多个读操作（或者写操作）放在一起，就会等所有的读操作进入队列之后执行，这样，原本应该是触发多次回流，变成了只触发一次回流。


# CSS3新特性
- 新增各种 CSS 选择器 （`: not(.input)`：所有 class 不是“input”的节点）
- 圆角 （border-radius:8px）
- 多列布局 （multi-column layout）
- 阴影和反射 （Shadoweflect）
- 文字特效 （text-shadow）
- 文字渲染 （Text-decoration）
- 线性渐变 （gradient）
- 旋转 （transform） [ftransform]
- 增加了旋转,缩放,定位,倾斜,动画,多背景

# ftransform
**讲概念**
1. CSS transform 属性允许你旋转，缩放，倾斜或平移给定元素。这是通过修改 CSS 视觉格式化模型的坐标空间来实现的。
**属性**
1. translate 位移
2. rotate 旋转
3. scale 缩放
4. skew 斜切
**举例子**
1. 平移一个 div 到 (30,20) 的偏移, 然后旋转 20 角度。
```css
div {
  width: 100px;
  height: 50px;
  transform: translate(30px, 20px) rotate(20deg);
}
```
**transform属性表**
| none                                                         | 定义不进行转换。                        |
| ------------------------------------------------------------ | --------------------------------------- |
| **matrix(*n*,*n*,*n*,*n*,*n*,*n*)**                          | 定义 2D 转换，使用六个值的矩阵。        |
| matrix3d(*n*,*n*,*n*,*n*,*n*,*n*,*n*,*n*,*n*,*n*,*n*,*n*,*n*,*n*,*n*,*n*) | 定义 3D 转换，使用 16 个值的 4x4 矩阵。 |
| **translate(*x*,*y*)**                                       | 定义 2D 转换。（平移）                  |
| translate3d(*x*,*y*,*z*)                                     | 定义 3D 转换。                          |
| translateX(*x*)                                              | 定义转换，只是用 X 轴的值。             |
| translateY(*y*)                                              | 定义转换，只是用 Y 轴的值。             |
| translateZ(*z*)                                              | 定义 3D 转换，只是用 Z 轴的值。         |
| **scale(*x*,*y*)**                                           | 定义 2D 缩放转换。                      |
| scale3d(*x*,*y*,*z*)                                         | 定义 3D 缩放转换。                      |
| scaleX(*x*)                                                  | 通过设置 X 轴的值来定义缩放转换。       |
| scaleY(*y*)                                                  | 通过设置 Y 轴的值来定义缩放转换。       |
| scaleZ(*z*)                                                  | 通过设置 Z 轴的值来定义 3D 缩放转换。   |
| **rotate(*angle*)**                                          | 定义 2D 旋转，在参数中规定角度。        |
| rotate3d(*x*,*y*,*z*,*angle*)                                | 定义 3D 旋转。                          |
| rotateX(*angle*)                                             | 定义沿着 X 轴的 3D 旋转。               |
| rotateY(*angle*)                                             | 定义沿着 Y 轴的 3D 旋转。               |
| rotateZ(*angle*)                                             | 定义沿着 Z 轴的 3D 旋转。               |
| **skew(*x-angle*,*y-angle*)**                                | 定义沿着 X 和 Y 轴的 2D 倾斜转换。      |
| skewX(*angle*)                                               | 定义沿着 X 轴的 2D 倾斜转换。           |
| skewY(*angle*)                                               | 定义沿着 Y 轴的 2D 倾斜转换。           |
| perspective(*n*)                                             | 为 3D 转换元素定义透视视图。            |


## 为什么有时候⽤ transform:translate 来改变位置⽽不是定位？
translate 是 transform 属性的⼀个值。改变 transform 或 opacity 不会触发浏览器重新布局（reflow）或重绘（repaint），只会触发复合（compositions）。⽽改变绝对定位会触发重新布局，进⽽触发重绘和复合。transform 使浏览器为元素创建⼀个 GPU 图层，但改变绝对定位会使⽤到 CPU。 因此 translate()更⾼效，可以缩短平滑动画的绘制时间。 ⽽ translate 改变位置时，元素依然会占据其原始空间，绝对定位就不会发⽣这种情况。

# fli 与 li 之间有看不见的空白间隔是什么原因引起的？如何解决？
浏览器会把 inline 内联元素间的空白字符（空格、换行、Tab 等）渲染成一个空格。为了美观，通常是一个`<li>`放在一行，这导致`<li>`换行后产生换行字符，它变成一个空格，占用了一个字符的宽度。
**解决办法**
1. 为`<li>`设置 float:left。不足：有些容器是不能设置浮动，如左右切换的焦点图等。
2. 将所有`<li>`写在同一行。不足：代码不美观。
3. 将`<ul>`内的字符尺寸直接设为 0，即 font-size:0。不足：`<ul>`中的其他字符尺寸也被设为 0，需要额外重新设定其他字符尺寸，且在 Safari 浏览器依然会出现空白间隔。
4. 消除`<ul>`的字符间隔 letter-spacing:-8px，不足：这也设置了`<li>`内的字符间隔，因此需要将`<li>`内的字符间隔设为默认 letter-spacing:normal。


# fflex布局 父元素 display:flex  弹性盒模型
**讲概念**
1. flex 可以让一个元素成为一个弹性布局的容器，通过 display:flex 实现。
2. 一个容器默认有两条轴：一个是水平的主轴，一个是与主轴垂直的交叉轴。
## flex的css属性
**容器**
1. flex-direction 指定主轴的方向, 如 row,row-reverse,column,column-reverse。
2. fjustify-content 指定元素在主轴上的排列方式, 如 center,left,right,space-between(均匀,首尾置底),space-around(均匀,间隔相等)。
3. falign-items 指定元素在交叉轴上的排列方式, 如 center,start,end,flex-start,flex-end。
4. flex-wrap 规定当一行排列不下时的换行方式，如 wrap(换行), nowrap(不换行), wrap-reverse(换行,新行往上排列)。
5. flex-flow 是 flex-direction 和 flex-wrap 的顺序缩写。
**元素**
1. flex-grow 当排列空间有剩余的时候，项目的放大比例, 值是一个数字，如容器中有 2 个元素, 1 个 flex-grow:1, 1 个 flex-grow:2。
2. flex-shrink 当排列空间不足时，项目的缩小比例, 值是一个数字，如 flex-shrink: 1。
3. flex-basis 元素在主轴方向上的初始大小，如 flex-basis: 30px。
4. flex 是 flex-grow flex-shrink flex-basis 的顺序缩写, 平时写 flex:1 指的是 flex: 1 1 0。元素可以在 flex-basis 为 0 的基础上伸缩。
**举例子**
```css
.box {
  display: flex;
}
.one {
  flex: 1 1 auto;
}
.two {
  flex: 1 1 auto;
}
.three {
  flex: 1 1 auto;
}
```


# fBFC  Block Formatting Contex  块级格式化上下文
1. BFC 是一个独立的布局环境，可以理解为一个容器，在这个容器中按照一定规则进行物品摆放，并且不会影响其它环境中的物品。
2. 如果一个元素符合触发 BFC 的条件，则 BFC 中的元素布局不受外部影响。
3. BFC 不会与浮动元素发生重叠。 [f两栏布局]
## f创建BFC:  常用的有 overflow:hidden, display:flow-root;
1. 根元素 `html`
2. 浮动元素（float 值不为 none）
3. 绝对定位元素（position 值为 absolute 或 fixed）
4. 行内块元素（display 值为 inline-block）
5. 表格单元格（display 值为 table-cell，HTML 表格单元格默认值）
6. 表格标题（display 值为 table-caption，HTML 表格标题默认值）
7. 匿名表格单元格元素（display 值为 table、table-row、 table-row-group、table-header-group、table-footer-group（分别是 HTML table、tr、tbody、thead、tfoot 的默认值）或 inline-table）
8. overflow 值不为 visible、clip 的块元素
9. display 值为 flow-root 的元素
10. contain 值为 layout、content 或 paint 的元素
11. 弹性元素（display 值为 flex 或 inline-flex 元素的直接子元素），如果它们本身既不是 flex、grid 也不是 table 容器
12. 网格元素（display 值为 grid 或 inline-grid 元素的直接子元素），如果它们本身既不是 flex、grid 也不是 table 容器
13. 多列容器（column-count 或 column-width (en-US) 值不为 auto，包括column-count 为 1）
14. column-span 值为 all 的元素始终会创建一个新的 BFC，即使该元素没有包裹在一个多列容器中 (规范变更, Chrome bug)
## 说用途
- **解决 margin 的重叠问题**
由于 BFC 是一个独立的区域，内部的元素和外部的元素互不影响，给重叠下面的那个元素包裹一个父 BFC，跟上面的元素完全脱离，就解决了 margin 重叠的问题。
- **解决高度塌陷的问题**
在对子元素设置浮动后，父元素会发生高度塌陷。解决这个问题，只需要把父元素变成一个 BFC。因为 BFC 会把浮动子元素的高度计算进去。常用的办法是给父元素设置`overflow:hidden`或`display:flow-root`。
- **创建自适应两栏布局** [f两栏布局]
可以用来创建自适应两栏布局：左边的宽度固定，右边的宽度自适应。

## f高度塌陷
非BFC父元素，不会将浮动子元素的高度计算在内，造成父元素高度比子元素小。
- 解决方法:
把父元素变成一个 BFC。因为 BFC 会把浮动子元素的高度计算进去。常用的办法是给父元素设置`overflow:hidden`或`display:flow-root`。

## fmargin重叠
两个块级元素的上外边距和下外边距可能会合并（折叠）为一个外边距，其大小会取其中外边距值大的那个，这种行为就是外边距折叠。需要注意的是，**浮动的元素和绝对定位**这种脱离文档流的元素的外边距不会折叠。重叠只会出现在**垂直方向**。
- 解决方法:
1. 兄弟重叠
- 底部元素变为行内盒子：`display: inline-block`
- 底部元素设置浮动：`float`
- 底部元素的 position 的值为`absolute/fixed`
2. 父子重叠
- 父元素加入：`overflow: hidden`
- 父元素添加透明边框：`border:1px solid transparent`
- 子元素变为行内盒子：`display: inline-block`
- 子元素加入浮动属性或定位x


# f浮动 ffloat
**讲概念**
1. 一个元素浮动时，如果它的容器没有设置高度, 那么容器的高度不能被撑开。此时, 内容会溢出到容器外面而影响布局。这种现象被称为浮动。
2. 浮动元素脱离文档流, 不占据空间, 会引起“高度塌陷”现象。 [f清除浮动]
3. 浮动元素碰到包含它的边框或者其他浮动元素的边框停留。
**浮动危害**  [浮动有什么问题]
1. 父元素的高度无法被撑开，影响与父元素同级的元素。
2. 与浮动元素同级的非浮动元素会跟随其后。
3. 若浮动的元素不是第一个元素，则该元素之前的元素也要浮动，否则会影响页面的显示结构。
**f清除浮动**  [如何清除浮动] [解决高度塌陷]
1. 父元素创建一个 BFC。 [fBFC]
如`display:flow-root`, `overflow:hidden`等, 因为 BFC 元素的高度会把浮动子元素的高度计算进来。
2. 增加一个末尾元素, 设置 `clear:both`。
3. 给`父元素`添加一个 ::after 伪元素, 设置 `content:''; display:block; clear:both;`。
4. 给`父元素`定义`height`属性，撑开高度不影响后面的元素。
**为什么 clear 可以清除浮动?**
clear 使得**元素盒子的边不能和前面的浮动元素相邻**，这样我们定义的块级元素就会渲染到浮动元素下面，把高度撑开。


# f伪类  如:hover
伪类选中元素的特殊状态。例如 hover 是选中元素在鼠标悬停时的状态。
伪类连同伪元素一起，他们允许你不仅仅是根据文档 DOM 树中的内容对元素应用样式，而且还允许你根据诸如像导航历史这样的外部因素来应用样式（例如 :visited），同样的，可以根据内容的状态（例如在一些表单元素上的 :checked），或者鼠标的位置（例如 :hover 让你知道是否鼠标在一个元素上悬浮）来应用样式。
## 常用的伪类
:link    匹配所有尚未访问的链接，包括那些已经给定了其他伪类选择器的链接。
:visited 匹配用户已访问过的链接。
:hover   适用于用户使用指示设备虚指一个元素（没有激活它）的情况。
:active  匹配被用户激活的元素。它让页面能在浏览器监测到激活时给出反馈。当用鼠标交互时，它代表的是用户`按下按键`和`松开按键`之间的时间。
:checked 匹配任何处于选中状态的radio, checkbox 或 select元素中的 option。
:focus   匹配获得焦点的元素（如表单输入）。当用户点击或触摸元素或通过键盘的 “tab” 键选择它时会被触发。
:host    匹配包含其内部使用的 CSS 的 shadow DOM 的根元素 - 换句话说，这允许你从其 shadow DOM 中选择一个自定义元素。
:nth-last-of-type(n)  选中倒数第n个type类型的元素, 注意倒数的索引从1开始。
:nth-of-type(n)       指定一个实际参数n，这个参数使用一种模式来匹配哪些元素应该被选中, 如 2n+1奇数, 2n偶数, int代表从1开始的索引。
:root    匹配文档树的根元素。对于 HTML 来说，:root 表示 <html> 元素，除了优先级更高之外，与 html 选择器相同。

# f伪元素  如::before
伪元素创建或选中元素的特定`部分`，如 ::before 创建一个伪元素作为元素的第一个子元素，通过 content 属性添加内容。
如下面这个正方形:
```css
/* 一个紫色的正方形 */
.box::before {
    content: "";
    display: block;
    width: 100px;
    height: 100px;
    background-color: rebeccapurple;
    border: 1px solid black;
} 
```
## 用法
一个选择器中只能使用一个伪元素。伪元素必须紧跟在语句中的简单选择器/基础选择器之后。
按照规范，应该使用双冒号（::）而不是单个冒号（:），以便区分伪类和伪元素。但是，由于旧版本的 W3C 规范并未对此进行特别区分，因此目前绝大多数的浏览器都同时支持使用这两种方式来表示伪元素。
## 常见的伪元素
* ::before  创建一个伪元素，其将成为匹配选中的元素的第一个子元素。常通过 content 属性来为一个元素添加修饰性的内容。此元素默认为行内元素。
* ::after  创建一个伪元素，作为已选中元素的最后一个子元素。通常会配合content属性来为该元素添加装饰内容。这个虚拟元素默认是行内元素。
* ::selection CSS 伪元素应用于文档中被用户高亮的部分（比如使用鼠标或其他选择设备选中的部分）。
* ::first-letter  选中某块级元素第一行的第一个字母，并且文字所处的行之前没有其他内容（如图片和内联的表格）。


# f伪类 和 f伪元素 的区别
1. 伪类给元素的特殊状态添加效果, 它是已有元素上添加类别的，不会产生新的元素。如 hover 是鼠标悬停的状态，可以加 color 等效果变化。伪元素在内容元素的前后插入额外的元素或样式，但是这些元素实际上并不在文档中生成。它们只在外部显示可见，但不会在文档的源代码中找到它们，因此，称为“伪”元素。如 ::before 创建一个伪元素作为元素的第一个子元素，通过 content 属性添加内容。


# f可替换元素
如 img, iframe, video, audio, embed。
在 CSS 中，可替换元素（replaced element）的展现效果不是由 CSS 来控制的。这些元素是一种外部对象，它们外观的渲染，是独立于 CSS 的。简单来说，它们的内容不受当前文档的样式的影响。CSS 可以影响可替换元素的位置，但不会影响到可替换元素自身的内容。某些可替换元素，例如 <iframe> 元素，可能具有自己的样式表，但它们不会继承父文档的样式。CSS 能对可替换元素产生的唯一影响在于，部分属性支持控制元素内容在其框中的位置或定位方式。

# f三角形 f画三角形
**原理**
1. 在 CSS 里 border 属性是沿着 div 的四个顶点往外延伸，形成 4 个梯形，只要把 div 的宽高设置成 0, 4 个梯形就会变成 4 个三角形，选一个即可。
**步骤**
1. 用一个 div, 把宽高设置为0。
2. 设置 border-bottom 是 100px solid red, 其他 border-xx 是 100px solid transparent。
3. 这样就是一个尖尖朝上的红色三角形。
**举例子:一个尖尖朝上的红色三角形**
```css
div {
  width: 0;
  height: 0;
  border-top: 100px solid transparent;
  border-left: 100px solid transparent;
  border-right: 100px solid transparent;
  border-bottom: 100px solid red;
}
```

# f扇形 f画扇形
**原理**
1. 基于 [f画三角形] 的特性，加一个 border-radius 属性。
```css
div {
    width: 0;
    height: 0;
    border-top: 100px solid transparent;
    border-left: 100px solid transparent;
    border-right: 100px solid transparent;
    border-bottom: 100px solid red;
    border-radius: 50%;
}
```

# f正方形 f画自适应的正方形 f画正方形
**自适应的含义**
`窗口/父元素`变化的时候, 正方形的宽高能够等比例地随之变大。
**原理**
1. 利用 margin, padding, width 的百分比都是相对于父元素宽度来计算。 [f百分比]
**步骤**
1. width 设置为父元素宽度的 20%。
2. height 设置为 0。
3. padding-top 设置为父元素宽度的 20%。
**例子**
1. 通过 padding 的百分比值是相对于父元素 width 的性质实现。[最优解]
```css
div {
  width: 20%;
  height: 0;
  padding-top: 20%;
  background-color: orange;
}
```
**其他例子**
1. 通过 margin 的百分比值是相对于父元素 width 的性质，增加一个伪子元素撑开元素的高度，撑开幅度为元素的宽度。[缺点:多了一个伪元素] [f伪元素]
```css
div {
  width: 30%;
  overflow: hidden;
  background: lightblue;
}
div::after {
  content: '';
  display: block;
  margin-top: 100%;
}
```
2. 宽度用百分比，高度用 vw 的形式，两者同值即可实现宽高相同。[缺点:只能相对于视口实现]
```css
div {
  width: 10%;
  height: 10vw;
  background: tomato;
}
```

# f百分比
**说用途**
1. padding, margin, width 的百分比值都是相对于`父元素的width`值计算的。[f画正方形]

# fem vs frem
**共同点**
都是相对长度单位
**区别**
em: 相对于父元素 font-size 的倍数
rem: 相对于根元素, 也就是html的 font-size 的倍数


# css响应式布局有什么实现方式？
1. @media 媒体查询 [fmedia] [f媒体查询]  (推荐! 很详细地区分)
2. 百分比  (把宽高等设置成百分比, 让子元素相对于父元素来计算)
3. rem [frem] (把宽高等设置成rem单位)
4. flex布局 [fflex] (通过flex:1伸缩)
5. vw,vh,vmax,vmin [fvw] [fvh] [fvmax] [fmin] (相对于视口的宽高)


# @media fmedia
**讲概念**
@media 是 CSS 的一个规则, 可用于基于一个或多个媒体查询的结果来应用样式表的一部分。
**说用途**
我们可以指定一个媒体查询和一个 CSS 块, 当且仅当该媒体查询与正在使用其内容的设备匹配时, 该 CSS 块才能应用于该文档。
**举例子**
```css
/* 精确宽度 */
@media screen and (width: 360px) {
  div {
    color: red;
  }
}
/* 最小宽度 */
@media screen and (min-width: 35rem) {
  div {
    background: yellow;
  }
}
/* 最大宽度 */
@media screen and (max-width: 50rem) {
  div {
    border: 2px solid blue;
  }
}
```

# f引入CSS的方式 fimport
1. 通过`内联样式`引入, 如`<div style="color:red;"></div>`。
2. 通过在 html 文件里写 `style标签`, 在 style标签里写 CSS 语句。
3. 通过 link 标签引入外部 CSS 文件, 如 `<link rel="stylesheet" href="./a.css">`。 
4. 通过在 CSS 文件里写 @import 语句引入 CSS 文件。

# flink
1. HTML 外部资源链接元素 link 标签规定了当前文档与外部资源的关系。
2. 该元素最常用于链接样式表，此外也可以被用来创建站点图标, 比如网站的`favicon`图标。
**说用法**
```html
<head>
  <link rel="stylesheet" href="main.css" />
  <link rel="icon" href="favicon.ico" />
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="apple-icon-114.png" type="image/png">
</head>
```

# f@import
**讲概念**
@import 是一个 CSS 提供的引入语句，用于在一个 CSS 文件中导入其他样式文件。
**说用法**
@import [一个双引号括起来的一个URL,指向要导入的样式文件] [设备条件?]
**举例子**
```css
@import 'custom.css';
@import 'custom.less';
@import url("fineprint.css") print;
@import url('landscape.css') screen and (orientation:landscape);
```

# flink vs f@import  f引入CSS方式对比
1. 允许加载的范围不同。
@import 是css 提供的语法规则，只有导入样式表的作用。
link 是 html 提供的标签，不仅可以加载 css 文件，还可以加载 favicon.ico, image 等外部资源。
2. 加载顺序不同。
link 是同步加载, 优先加载CSS文件到页面;
@import 是异步加载，在 HTML 页面加载完毕后才加载 CSS 文件。
3. 兼容性不同。
@import是 css2.1 才有的语法，故只可在 iE5+ 才能识别。
link 标签作为 html 元素，不存在兼容性问题。


# f水平垂直居中的方式 fcenter fz f居中
1. 父元素相对定位,子元素绝对定位,left,top都是50%定位左上角点,然后transform:translte(-50%,-50%)平移回来。 [父相对子绝对居中再平移]
2. 父元素相对定位,子元素绝对定位,left,top都是50%定位左上角点,然后 margin 自身宽高一半的负值平移回来。 [父相对子绝对居中再margin负值]
3. 父元素flex布局,通过`display: flex;align-items: center;justify-content: center;`让内容垂直水平居中。 [父flex布局经典三句话居中]
4. 父元素flex布局,子元素`margin:auto`即可水平垂直居中, 在 flex 布局下, auto 实现外边距相等。 [父flex布局子margin_auto]

**水平垂直居中1**  [父相对子绝对居中再平移]
注意: transform: translate 需考虑兼容性问题。
```css
.parent {
  position: relative;
  width: 100vw;
  height: 100vh;
}
.child {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: 100px;
  height: 100px;
}
```

**水平垂直居中2**  [父相对子绝对居中再margin负值]
注意: 适用于子元素的宽高已经知道的情况。
```css
.parent {
  position: relative;
  width: 100vw;
  height: 100vh;
}
.child {
  position: absolute;
  left: 50%;
  top: 50%;
  margin-left: -50px;
  margin-top: -50px;
  width: 100px;
  height: 100px;
}
```

**水平垂直居中3**  [父flex布局经典三句话居中]
```css
.parent {
  display: flex;
  align-items: center;  /* 垂直交叉轴 */
  justify-content: center;  /* 主轴 */
  width: 100vw;
  height: 100vh;
}
.child {
  width: 100px;
  height: 100px;
}
```

**水平垂直居中4**  [父flex布局子margin_auto]
```css
.parent {
  display: flex;
  width: 100vw;
  height: 100vh;
}
.child {
  margin: auto;
  width: 100px;
  height: 100px;
}
```


# f两栏布局 flayout2
**讲概念**
1. 左边栏宽度固定, 右边栏宽度自适应。
**两栏布局的实现方式**
1. 浮动左边栏,右边栏margin-left左宽,父元素设置高度撑开。(左边栏浮动造成的塌陷) [左浮动右margin父高度] [f清除浮动]
2. 浮动左边栏,右边栏设置overflow:hidden触发BFC, BFC不会与浮动元素重叠。 [左浮动右BFC]  [fBFC]
3. 父元素display:flex,让左右排成一行,左边栏固定宽度,右边栏flex:1自适应宽度。 [父flex布局右flex1] [fflex]
4. 父元素相对定位,左边栏绝对定位,让左右重叠在一行,然后右边栏margin-left左宽。 [父相对左绝对右margin]
5. 父元素相对定位,右边栏绝对定位,右left左宽,top0从顶开始,bottom0撑开高度,right0撑开宽度。 [父相对右绝对left左宽其余0]

**两栏实现1** [左浮动右margin父高度]
```css
.container {
  height: 100px;
}
.left {
  float: left;
  width: 100px;
}
.right {
  margin-left: 100px;
}
```

**两栏实现2** [左浮动右BFC]
```css
.left {
  float: left;
  width: 100px;
}
.right {
  overflow: hidden; 
}
```

**两栏实现3** [父flex布局右flex1]
```css
.container {
  display: flex;
}
.left {
  width: 100px;
}
.right {
  flex: 1; 
}
```

**两栏实现4** [父相对左绝对右margin]
```css
.container {
  position: relative;
}
.left {
  width: 100px;
  position: absolute;
}
.right {
  margin-left: 100px;
}
```

**两栏实现5**  [父相对右绝对left左宽其余0]
```css
.container {
  position: relative;
}
.left {
  width: 100px;
}
.right {
  position: absolute;
  left: 100px;  /* 紧挨着左边栏开始 */
  top: 0;  /* 从最顶开始 */
  right: 0;  /* 撑开右边 */
  bottom: 0;  /* 撑开高度 */
}
```

# f三栏布局 flayout3
**讲概念**
1. 左边栏宽度固定, 右边栏宽度固定, 中间栏宽度自适应。
**三栏布局的实现方式**
1. 父元素相对定位,左边栏绝对定位left:0+top:0,右边栏绝对定位right:0+top:0,让左右排成一行,然后中间栏margin两边的宽。[父相对左右绝对中margin]
2. 父元素flex布局,让左中右排成一行,中间栏flex:1自适应宽度。 [父flex布局中flex1]
3. [圣杯布局]

**三栏实现1**  [父相对左右绝对中margin]
```css
.container {
  position: relative;
}
.left {
  position: absolute;
  left: 0;
  top: 0;
  width: 100px;
}
.right {
  position: absolute;
  right: 0;
  top: 0;
  width: 200px;
}
.middle {
  margin-left: 100px;
  margin-right: 200px;
}
```

**三栏实现2**  [父flex布局中flex1]
```css
.container {
  display: flex;
}
.left {
  width: 100px;
}
.right {
  width: 200px;
}
.middle {
  flex: 1;
}
```

**三栏实现3** [圣杯布局]
```css
.container {
  height: 100px;
  padding-left: 100px;
  padding-right: 200px;
}
.left {
  position: relative;
  left: -100px;
  float: left;
  margin-left: -100%;
  width: 100px;
  height: 100px;
}
.right {
  position: relative;
  left: 200px;
  float: right;
  margin-left: -200px;
  width: 200px;
  height: 100px;
}
.middle {
  float: left;
  width: 100%;
  height: 100px;
}
```
