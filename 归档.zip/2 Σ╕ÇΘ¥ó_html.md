# fDOCTYPE
文档类型声明，全称是 document type，告知浏览器用什么文档标准解析这个文档。
## 例子
比如加 html 是让浏览器以 W3C 标准解析文档。
```html
<!DOCTYPE html>
<html>
  ...
</html>
```

# fHTML5 新特性
从 标签、属性、存储、API 四个方面来说:
## 标签
在标签上，新增语义化标签 aside, figure, section, header, footer, nav 等，增加多媒体标签 video 和 audio, 使得样式和结构更加分离。
## 属性
在属性上，增强表单，主要是增强了 input 的 type 属性; meta 增加 charset 属性以设置字符集; script 增加 async 以一步加载脚本。
## 存储
在存储上，增加 localStorage, sessionStorage 和 IndexDB 存储 web 数据。
## API
在 API 上，新增 拖放API, 地理定位, SVG绘图, canvas绘图, Web Worker, WebSocket。

# fmeta
meta 标签用于描述文档的元信息，如网站字符集、响应头、移动设备的视口大小、作者、描述、关键词，它通过键值对的形式来定义信息。常用的属性如 charset, http-equiv, 以及 name-content 形式定义的属性。
## fcharset 字符集
这个属性声明了文档的字符编码。如果使用了这个属性，其值必须是与 ASCII 大小写无关（ASCII case-insensitive）的"utf-8"。
```html
<meta charset="UTF-8">
```
## fhttp-equiv HTTP头部(请求+响应)
```html
<!-- 内容安全策略  禁用不安全的内联/动态执行，只允许通过 https 加载这些资源（如图片、字体、脚本等） -->
<meta http-equiv="Content-Security-Policy" content="default-src https:">
<!-- 声明文档的类型 -->
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<!-- 重新载入页面的时间间隔10秒 -->
<meta http-equiv="refresh" content="10">
```
## name-content 对
定义文档的标准元数据，其中 name 作为元数据的名称，content 作为元数据的值。常用的元数据有:
* viewport: 定义视口大小，目前只用于移动设备。
* application-name: 表示网页中运行的应用程序名称。
* author: 文档作者的名字。
* color-scheme: 指定与当前文档兼容的一种或多种配色方案。
* referrer：控制由当前文档发出的请求的 HTTP Referer 请求头。

```html
<!-- 视口宽度为设备宽度; 设备宽度与视口大小之间的缩放比例为1:1 -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- 网页中运行的应用程序名称 -->
<meta name="application-name" content="app">
<!-- 文档作者的名字 -->
<meta name="author" content="mike">
<!-- 文档更喜欢黑暗模式，但在光模式下也可以在功能上呈现 -->
<meta name="color-scheme" content="dark light">
<!-- 
  Referer 是 HTTP 请求头中的一个字段，记录了该 HTTP 请求的来源地址，也就是 URL。
  Origin 属性只包含了域名信息，并没有包含具体的 URL 路径，这是 Origin 和 Referer 的一个主要区别。

  Origin: https://time.geekbang.org  (没有Path)
  Referer: https://time.geekbang.org/column/intro/216  (有Path)

  Origin 的值之所以不包含详细路径信息，是有些站点因为安全考虑，不想把源站点的详细路径暴露给服务器。
-->
<!-- 只发送当前文档的 origin -->
<meta name="referrer" content="origin">
```
### fviewport 有哪些属性
* width: 定义 viewport 的宽度，如果值为正整数，则单位为像素。
* initial-scale: 定义设备宽度（宽度和高度中更小的那个：如果是纵向屏幕，就是 device-width，如果是横向屏幕，就是 device-height）与 viewport 大小之间的缩放比例。范围 [0.0~10.0]
* maximum-scale: 定义缩放的最大值，必须大于等于 minimum-scale，否则表现将不可预测。浏览器设置可以忽略此规则；iOS 10 开始，Safari iOS 默认忽略此规则。[0.0~10.0]
* minimum-scale: 定义缩放的最小值，必须小于等于 maximum-scale，否则表现将不可预测。浏览器设置可以忽略此规则；iOS 10 开始，Safari iOS 默认忽略此规则。[0.0~10.0]
* user-scalable: 默认为 yes，如果设置为 no，用户将无法缩放当前页面。浏览器设置可以忽略此规则；iOS 10 开始，Safari iOS 默认忽略此规则。[yes|no]

# fhref 和 fsrc 有什么区别
href（hyperReference）即超文本引用：当浏览器遇到href时，会并行的地下载资源，不会阻塞页面解析，例如我们使用<link>引入CSS，浏览器会并行地下载CSS而不阻塞页面解析。
src（resource）即资源，当浏览器遇到src时，会暂停页面解析，直到该资源下载或执行完毕。
```html
<link href="style.css" rel="stylesheet" />
<!-- ..body.. -->
<script src="script.js"></script>
```

### fHTML生命周期事件有哪些? f生命周期
DOMContentLoaded => load => beforeunload => unload
1. fDOMContentLoaded  (在 document 上监听)
当初始的 HTML 文档被完全加载和解析完成之后，DOMContentLoaded 事件被触发，而无需等待样式表、图像和子框架的完全加载。
```js
document.addEventListener('DOMContentLoaded',function(){
  console.log('1');
});
```
2. fload
当整个页面及所有依赖资源如样式表和图片都已完成加载时，将触发load事件。 
```js
window.addEventListener('load', (event) => {
  console.log('2');
});
```
3. fbeforeunload
当浏览器窗口关闭或者刷新时，会触发 beforeunload 事件。当前页面不会直接关闭，可以点击确定按钮关闭或刷新，也可以取消关闭或刷新。
```js
window.addEventListener('beforeunload', function(event) {
  console.log('3');
});
```
4. funload
当文档或一个子资源正在被卸载时，触发 unload事件。
```js
window.addEventListener('unload', function(event) {
  console.log('4');
});
```

# freadyState  fdocument.readyState
Document.readyState 属性描述了document 的加载状态。
当该属性值发生变化时，会在 document 对象上触发 readystatechange (en-US) 事件。
一个文档的 readyState 可以是以下之一:
* loading（正在加载）
document 仍在加载。
* interactive（可交互）
文档已被解析，"正在加载"状态结束，但是诸如图像，样式表和框架之类的子资源仍在加载。
* complete（完成）
文档和所有子资源已完成加载。表示 load 状态的事件即将被触发。
```js
document.addEventListener('readystatechange', (event) => {
  console.log(`readystate: ${document.readyState}\n`);
});
```
