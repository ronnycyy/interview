# Node.js
**讲概念**
Node.js 是一个基于 Chrome v8 引擎的 JavaScript 运行时环境，同时结合 libuv 扩展了 JavaScript 的功能。它使得 JavaScript 具有了后端语言才有的 I/O, 文件读写, 操作数据库的能力。

