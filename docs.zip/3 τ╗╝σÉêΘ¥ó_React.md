# 综合面回放
面试官提的问题记录:
1. 工资？
我工资是 13k
2. 为什么离职？
  * 因为我们团队的技术氛围不浓厚，我们没有任何的技术分享，也不重视前端，我的技术在这里得不到很好的发展。
  * 离职也是想开拓自己的眼界，去跟更优秀的团队做更优秀的产品，实现自己的人生价值。
3. 离职这段时间干了什么？
  * 学了一段时间算法 (二叉树、链表、图)
  * 读了一本书，叫《编码 -- 隐匿在计算机软硬件背后的语言》, 讲述从 0 到 1 做一个计算机的过程。
  * 重温了一下 React 和 Webpack 的源码
4. 为什么这么长时间没有找到工作？
  有两点原因:
  * 疫情期间不好找工作
  * 想借此机会好好地沉淀一下自己的技术
5. 介绍一下自己？
  面试官您好，我叫陈允翼，是一名 3 年开发经验的前端工程师。我之前是在深圳市台电实业有限公司，主要使用的前端框架是 React，对 React 的原理有比较深入的学习。我在原来公司负责的是会议相关的业务，具体来说，我对公司的会议管理平台进行过性能优化，参与过支持网页设计器的 canvas2D 渲染引擎，也为团队开发过脚手架。我的自我介绍完毕，谢谢面试官。
6. 你来聊一下`React的合成事件`和`浏览器的原生事件`有什么区别？
  ...
7. setState 是同步还是异步？
  ...
8. React 如何防止子组件重复渲染？
  ...
9. React.memo 和 useMemo 的使用场景
  ...
10. 你说一下使用 hooks 的注意事项
  ...
11. hooks 的原理是什么？
  ...
12. 四、React 如何封装自定义 hooks?
  ...
13. 五、什么是高阶组件？有什么优缺点？
  ...
14. redux 用过吗？使用过什么状态管理工具？
  ...
15. 六、React 为什么需要 fiber? 
  ...
16. React 的 Diff 算法
  ...
17. Webpack 有用过吗？
  有。
18. Webpack 的 Tree Shaking 是什么？有什么作用？原理是啥？
  ...
19. Webpack 的工作流程是怎么样的？
  ...
20. Webpack 如何实现持久化缓存？🔥
  ...
21. Webpack 的 Plugin 和 Loader
  ...
22. 现在有刷算法吗？刷了多少道？
  算法我是报了一个马士兵教育的算法班去学，学了 1 年，班里的题加上力扣的题已经刷了四百多道了。
23. 你负责的是一个会议管理平台这个项目，来介绍一下这个项目。
  ...
24. 会议日志长列表数据量大，操作卡顿，有多卡顿？
  ...
25. 代表资料包上传的速度是多少？怎么跟后台做规划的？
  ...
26. 首屏优化的原因？首屏优化的影响？哪些因素影响？
  ...


TODO: 把综合面的东西搬过来，只在这里看 React。


**一、React的合成事件和浏览器的原生事件有什么区别？**
# f合成事件
React 应用中，元素绑定的事件并不是原生事件，而是React 合成的事件，比如 onClick 是由 click 合成，onChange 是由 blur ，change ，focus 等多个事件合成。

# f事件委托
1. React 的事件不是绑定在元素上的，而是统一绑定在顶部容器上，在 v17 之前是绑定在 document 上的，在 v17 改成了 div#root 容器上, 也就是 ReactDOM.render 或者 ReactDOM.createRoot 接收的 rootNode。
2. 当事件触发时，实际触发回调的是在 root 上的监听器, 然后执行 dispatchEvents 函数，按浏览器`冒泡/捕获`的事件传播流程收集监听器，然后统一触发。

# f事件注册 f事件绑定
1. 在 React 新版的事件系统中，在 createRoot 会一口气向外层容器上注册完全部事件。
2. 事件是由各个插件提供，比如 ChangeEventPlugin 提供 onChange 相关事件，最终形成一个集合 allNativeEvents。
3. 遍历 allNativeEvents 这个事件集合，调用 listenToNativeEvent 这个 API 注册冒泡阶段和捕获阶段的回调，回调函数统一成内置了优先级的 dispatchEvent 函数。
4. 如果发生一次 click 事件，就会触发 2 次 dispatchEvent, 1 次是捕获阶段, 1 次是冒泡阶段。

# f事件触发
1. 在 div#root 上触发回调，这个回调是内置了优先级的 dispatchEvent 函数。
2. dispatchEvent 调用 batchedUpdates 开始批量更新，其中执行 dispatchEventsForPlugins，它的执行步骤如下:
  1. 得到触发事件的 Fiber 结点
  2. 根据`原生事件-React事件的映射关系`, 以及`冒泡/捕获`阶段，将原生事件 转为 React 事件。
  3. 从触发事件的 Fiber 开始，一路往上直到 div#root, 收集监听该`React事件`的元素，和它们的回调函数，封装一下然后 push 到 dispatchQueue 里。
  4. 遍历 dispatchQueue 执行回调函数，如果是`捕获阶段`就逆序遍历，保证触发顺序和浏览器事件触发规则一致。

# f事件插件
插件统一提供 2 个方法， 一个 registerEvents 用来注册事件，一个 extractEvents 用来提取事件。
1. registerEvents
比如 ChangeEventPlugin 定义了 onChange 对应原生的 'change', 'input', 'keydown', 'keyup' 等多个事件，这些原生事件在初始化的时候就会注册到 div#root 上，提供的回调统一是 dispatchDiscreteEvent。
2. extractEvents
触发事件后，浏览器进入DOM事件的`冒泡/捕获`阶段, React把`原生事件`转换成`react事件`，然后从触发事件的元素开始，一路往上检查沿途的元素的 props 是否注册了此刻 React 事件的回调，比如 onChange, onClick 等，如果有就加入 dispatchQueue 中，这个过程就是为了收集事件。


**二、setState 是同步还是异步?** [fsetState]
对于不同模式的 React 应用, setState 的表现是不一样的:
- 在 legacy 模式下，
  - 当命中了 batchedUpdates 逻辑时，进入批处理计算所有状态, 然后异步更新 (状态更新指 App 函数重新执行)，所以 setState 是异步的;
  - 没有命中 batchedUpdates 时，状态更新同步执行，所以 setState 是同步的。
- 在 concurrent 模式下，
  - 状态始终是异步更新，所以 setState 是异步的。

# flegacy
比如 React17 版本，通过 ReactDOM.render 开启，这种 React 应用产生的更新都是没有优先级的。

# fconcurrent
在 React18 通过 ReactDOM.createRoot 开启，React 应用产生的更新有优先级。

# fbatchedUpdate
批处理。比如在一个事件回调中执行多个 setState，那么 React 会赋予一个 BatchedUpdate 上下文

# fscheduleUpdateOnFiber
React 每次调度更新都会执行的函数。
1. 在 legacy 模式下，更新优先级都是 SyncLane，并且当前环境是 NoContext 的话 (脱离 BatchedUpdate 上下文)，就会调用 flushSyncCallbacksOnlyInLegacyMode 执行状态的同步更新。这意味着在 setState 之后能同步获取到更新后的 state。
2. 在 concurrent 模式下，不会执行 flushSyncCallbacksOnlyInLegacyMode, 状态会异步地更新。


**三、React 如何防止子组件重复渲染？**
如果不考虑性能优化 API，仅考虑 React 默认的`判断状态是否改变`的策略的话， (性能API如: shouldComponentUpdate, memo, forceUpdate)
对于一个 React 组件来说，能够引起它重复渲染的原因只有 3 个:
1. props: 从父组件传递下来。
2. state: 自己维护。
3. context: 自己选择要接收哪些 context。
只要这 3 者不变，组件就不会重新渲染。 其中 state 和 context 都是自己维护的, 更新前后只要自己维持数据不变就行，而 props 是父组件传递下来的，更新前后是否保持不变，就要看 props 的比较策略是怎么定的。


# fprops fprops比较策略
1. React 默认的 props 比较策略是`引用比较`, 也就是说，只要更新前后 props 的引用变了，React 就会认为组件发生了更新。在这种策略下，即使更新前后 props 都是传递一个空对象，因为两次得到的空对象引用不同，所以 React 也会认为子组件状态改变。
2. 如果使用了 React 的性能优化 API, 比如 React.memo, 或者是 useMemo, 那么 props 的比较策略就会改为`浅比较`, 这时更新前后再传递空对象，就会认为前后收到的 props 是相同的，子组件的状态没有改变，也就不需要重新渲染了。
3. 不过，把 props 的比较策略改成`浅比较`以后，会耗费多一点性能，因为`浅比较`要遍历两个对象的 key，而`引用比较`只对比引用即可, 这样就需要考虑，浅比较多耗费的性能会不会比子组件重新render的性能还要多，这是需要权衡利弊的地方。


# fmemo fReact.memo [下一项是useMemo, 面试常常要求对比]
**讲概念**
React.memo 是一个高阶组件，它接收一个组件，返回一个可能是缓存的组件。
**讲用法**
React.memo 接收两个参数，一个`React组件`，以及一个`比较函数`，返回一个`缓存值`。
- 当`比较函数`返回 true 时，React 将跳过被 React.memo 包裹的组件的渲染，直接返回最近一次的渲染结果;
- 当`比较函数`返回 false 时，组件重新渲染，React.memo 返回重新渲染的结果。
- 如果没有提供`比较函数`, memo 默认会`浅比较`更新前后的 props 来返回一个布尔值。
**函数签名**
```ts
function memo(Component: T, areEqual?: (prevProps: ComponentProps, nextProps: ComponentProps) => boolean): T;
```
**说原理**
1. 当 React Fiber 树更新时，到达一个 memo 的结点，会执行 beginWork -> updateSimpleMemoComponent.
2. pdateSimpleMemoComponent 中使用 shallowEqual(prevProps, nextProps) 浅比较 更新前后的props。
如果发现没有改变:
* 那么命中 bailout 逻辑，返回 bailoutOnAlreadyFinishedWork 的执行结果，也就是返回上一次的渲染结果(current.child 上一次的子fiber)
* 也就是说, 不需要重新执行 函数组件 来获取子Fiber, 达到性能优化的目的。
**举例子**
```jsx
// 每次 React 应用更新时，浅比较 MemoComponent 的 props, 如果一致，复用上一次的渲染结果，不用重新渲染。
const MemoComponent = React.memo(MiddleComponent, (prevProps, nextProps) => shalldowEqual(prevProps, nextProps));
```


# fuseMemo [上一项是React.memo]
**讲概念**
useMemo 是 React 提供的一个 hook, 只能用于函数组件。
**讲用法**
useMemo 接收两个参数，一个是`create函数`，一个是`依赖数组`，返回一个缓存值。
- 当函数组件重新渲染时，如果`依赖数组`中的任何一项发生了改变，`create函数`就会重新执行，返回新的缓存值。
- 这种优化有助于避免在每次渲染时都进行高开销的计算。
**函数签名**
```ts
function useMemo<T>(factory: () => T, deps: DependencyList | undefined): T;
```
**举例子**
```jsx
const memoizedValue = useMemo(create, deps);
```
**注意**
1. 如果没有提供依赖项数组，useMemo 在每次渲染时都会计算新的值。
2. 如果传入 deps 一个空数组，那么 useMemo 将只保留第一次的缓存，不会刷新缓存。
3. 不要把副作用这类的操作放在 create 函数中，这属于 useEffect 的适用范畴。传入 useMemo 的函数会在渲染期间执行，而不是渲染完成后。


# fshouldComponentUpdate
**讲概念**
1. shouldComponentUpdate 是一个在类组件中使用的，继承自 React.Component 的方法。
2. 它接收 2 个参数，一个是 nextProps, 一个是 nextState, 分别代表更新后的 props 和 state。
3. 它返回一个 Boolean 值，如果是 true 代表本组件需要重新渲染，如果是 false 代表本组件不用重新渲染。
**函数签名**
```ts
shouldComponentUpdate?(nextProps: Readonly<P>, nextState: Readonly<S>, nextContext: any): boolean;
```
**说用途**
本方法常用于实现更新前后 state/props 的比较逻辑，比如对于某些 state 的属性改变需要重新渲染，某些改变不需要渲染，这些可以通过 shouldComponentUpdate 里的逻辑实现。


# fPureComponent  fCompoennt和PureCompoennt的区别
1. React.PureComponent 与 React.Component 很相似。两者的区别在于 React.Component 并未实现 shouldComponentUpdate()，而 React.PureComponent 中以`浅层对比` prop 和 state 的方式来实现了该函数。
2. 如果 prop 或 state 中包含复杂的数据结构，则有可能因为无法检查深层的差别，产生错误的比对结果。
仅在你的 props 和 state 较为简单时，才使用 React.PureComponent，或者在深层数据结构发生变化时调用 forceUpdate() 来确保组件被正确地更新。
3. React.PureComponent 中的 shouldComponentUpdate() 将跳过所有子组件树的 prop 更新。因此，请确保所有子组件也都是“纯”的组件。
4. 你也可以考虑使用 immutable 对象加速嵌套数据的比较。


# fComponent
**讲概念**
1. React.Component 是使用 ES6 class 语法定义 React 组件的基类。
**说用途**
```jsx
class Greeting extends React.Component {
  render() {
    return <h1>Hello, {this.props.name}</h1>;
  }
}
```

# fforceUpdate
**讲概念**
1. forceUpdate 是定义在 React.Component.prototype 上的一个 API, 用于 React 类组件, 调用以后会强制重新渲染本组件。
2. forceUpdate 被调用后，将跳过 shouldComponentUpdate 的检查，强制执行 render 方法。
```jsx
class Greeting extends React.Component {
  update() {
    if (need) {
      this.forceUpdate();
    }
  }
  render() {
    return <h1 onClick={() => update()}>Hello, {this.props.name}</h1>;
  }
}
```


**四、你说一下使用 hooks 的注意事项**
1. 约定 hooks 命名以 useXX 开头。
2. hooks 必须在函数组件内使用，不能在类组件里使用。
3. hooks 必须在函数组件作用域顶部使用。
4. 每次函数组件 render 时，不能打乱 hooks 的执行顺序。比如把 hooks 放到`条件语句`或`循环语句`中是不行的。

# fhooks
**讲概念**
1. Hook 是 React 16.8.0 的新增特性, 它让函数组件也能做类组件能做的大部分的事。
2. 通过 hooks 函数组件有了自己的状态，可以处理副作用，能获取 ref 等。
**说用途** [fhooks解决了什么问题] [fhooks出现的原因]
1. 在组件之间复用`状态逻辑`; [f状态逻辑]
2. 集中管理复杂组件的相关逻辑;
3. 拥抱函数式编程;
*用途1.在组件之间复用状态*
1. 在 hooks 之前，组件的状态都用类组件实现，每个类组件都有一套独特的`状态逻辑`，类组件之间不能复用`状态逻辑`。 
2. 随着组件功能增强，类组件的状态变得越来越臃肿，这样维护成本就加大了，所以有必要做出一套能复用状态的方案，于是产生了 hooks。
3. 通过自定义 hook 的设计，可以灵活地将`状态逻辑`抽离、复用。
*用途2.集中管理复杂组件的相关逻辑*  [fuseEffect]
1. 这一点的代表hook是 useEffect。在类组件时期，相关代码常常被生命周期钩子分散了，比如在 componentDidMount 中注册事件回调，在 componentWillUnmount 中移除事件回调。这样 2 部分相关的代码就被分散开了，处理 1 个部分的时候必须同时考虑另外 1 个部分，这样很容易产生 bug。
2. useEffect 将相关逻辑集中到了一起，更容易维护，在第 1 个参数中接收副作用函数，可以在这个副作用函数里注册事件，然后这个副作用的返回值如果是一个函数，就会在组件卸载时执行，所以可以在返回的时候写一个函数移除事件回调。
3. 这样把相关逻辑都集中到 useEffect 的第 1 个参数中，使得维护起来更清晰了。
*用途3.拥抱函数式编程*
1. React团队发现 class 是学习 React 的一大屏障。因为:
  - 开发者必须理解 this 的工作方式
  - 开发者必须正确绑定事件处理器
  - class 的语法提案不够稳定
2. React团队发现使用 class 组件会使得一些优化措施无效，比如 class 不能很好的压缩，并且会使热重载出现不稳定的情况等。
所以，React 选择拥抱函数式编程。
而 16.8版本 之前函数组件支持的 React 特性较少，所以出现了 hook, 它使得开发者在非 class 的情况下可以使用更多的 React 特性。


# fhooks原理
1. hooks 本质上是一条单向链表，挂载在 fiber.memoizedState 上，函数组件 mount 时会把 这条链表 新建出来。
2. 源码里有一个 workInProgressHook 指针，每次函数组件重新渲染时，指针会复位到 fiber 的第 1 个 hook 上。
3. 函数组件执行，遇到 useState 等 hook 语句，开始执行 hook: 找到 workInProgressHook, 然后让 workInProgressHook 走到 next, 这样下一个 hook 语句执行的时候就能准确取到自己的 hook 对象。(前提是hook语句执行顺序不变)
4. 某一个 hook 语句获取到自己的 hook 对象以后，执行自己的逻辑。比如:
  1. useState 会计算 state, 返回 新的state 和 dispatchAction; 
  2. useRef 会在创建/返回一个只有 current 属性的对象，挂载在自己 hook 的 memoizedState 属性上。
  3. useMemo 会在 mount 时执行 create 存储缓存值; update 时检查 deps 是否变更，有变更重新执行 create 缓存，无变更返回缓存。
5. hook 有一个共同点，它们都会把 hook 的状态挂载在 hook.memoizedState 上。
**为什么hook不能放到条件语句里**
1. hook 的执行顺序是遍历链表实现的，是固定的。如果一个函数组件有多个 useState, 而某些 useState 在条件语句中，这样重新渲染的话 useState 的执行顺序就不是固定的了，可能会使某些 useState 取到错误的 hook, 从而执行出错。
```jsx
function Demo() {
  const [x1,setX1] = useState(0);    // fiber.memoizedState
  if (condition) {
    const [x2,setX2] = useState(1);  // fiber.memoizedState.next  
  }
  // 错误❌: 这里可能会取到 fiber.memoizedState.next, 因为上一个 useState 可能没执行!
  const [x3,setX3] = useState(2);    // fiber.memoizedState.next.next 
}
```

# fuseEffect
**讲概念**
1. React.useEffect 接收一个 create 函数，以及一个 deps 依赖数组。
2. 当 deps 中的任何一项改变时，React 会在组件更新完成后，异步执行 create 函数，并返回一个 destory 函数。
3. destory 函数和 create 函数一一对应，执行 destory 应该清除 create 造成的 effect。
4. React 会保证所有的 destory 都执行以后，再执行任意一个 create。
**说用途**
1. create 函数一般用来执行一些副作用，如设置定时器, 请求数据, 订阅数据 等，destory 函数用来作清除工作，如退订数据。
2. 通常情况下组件会多次渲染，那么在执行下一个 effect 之前，上一个 effect 的 destory 函数执行，清除上一次的副作用。
3. 对于某些特定值 x 应该单独给予一个 useEffect, 并将 x 作为 deps 的唯一元素，每次渲染时只关注 x 是否改变来决定是否产生副作用。
4. 如果想要执行只运行一次的 effect, 可以传递一个空的 deps 数组。
**执行时机**
1. create 函数会在 commit 阶段完成后异步执行(宏任务)，这时候浏览器已经完成了`布局`与`绘制`，可以获取到最新的 DOM 结点。 
2. 之所以设置成异步，是因为请求、订阅这种副作用操作，不应该阻塞浏览器的对屏幕的更新。
**产生背景**
1. 在 class 组件中，我们希望在组件`加载`和`更新`时执行同样的操作时，就要在 componentDidMout 和 componentDidUpdate 都调用，有些繁琐。
2. 如果使用 useEffect，就能使相关的逻辑在组件中能更加集中，便于维护。
**函数签名**
```ts
function mountEffect(create: () => (() => void) | void, deps?: Array<any>): void;
function updateEffect(create: () => (() => void) | void, deps?: Array<any>): void;
```
**举例子**
```jsx
function UseEffectDemo1() {
  // 组件重新渲染
  const [x, setX] = useState(0);
  // 定义副作用
  useEffect(() => {
    // 每次 x 改变就 create 一个 effect
    console.log('create执行');
    return () => {
      // 每次 x 改变，destory 上一次的 effect
      console.log('destory执行~');
    }
  }, [x]);
  return (
    <>
      <button onClick={() => setX(v => v + 1)}>更新x</button>
    </>
  )
}
```


# fuseLayoutEffect
**讲概念**
1. React.useLayoutEffect 会在所有的 DOM 变更之后同步调用 effect, 执行时机是 commit 阶段的 layout 步骤。
**说用途**
1. 可以使用它来读取 DOM 布局并同步触发重渲染。
2. 在浏览器执行绘制之前，useLayoutEffect 内部的更新计划将被同步刷新。
3. 官网建议尽可能使用 useEffect 以避免阻塞视觉更新。
**函数签名**
```ts
function mountLayoutEffect(create: () => (() => void) | void, deps?: Array<any>): void;
function updateLayoutEffect(create: () => (() => void) | void, deps?: Array<any>): void;
```

# fuseRef
**讲概念**
1. useRef 返回一个 ref 对象 { current: initialValue },  其中 initialValue 是 useRef 接收的第 1 个参数。
2. 这个 ref 对象在组件的整个生命周期内持续存在，这代表重新渲染组件，ref.current 的数据不会丢失。
**原理**
1. useRef 返回的其实是 hook.memoizedState, 它是一个缓存值，只要组件没被卸载，怎么更新都不会丢失的。 (hook = fiber.memoizedState)
**函数签名**
```ts
function mountRef<T>(initialValue: T): { current: T }
function updateRef<T>(initialValue: T): { current: T }
```
**举例子**
利用 useRef 得到的对象缓存在 fiber 上的特性，统计组件的渲染次数。
```jsx
function UseRefDemo1() {
  // 让组件重新渲染
  const [x, setX] = useState(0);
  // 记录 UseRefDemo1 组件的渲染次数, 初始化为0
  // 得到的就是一个 { current: 0 } 对象。
  const renderCountRef = useRef(0);
  // 每次更新计数+1
  renderCountRef.current++;
  // 渲染次数是不是奇数次
  const isOdd = renderCountRef.current % 2 !== 0;
  return (
    <>
      <h1>{isOdd ? '奇数次更新' : '偶数次更新'}</h1>
      <p>x: {x}</p>
      <button onClick={() => setX(v => v + 1)}>更新</button>
    </>
  )
}
```

# fuseEffect vs fuseLayoutEffect
1. useEffect 的 create 会在 commit 阶段完成以后异步执行; useLayoutEffect 的 create 在 commit 阶段的最后一个步骤 layout 阶段同步执行。
2. 所以，useLayoutEffect 的 DOM 更改会阻塞视觉更新，尽量要使用 useEffect 来避免这种情况。


# f自定义hook  f状态逻辑 
**讲概念**
从组件中抽离出来的只关注如何维护 state 的逻辑。
**如何封装自定义hooks**
1. 自定义 hook 是一个函数，其名称以`use`开头，函数内部可以调用其他的 hooks。
2. 自定义 hook 的 state 是完全独立的，hook 的每次调用都有一个完全独立的 state，因为在同一个组件中多次调用同一个自定义hook，它们的状态也互不影响。
**举例子**
自定义hook 里用自己的 useState + useEffect 来管理状态，最后返回 state, 外部直接使用这个被管理的 state。
```jsx
// 抽离状态逻辑，形成自定义hook
function useFriendStatus(id) {
  const [isOnline, setIsOnline] = useState(null);
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsOnline(props.friend.id % 2 === 0 ? true : false);
    }, 1000)

    return () => {
      clearTimeout(timer);
    };
  });
  return isOnline;
}
// 这 2 个组件复用状态逻辑
function ComponentFriendStatus(props) {
  const isOnline = useFriendStatus(props.friend.id);
  return isOnline ? 'Online' : 'Offline';
}
function ComponentFriendListItem(props) {
  const isOnline = useFriendStatus(props.friend.id);
  return (
    <li style={{ color: isOnline ? 'green' : 'black' }}>
      {props.friend.name}
    </li>
  );
}
```

**五、什么是高阶组件？有什么优缺点？**

# f高阶组件 fHOC  
**讲概念**
1. 高阶组件是一个函数，接收的参数为组件，返回值是一个新组件，组件将 props 转换为 UI，而高阶组件是将组件转换为另一个组件。
2. 高阶组件又称为 HOC, 是 React 中用于复用组件逻辑的一种高级技巧。 (Higher-Order Components)
3. HOC 自身不是 React API 的一部分，它是一种基于 React 的组合特性而形成的设计模式。
**优缺点**
HOC 的优点是:
1. 逻辑复用。
2. 不影响被包裹组件的内部逻辑。
HOC 的缺点是:
1. HOC 传递给被包裹组件的 props 容易和被包裹后的组件重名，进而被覆盖。
**说用途**
1. 抽离逻辑使代码复用。
2. 增强组件的功能。
**说用途1 抽离逻辑使代码复用**
比如说`添加日志功能`这个场景:
系统中各个业务模块往往都需要日志功能，那么就可以定义一个高阶组件，负责把传给它的组件都包装上一个日志功能，再返回包装完成的组件出来。
```jsx
function logProps(WrappedComponent) {
  return class extends React.Component {
    componentDidUpdate(prevProps) {
      console.log('Current props: ', this.props);
      console.log('Previous props: ', prevProps);
    }
    render() {
      return <WrappedComponent {...this.props} />;
    }
  }
}
```
**说用途2 增强组件的功能**
比如给某个组件增加一个统计自己渲染时间的功能:
方法是新建一个子类组件，监听父组件的 componentWillMount 和 componentDidMount，计算出时间间隔。
```jsx
class Home extends React.Component {
    render() {
        return <h1>Hello World</h1>;
    }
}
function withTiming(WrappedComponent) {
    return class extends WrappedComponent {
        constructor(props) {
            super(props);
            this.start = 0;
            this.end = 0;
        }
        UNSAFE_componentWillMount() {
            super.componentWillMount && super.componentWillMount();
            this.start = Date.now();
        }
        componentDidMount() {
            super.componentDidMount && super.componentDidMount();
            this.end = Date.now();
            console.log(`${WrappedComponent.name} 组件渲染时间为 ${this.end - this.start} ms`);
        }
        render() {
            return super.render();
        }
    };
}
export default withTiming(Home); 
```
**三方库**
1. HOC 在第三方库中很常见，比如 Redux 的 connect 函数、Relay 的 createFragmentContainer。
```jsx
// redux 的 connect 函数
const ConnectedComment = connect(commentSelector, commentActions)(CommentList);
// 刚刚发生了什么？！如果你把它分开，就会更容易看出发生了什么:
// connect 是一个函数，它的返回值为另外一个函数。
const enhance = connect(commentListSelector, commentListActions);
// 返回值为 HOC，它会返回已经连接 Redux store 的组件
const ConnectedComment = enhance(CommentList);
```


**六、React 为什么需要 fiber?**
1. 在 React15 以前，`协调器`采用`同步的`、`递归的`方式创建`虚拟DOM`, 递归过程一旦开始就不能中断。如果组件树的层级很深，这中同步的`协调`过程会占用浏览器的`渲染主线程`很多时间, 导致浏览器没有时间更新视图, 造成卡顿。
2. 为了解决这个问题，16版本以后，React 将`同步的无法中断的更新`重构为`异步的可中断的更新`。实际上就是将一次大的更新划分为多个小的工作单元，每个工作单元称为 Fiber, 执行完一个 Fiber 就检查一下是否超过时间，超过了就暂停工作，把一帧中的剩余时间交还给浏览器去渲染视图，然后在下一次宏任务中继续执行下一个 Fiber，实现了一次大更新的`中断`与`恢复`，这种不阻塞浏览器渲染的更新机制，符合 React `快速响应`的理念。


# fFiber
**讲概念**
Fiber 可以从 3 个方面来理解:
1. 作为架构来说，之前 React15 的`协调器`采用递归的方式执行，数据保存在递归调用栈中，所以被称为 Stack Reconciler。React16的`协调器`基于 Fiber 节点实现，被称为 Fiber Reconciler。
2. 作为静态的数据结构来说，每个 Fiber 结点对应一个 React组件, Fiber结点保存了该组件的类型（函数组件/类组件/原生组件...）、对应的DOM节点等信息。
3. 作为动态的工作单元来说，每个 Fiber 节点保存了本次更新中该组件改变的状态、要执行的工作（需要被删除/被插入页面中/被更新...）。
**Fiber的数据结构**
```js
function FiberNode(tag, pendingProps, key, mode) {
  
  /* 1. 作为静态数据结构的属性 */
  // Fiber对应组件的类型 Function/Class/Host...
  this.tag = tag;
  // key属性, 用户提供, 主要用于 DOM DIFF。
  this.key = key;
  // 大部分情况同type，某些情况不同，比如FunctionComponent使用React.memo包裹
  this.elementType = null;
  // 对于 FunctionComponent，指函数本身，对于ClassComponent，指class，对于HostComponent，指DOM节点tagName
  this.type = null;
  // Fiber对应的真实DOM节点
  this.stateNode = null;

  /* 2. 用于连接其他Fiber节点形成Fiber树 */
  // 指向父级Fiber节点
  this.return = null;
  // 指向子Fiber节点
  this.child = null;
  // 指向右边第一个兄弟Fiber节点
  this.sibling = null;
  // 结点`在同级结点形成的数组中`的索引
  this.index = 0;

  this.ref = null;

  /* 3. 作为动态的工作单元的属性 */
  // 在一次更新中，代表element创建
  this.pendingProps = pendingProps;
  // 记录上一次更新完毕后的props
  this.memoizedProps = null;       
  // 类组件存放setState更新队列，函数组件存放
  this.updateQueue = null;         
  // 类组件保存state信息，函数组件保存hooks信息，dom元素为null
  this.memoizedState = null;       
  // context或是时间的依赖项
  this.dependencies = null;        

  // 描述fiber树的模式，比如 ConcurrentMode 模式
  this.mode = mode;                

  // effect标签，用于收集effectList
  this.effectTag = NoEffect;
  // effect标签，用于收集effectList
  this.nextEffect = null;

  // 第一个effect
  this.firstEffect = null;
  // 最后一个effect
  this.lastEffect = null;

  /* 调度优先级相关 */
  this.lanes = NoLanes;
  this.childLanes = NoLanes;

  /* 指向该fiber在另一次更新时对应的fiber */
  this.alternate = null;
}
```


**七、说一下你理解的 dom diff**
# fDOM DIFF  fDiff
**讲概念**
1. Diff算法的本质是对比`更新前虚拟dom树`和`更新后虚拟dom树`，找出两者之间的差异。
2. React 原理中，是在对比`当前结点的大儿子`和`新产生的React元素`, 从而产生`workInProgress的大儿子`。
3. 如果是
**说实现**
1. React 的 DIFF 算法分为 单结点DIFF 和 多结点DIFF。
2. 这里的`单结点`或`多结点`指的是新结点，新结点只有单个就是单结点diff，新结点有多个就是多结点diff。
**实现一、单结点**
单结点DIFF执行的是 reconcileSingleElement 函数。

因为只有一个新结点，所以通过 sibling 指针遍历老结点即可。遍历过程比较新老结点的 type 和 key, 有三种情况:
  1. 如果 type 和 key 都相同，说明这个`老结点`可以复用，标记`剩余的老结点`为`删除`，返回这个可复用的老结点。
  2. 如果 key 相同，但是 type 不同，`老结点`和`老结点的弟弟们`都标记为删除，跳出遍历，直接新建一个结点，标记`插入`。
  3. 如果 key 不同，删除这个老结点，继续遍历下一个老结点。如果遍历完了还是没有结点可复用，那就新建一个结点，标记`插入`。
  
  **单结点[例子]**
  比如: liA,liB,liC => liB
  DIFF过程就是:  
  liA => liB ❌ Deletion
  liB => liB ✅ 复用
  liC        ❌ Deletion


**实现二、多结点**
多结点DIFF执行的是 reconcileChildrenArray 函数, 主要分 3 步:
1. 建立老结点的查询表。
2. 遍历更新后的结点数组, 重点在于比较老结点索引。
3. 标记不可复用的老结点为删除。
**实现二、多结点 1.遍历前建立老结点的查询表**
1. 新建一个 Map, 将`老结点数组`中每个结点保存在以`结点key`为`key`，`结点本身`为`value`的 Map 中。
2. 这样就能在 O(1) 的时间复杂度内通过 key 找到老结点，这也是我们要写 key 的原因。
**实现二、多结点 2.遍历更新后的结点数组, 重点在于比较老结点索引**
遍历`新结点数组`, 用新结点的 key 去 Map 中查找:

  - 如果能找到一个值，说明这个新结点有一个`可复用的老结点`。
    这个`可复用的老结点`只有 2 种可能: 1 种是更新后它移动了，1种是更新后它没移动。
    React在Diff里做的就是判断`可复用的老结点`是否移动了:
    
      1. React 把最近的一个`可复用老结点在老数组中的索引`记录到 lastPlacedIndex 里。
         由于遍历`新结点数组`是从左往右的，如果后续的`可复用老结点`在更新前后没有移动，那么`可复用老结点的索引`应该始终大于`lastPlacedIndex`。
      
      2. 接下来判断`可复用老结点的索引`是否大于`lastPlacedIndex`:
          1. 如果大于或等于, 说明这个结点没有移动, 但是要更新 lastPlacedIndex = oldNode.index。
          2. 如果小于, 说明这个结点在更新后向右移动了，标记为`Placement`, Placement 对应 parent.appendChild, 会添加到最右边。

  - 如果找不到值，说明新结点是新增的，标记为`Placement`, 等待 commit 阶段新建对应的`DOM结点`插入页面。
**实现二、多结点 3.遍历后删除不可复用的老结点**
1. 查询表中的结点，一旦发现是`可复用的`，就会被删除。
2. 如果遍历新结点数组完成后，查询表还有结点，那就全部标记为`Deletion`，因为新结点里面没有它们，不能复用的。

  **多结点[例子]**
  老结点            A        B       C              D                   E                   F(不可复用,删除,Deletion)   
  新结点            A        C       E              B                   G                       D
                  复用     复用     复用         复用(老B右移)    不可复用(插入,Placement)    复用(老D右移,Placement)
  lastPlaceIndex   0        2       4              4                   4                       4
                  >=       >=      >=    B.oldIndex < lastPlacedIndex              D.oldIndex < lastPlacedIndex

**DIFF注意点**
1. 在多结点DIFF中，React只会将结点往后移动，如果我们要将节点从后往前移，实际上是把目标结点前面的结点全部往后移动了。这会影响性能，所以尽量不要把结点从后往前移动。
2. 如果用户没有写 key, 那么 React 认为 key 是 null, 在更新前后对比时，就会得出 key 相同的结论。
3. 检查出 key, type 都相同, 会复用 current 的属性，如 flags, childLanes, lanes, child, memoizedProps, memoizedState, updateQueue, sibling, index, ref。
4. 当 key, type 都不变，只有常规属性改变时，React 会复用 current.alternate 作为 workInProgress，把 pendingProps 放到 workInProgress.pendingProps 上，进行后续状态更新。


# fscheduler
**讲概念**
1. Scheduler 是一个在浏览器环境中实现`调度功能`的包。
2. 它提供了 2 个功能，一个是时间切片，一个是优先级调度。
3. 当前 Scheduler 用于 react 内部，但是 react 团队计划将它作为一个独立的包。
**说用途**
1. 时间切片
2. 优先级调度
**时间切片** [f时间切片]
1. 时间切片的目的是在浏览器一帧的空闲时间执行 React 的任务，不去占用`重排重绘`的时间，从而以提供快速响应的效果。
2. 主流浏览器的刷新频率是 60 Hz, 也就是一帧 16.6 ms。
3. 时间切片默认的任务执行时间是 5ms, 超过执行时间后, 会通过 shouldYield 退出 while 循环, 中断任务, 重新进入`调度`阶段。
4. 调度完成的下个任务被放到`宏任务`里等`下一帧`执行，那么在`这一帧`中浏览器就取回了控制权，可以在这一帧的剩余时间执行`渲染视图`等操作。
5. 所以，在执行一个耗时很长的 React任务时，会看到任务被切分在一片一片的 5ms 多一点的时间里执行，这就是`时间切片`。
**优先级调度** [f优先级调度]
1. 调度器提供了 2 个队列，一个存放`已就绪任务`，一个存放`未就绪任务`，分别叫 taskQueue 和 timerQueue, 都是用`小根堆`实现。
2. 当一个 task 到来时，先通过优先级计算出它的`过期时间`, 然后根据`过期时间`插入`小根堆`里, 再维持住`小根堆`。
3. 同时把 timerQueue 里已经就绪的任务加入 taskQueue。
4. 开始调度后，在 MessageChannel 里调度的是 flushWork, 代表把 task 刷到执行区准备执行, 它会弹出 taskQueue 堆顶的任务并执行，循环这个过程直到被 shouldYieldToHost 中断。
**高优任务如何打断低优任务** [f打断] [f高优打断低优]
1. 比如说，一个耗时很长的低优任务正在执行，源码里是一个 while 循环里不断执行 performUnitOfWork。 [低优render100个]
2. 但是每过 5ms, performUnitOfWork 就会被 shouldYield 中断, 退出 while 循环。
3. 退出以后，会执行`调度器`提供的调度 API 调度任务，调度时会根据`优先级`决定下个任务。
4. 如果没有`高优任务`，`调度器`会让这个`低优任务`在下次浏览器时宏任务执行时恢复执行，宏任务用的是 MessageChannel。
5. 如果有`高优任务`，`调度器`会优先调度高优任务，于是这次的宏任务让高优任务先执行，这就是`低优任务被打断`的情况。 [被打断时render了80个]
6. 当高优任务完整地结束以后，`调度器`再次调度所有任务，发现之前的低优任务还存在，于是让它继续执行，这就是`恢复`的情况。 [恢复执行render20个]
**React的调度流程是什么样的**
1. 一次状态变化如 setState 会产生一个任务，这个任务会交给`调度器`。
2. `调度器`中有 2 个队列，一个 taskQueue (就绪任务), 一个 timerQueue (未就绪任务), 都是小根堆。
3. 根据`优先级`计算出过期时间，然后将 task 排序，取出最早过期的任务开始执行。


# fMessageChannel
**讲概念**
1. MessageChannel 接口允许我们创建一个新的消息通道，并通过它的两个 MessagePort 属性发送数据。
2. onmessage 指定的回调函数将在`宏任务`中执行。
**举例子**
```js
/* 建立一个消息通道 */
const channel = new MessageChannel();
/* 建立一个port发送消息 */
const port = channel.port2;
/* 接收消息 */
channel.port1.onmessage = function(){
  /* 宏任务中, 执行 React 任务 */
  scheduledHostCallback();
};
/* 向浏览器请求执行更新任务 */
port.postMessage();
```
**React为什么用MessageChannel**
1. MessageChannel 比 setTimeout 执行时机更加靠前，能让任务更早触发。
2. 递归执行 setTimeout 时，最后间隔时间会变成 4ms 左右，而不是最初的 1ms，一帧才 16ms，这就造成了浪费。
```js
let time = 0
let nowTime = +new Date()
let timer = null;
const poll = function(){
    timer = setTimeout(()=>{
        const lastTime = nowTime
        nowTime = +new Date()
        console.log( '递归setTimeout(fn,0)产生时间差：' , nowTime -lastTime )
        poll()
    },0)
    time++
    if(time === 20) clearTimeout(timer)
}
poll();
```


# cra调试技巧 f调试源码
在 ～YourProject/scripts/start.js 里，写上如下配置, 即可在运行时监听 react 库动态调试:
```js
const serverConfig = {
    host: HOST,
    port,
    // 我加的!!! 便于开发环境调试源码
    watchFiles: [
      'src/**/*',
      'node_modules/react/cjs/react.development.js',
      'node_modules/react-dom/cjs/react-dom.development.js',
      'node_modules/scheduler/cjs/scheduler.development.js',
    ],
  };
```