# 综合面回放
面试官提的问题记录:
1. 工资？
我工资是 13k
2. 为什么离职？
  * 因为我们团队的技术氛围不浓厚，我们没有任何的技术分享，也不重视前端，我的技术在这里得不到很好的发展。
  * 离职也是想开拓自己的眼界，去跟更优秀的团队做更优秀的产品，实现自己的人生价值。
3. 离职这段时间干了什么？
  * 学了一段时间算法 (二叉树、链表、图)
  * 读了一本书，叫《编码 -- 隐匿在计算机软硬件背后的语言》, 讲述从 0 到 1 做一个计算机的过程。
  * 重温了一下 React 和 Webpack 的源码
4. 为什么这么长时间没有找到工作？
  有两点原因:
  * 疫情期间不好找工作
  * 想借此机会好好地沉淀一下自己的技术
5. 介绍一下自己？
  面试官您好，我叫陈允翼，是一名 3 年开发经验的前端工程师。我之前是在深圳市台电实业有限公司，主要使用的前端框架是 React，对 React 的原理有比较深入的学习。我在原来公司负责的是会议相关的业务，具体来说，我对公司的会议管理平台进行过性能优化，参与过支持网页设计器的 canvas2D 渲染引擎，也为团队开发过脚手架。我的自我介绍完毕，谢谢面试官。
6. 你来聊一下`React的合成事件`和`浏览器的原生事件`有什么区别？
  ...
7. setState 是同步还是异步？
  ...
8. React 如何防止子组件重复渲染？
  ...
9. React.memo 和 useMemo 的使用场景
  ...
10. 你说一下使用 hooks 的注意事项
  ...
11. hooks 的原理是什么？
  ...
12. 四、React 如何封装自定义 hooks?
  ...
13. 五、什么是高阶组件？有什么优缺点？
  ...
14. redux 用过吗？使用过什么状态管理工具？
  ...
15. 六、React 为什么需要 fiber? 
  ...
16. React 的 Diff 算法
  ...
17. Webpack 有用过吗？
  有。
18. Webpack 的 Tree Shaking 是什么？有什么作用？原理是啥？
  ...
19. Webpack 的工作流程是怎么样的？
  ...
20. Webpack 如何实现持久化缓存？🔥
  ...
21. Webpack 的 Plugin 和 Loader
  ...
22. 现在有刷算法吗？刷了多少道？
  算法我是报了一个马士兵教育的算法班去学，学了 1 年，班里的题加上力扣的题已经刷了四百多道了。
23. 你负责的是一个会议管理平台这个项目，来介绍一下这个项目。
  ...
24. 会议日志长列表数据量大，操作卡顿，有多卡顿？
  ...
25. 代表资料包上传的速度是多少？怎么跟后台做规划的？
  ...
26. 首屏优化的原因？首屏优化的影响？哪些因素影响？
  ...


**一、React的合成事件和浏览器的原生事件有什么区别？**
# f事件系统
事件系统是 React 模拟浏览器的事件运行机制，实现的一套提供`合成事件、冒泡/捕获机制、事件委托`的系统。
**React为什么有自己的事件系统?**
1. 提供兼容性。
2. 集中委托、统一管理。
3. 支持 SSR 和 跨端。
**React为什么有自己的事件系统? 1.提供兼容性。**
1. 对于不同的浏览器，对事件存在不同的兼容性，React 想实现一个兼容全浏览器的框架 (e.xx都可以用)，为了实现这个目标就需要创建一个兼容全浏览器的事件系统，以此抹平不同浏览器的差异。
**React为什么有自己的事件系统? 2.集中委托、统一管理。**
1. v17 之前 React 事件都是绑定在 document 上，v17 之后 React 把事件绑定在应用对应的容器 container 上(div#root)，将事件绑定在同一容器之后，触发回调都通过 dispatchEvent 函数来管理。这样做防止很多事件直接绑定在原生的 DOM 元素上造成不可控的情况。
2. 由于不是绑定在真实的 DOM 上，所以 React 需要模拟一套事件流: 事件捕获 -> 事件源 -> 事件冒泡，也包括重写一下事件源对象 event。
**React为什么有自己的事件系统? 3.支持 SSR 和 跨端。**
1. 这种事件系统，大部分处理逻辑都在底层处理了，这对后期的 ssr 和跨端支持度很高。

# f合成事件
React 应用中，元素绑定的事件并不是原生事件，而是React 合成的事件，比如 onClick 是由 click 合成，onChange 是由 blur ，change ，focus 等多个事件合成。
**合成事件对象的结构**
```ts
interface BaseSyntheticEvent<E = object, C = any, T = any> {
  // 浏览器的原生事件
  nativeEvent: E;
  // 绑定了合成事件的 React 原生组件对应的 DOM 结点，如 button 的上级 div
  currentTarget: C;
  // 触发了合成事件的 React 原生组件对应的 DOM 结点，如 button
  target: T;
  // 自定义的阻止浏览器默认行为方法
  preventDefault(): void;
  // 自定义的停止冒泡方法
  stopPropagation(): void;
  // ...
}
```

# f事件委托
1. React 的事件不是绑定在元素上的，而是统一绑定在顶部容器上，在 v17 之前是绑定在 document 上的，在 v17 改成了 div#root 容器上, 也就是 ReactDOM.render 或者 ReactDOM.createRoot 接收的 rootNode。
2. 当事件触发时，实际触发回调的是在 root 上的监听器, 然后执行 dispatchEvents 函数，按浏览器`冒泡/捕获`的事件传播流程收集监听器，然后统一触发。

# f事件注册 f事件绑定
1. 在 React 新版的事件系统中，在 createRoot 会一口气向外层容器上注册完全部事件。
2. 建立`合成事件`映射到`原生事件数组`的映射表。比如 onChange 事件是由 原生的change,input,keydown,keyup等事件合成的, 这个对应关系由各个事件插件提供，最终原生事件形成一个集合`allNativeEvents`,映射关系形成一张表`registrationNameDependencies`。
3. 遍历`allNativeEvents`这个事件集合，调用`listenToAllSupportedEvents`这个 API 注册`冒泡阶段`和`捕获阶段`的回调，回调函数统一成内置了优先级的`dispatchEvent`函数, 注册在`div#root`上。
4. 如果发生一次 click 事件，就会触发 2 次`dispatchEvent`, 1 次是捕获阶段, 1 次是冒泡阶段。
**合成事件-原生事件映射关系表**
```js
const registrationNameDependencies = {
  onChange: ['change', 'click', 'focusin', 'focusout', 'input', 'keydown', 'keyup', 'selectionchange'],
  onClick: ['click'],
  ...
}
```

# f事件触发
1. 在 div#root 上触发回调，这个回调是内置了优先级的 dispatchEvent 函数。
2. dispatchEvent 调用 batchedUpdates 开始批量更新，其中执行 dispatchEventsForPlugins, 它的执行步骤如下:
  1. 得到触发事件的 Fiber 结点。
  2. 查询对应表，将`原生事件`转为`React合成事件`, 根据`冒泡/捕获`阶段补上后缀。
  3. 从触发事件的 Fiber 开始，一路往上走到 rootFiber, 沿途收集监听该`React合成事件`的元素, 以及它们的回调函数, 封装一下然后 push 到 dispatchQueue 里。
  4. 最后遍历 dispatchQueue, 执行所有监听该`React合成事件`的回调函数，如果是`捕获阶段`就逆序遍历，如果是`冒泡阶段`就正序遍历, 中途遇到 `e.stopPropagation()`的话就停止传播, 终止遍历，这个过程跟浏览器的事件机制保持一致。


# f事件插件
**讲概念**
1. 事件插件是一个记录了`React合成事件`和`浏览器原生事件`之间的映射关系的这么一个插件。
**说用途**
事件插件统一提供 2 个方法， 一个 registerEvents 用来注册事件，一个 extractEvents 用来提取事件。
1. registerEvents
比如 ChangeEventPlugin 定义了 onChange 对应原生的 'change', 'input', 'keydown', 'keyup' 等多个事件，这些原生事件在初始化的时候就会注册到 div#root 上，提供的回调统一是 dispatchDiscreteEvent。
2. extractEvents
触发事件后，浏览器进入DOM事件的`冒泡/捕获`阶段, React把`原生事件`转换成`react事件`，然后从触发事件的元素开始，一路往上检查沿途的元素的 props 是否注册了此刻 React 事件的回调，比如 onChange, onClick 等，如果有就加入 dispatchQueue 中，这个过程就是为了收集事件。


**二、setState是同步还是异步** [fsetState] [fsetState是同步还是异步]
对于不同模式的 React 应用, setState 的表现是不一样的:
- 在 legacy 模式下，
  - 当命中了 batchedUpdates 逻辑时，进入批处理计算所有状态, 然后异步更新 (App 函数重新执行)，所以 setState 是异步的;
  - 没有命中 batchedUpdates 时(比如用 setTimeout 包裹脱离 BatchedContext 上下文)，状态更新会同步执行，所以 setState 是同步的。
- 在 concurrent 模式下，
  - 状态始终是异步更新，所以 setState 是异步的。

❓区分同步还是异步:
```js
this.state = { count: 0 };
this.setState(state => ({ count: state.count+1 }));
this.setState(state => ({ count: state.count+1 }));
// 如果打印了 2, 说明 this.state 在每次 setState 的同时就变化了，那就是同步。
// 如果打印了 0, 说明 2 次 setState 执行完了 this.state 也没变，那就是异步。
console.log(this.state.count);
```

# fsetState
**讲概念**
1. this.setState 用于请求一次React应用更新, 它只能用于类组件。
**说用法**
1. 接收 2 个参数，第 1 个可以是对象或函数，第 2 个是一个回调函数，无返回值。
2. 第 1 个参数定义将要改变的状态。
3. 第 2 个参数为可选的回调函数，它将在 setState 完成合并并重新渲染组件后执行。通常，我们建议使用 componentDidUpdate() 来代替此方式。
**函数签名**
```ts
setState(newState: Object | Function, functionAfterRender: Function): void;
```
**举例子1. 状态函数**
```jsx
this.setState((state, props) => {
  return {counter: state.counter + props.step};
});
```
**举例子2. 状态对象**
```jsx
this.setState({ count: 1 }, () => console.log('渲染完成'));
```


# fbatchedUpdate
**讲概念**
1. 一次回调中触发多次 setState，将这多次更新合并为一次更新的优化手段，就叫 batchedUpdates。
2. React 会在一个 BatchedUpdate 上下文中执行这次事件回调。
**优缺点**
缺点:
1. 在 legacy 模式下整个过程需要同步执行，如果将 setState 作为异步调用，那么执行 setState 时已经离开了 batchedUpdates 的上下文，也就获取不到 BatchedContext 了。
**说实现**
在 legacy模式 和 concurrent模式 下, batchedUpdate 的实现是不同的。
**说实现1. legacy模式**
1. 接收一个函数 fn, fn 通常是组件的 onClick 等事件回调，其中包含多个 setState 方法。
2. fn 执行之前，将它的上下文`或上`一个 BatchedContext，fn 执行完成后，再恢复成之前的上下文。
3. fn 执行时，其中的 setState 会获取到 executionContext, 这时就会得到 BatchedContext，那么就不会立马触发更新，而是在 batchedUpdate 的 finally 里，执行 flushSyncCallbackQueue 里触发更新。
```js
// ~/react-reconciler/src/ReactFiberWorkLoop.js
export function batchedUpdates(fn, a) {
  const prevExecutionContext = executionContext;
  executionContext |= BatchedContext;
  try {
    return fn(a);
  } finally {
    executionContext = prevExecutionContext;
    // ...
    flushSyncCallbacksOnlyInLegacyMode();
  }
}
```
**说实现2. concurrent模式**
1. 第一个 setState 进来, 得到一个优先级, 产生一个任务，通过 scheduleCallback 调度。(performConcurrentWorkOnRoot)
2. 第二个 setState 进来, 得到一模一样的优先级, 然后准备调度的时候(ensureRootIsSchedule), 先获取 root.callbackNode 发现已经有任务正在调度，于是取出这个任务的优先级 root.callbackPriority 和此刻想要调度任务的优先级对比，发现一致, 那么第二次更新就不会被调度, 也就是复用了正在调度的任务。
这样就把多次 setState 合并成了一个任务，只造成一次`更新`。
3. 关键就在于，同一个 onClick 里的所有 setState，得到的 lane 都是一致的，从而产生的优先级一致，就可以复用任务。


# flegacy
**讲概念**
1. 比如 React17 版本，通过 `ReactDOM.render(<App />, root)` 开启，这种 React 应用产生的更新都是没有优先级的。

# fconcurrent
**讲概念**
1. 在 React18 通过 `ReactDOM.createRoot(root).render(<App />)` 开启，React 应用产生的更新具有优先级。
2. 注意导入的语句变成 `import ReactDOM from 'react-dom/client';`。


# fscheduleUpdateOnFiber
**讲概念**
React 每次调度更新都会执行的函数。
1. 在 legacy 模式下，更新优先级都是 SyncLane，并且当前环境是 NoContext 的话 (脱离 BatchedUpdate 上下文)，就会调用 flushSyncCallbacksOnlyInLegacyMode 执行状态的同步更新。这意味着在 setState 之后能同步获取到更新后的 state。
2. 在 concurrent 模式下，不会执行 flushSyncCallbacksOnlyInLegacyMode, 状态会异步地更新。


**三、React 如何防止子组件重复渲染？**
# f性能优化
React 性能优化主要关注点在于: 避免子树的不必要渲染。
**如何防止子组件重复渲染**
如果不考虑性能优化 API，仅考虑 React 默认的`判断状态是否改变`的策略的话， (性能API如: shouldComponentUpdate, memo, forceUpdate)
对于一个 React 组件来说，能够引起它重复渲染的原因只有 3 个:
1. props: 从父组件传递下来。
2. state: 自己维护。
3. context: 自己选择要接收哪些 context。
只要这 3 者不变，组件就不会重新渲染。 其中 state 和 context 都是自己维护的, 更新前后只要自己维持数据不变就行，而 props 是父组件传递下来的，更新前后是否保持不变，就要看 props 的比较策略是怎么定的。
**fprops比较策略**
1. React 默认的 props 比较策略是`引用比较`, 也就是说，只要更新前后 props 的引用变了，React 就会认为组件发生了更新。在这种策略下，即使更新前后 props 都是传递一个空对象，因为两次得到的空对象引用不同，所以 React 也会认为子组件状态改变。
2. 如果使用了 React 的性能优化 API, 比如 React.memo, 或者是 useMemo, 那么 props 的比较策略就会改为`浅比较`, 这时更新前后再传递空对象，就会认为前后收到的 props 是相同的，子组件的状态没有改变，也就不需要重新渲染了。
3. 不过，把 props 的比较策略改成`浅比较`以后，会耗费多一点性能，因为`浅比较`要遍历两个对象的 key，而`引用比较`只对比引用即可, 这样就需要考虑，浅比较多耗费的性能会不会比子组件重新render的性能还要多，这是需要权衡利弊的地方。

# fmemo fReact.memo [下一项是useMemo, 面试常常要求对比] [f性能优化API]
**讲概念**
React.memo 是一个高阶组件，它接收一个组件，返回一个可能是缓存的组件。
**讲用法**
React.memo 接收两个参数，一个`React组件`，以及一个`比较函数`，返回一个`缓存值`。
- 当`比较函数`返回 true 时，React 将跳过被 React.memo 包裹的组件的渲染，直接返回最近一次的渲染结果;
- 当`比较函数`返回 false 时，组件重新渲染，React.memo 返回重新渲染的结果。
- 如果没有提供`比较函数`, memo 默认会`浅比较`更新前后的 props 来返回一个布尔值。
**函数签名**
```ts
function memo(Component: T, areEqual?: (prevProps: ComponentProps, nextProps: ComponentProps) => boolean): T;
```
**说原理**
1. 当 React Fiber 树更新时，到达一个 memo 的结点，会执行 beginWork -> updateSimpleMemoComponent.
2. pdateSimpleMemoComponent 中使用 shallowEqual(prevProps, nextProps) 浅比较 更新前后的props。
如果发现没有改变:
* 那么命中 bailout 逻辑，返回 bailoutOnAlreadyFinishedWork 的执行结果，也就是返回上一次的渲染结果(current.child 上一次的子fiber)
* 也就是说, 不需要重新执行 函数组件 来获取子Fiber, 达到性能优化的目的。
**举例子**
```jsx
// 每次 React 应用更新时，浅比较 MemoComponent 的 props, 如果一致，复用上一次的渲染结果，不用重新渲染。
const MemoComponent = React.memo(MiddleComponent, (prevProps, nextProps) => shalldowEqual(prevProps, nextProps));
```


# fuseMemo [上一项是React.memo]
**讲概念**
useMemo 是 React 提供的一个 hook, 只能用于函数组件。
**讲用法**
useMemo 接收两个参数，一个是`create函数`，一个是`依赖数组`，返回一个缓存值。
- 当函数组件重新渲染时，如果`依赖数组`中的任何一项发生了改变，`create函数`就会重新执行，返回新的缓存值。
- 这种优化有助于避免在每次渲染时都进行高开销的计算。
**函数签名**
```ts
function useMemo<T>(factory: () => T, deps: DependencyList | undefined): T;
```
**举例子**
```jsx
const memoizedValue = useMemo(create, deps);
```
**注意**
1. 如果没有提供依赖项数组，useMemo 在每次渲染时都会计算新的值。
2. 如果传入 deps 一个空数组，那么 useMemo 将只保留第一次的缓存，不会刷新缓存。
3. 不要把副作用这类的操作放在 create 函数中，这属于 useEffect 的适用范畴。传入 useMemo 的函数会在渲染期间执行，而不是渲染完成后。


# fshouldComponentUpdate [f性能优化API]
**讲概念**
1. shouldComponentUpdate 是一个在类组件中使用的，继承自 React.Component 的方法。
2. 它接收 2 个参数，一个是 nextProps, 一个是 nextState, 分别代表更新后的 props 和 state。
3. 它返回一个 Boolean 值，如果是 true 代表本组件需要重新渲染，如果是 false 代表本组件不用重新渲染。
**函数签名**
```ts
shouldComponentUpdate?(nextProps: Readonly<P>, nextState: Readonly<S>, nextContext: any): boolean;
```
**说用途**
本方法常用于实现更新前后 state/props 的比较逻辑，比如对于某些 state 的属性改变需要重新渲染，某些改变不需要渲染，这些可以通过 shouldComponentUpdate 里的逻辑实现。


# fPureComponent  fCompoennt和PureCompoennt的区别
1. React.PureComponent 与 React.Component 很相似。两者的区别在于 React.Component 并未实现 shouldComponentUpdate()，而 React.PureComponent 中以`浅层对比` prop 和 state 的方式来实现了该函数。
2. 如果 prop 或 state 中包含复杂的数据结构，则有可能因为无法检查深层的差别，产生错误的比对结果。
仅在你的 props 和 state 较为简单时，才使用 React.PureComponent，或者在深层数据结构发生变化时调用 forceUpdate() 来确保组件被正确地更新。
3. React.PureComponent 中的 shouldComponentUpdate() 将跳过所有子组件树的 prop 更新。因此，请确保所有子组件也都是“纯”的组件。
4. 你也可以考虑使用 immutable 对象加速嵌套数据的比较。


# fComponent
**讲概念**
1. React.Component 是使用 ES6 class 语法定义 React 组件的基类。
**说用途**
```jsx
class Greeting extends React.Component {
  render() {
    return <h1>Hello, {this.props.name}</h1>;
  }
}
```

# fforceUpdate
**讲概念**
1. forceUpdate 是定义在 React.Component.prototype 上的一个 API, 用于 React 类组件, 调用以后会强制重新渲染本组件。
2. forceUpdate 被调用后，将跳过 shouldComponentUpdate 的检查，强制执行 render 方法。
```jsx
class Greeting extends React.Component {
  update() {
    if (need) {
      this.forceUpdate();
    }
  }
  render() {
    return <h1 onClick={() => update()}>Hello, {this.props.name}</h1>;
  }
}
```


**四、你说一下使用 hooks 的注意事项**
1. 约定 hooks 命名以 useXX 开头。
2. hooks 必须在函数组件内使用，不能在类组件里使用。
3. hooks 必须在函数组件作用域顶部使用。
4. 每次函数组件 render 时，不能打乱 hooks 的执行顺序。比如把 hooks 放到`条件语句`或`循环语句`中是不行的。

# fhooks
**讲概念**
1. Hook 是 React 16.8.0 的新增特性, 它让函数组件也能做类组件能做的大部分的事。
2. 通过 hooks 函数组件有了自己的状态，可以处理副作用，能获取 ref 等。
**说用途** [解决了什么问题] [出现的原因]
1. 在组件之间复用`状态逻辑`; [f状态逻辑]
2. 集中管理复杂组件的相关逻辑;
3. 拥抱函数式编程;
**用途1.在组件之间复用状态**
1. 在 hooks 之前，组件的状态都用类组件实现，每个类组件都有一套独特的`状态逻辑`，类组件之间不能复用`状态逻辑`。 
2. 随着组件功能增强，类组件的状态变得越来越臃肿，这样维护成本就加大了，所以有必要做出一套能复用状态的方案，于是产生了 hooks。
3. 通过自定义 hook 的设计，可以灵活地将`状态逻辑`抽离、复用。
**用途2.集中管理复杂组件的相关逻辑**  [fuseEffect]
1. 这一点的代表hook是 useEffect。在类组件时期，相关代码常常被生命周期钩子分散了，比如在 componentDidMount 中注册事件回调，在 componentWillUnmount 中移除事件回调。这样 2 部分相关的代码就被分散开了，处理 1 个部分的时候必须同时考虑另外 1 个部分，这样很容易产生 bug。
2. useEffect 将相关逻辑集中到了一起，更容易维护，在第 1 个参数中接收副作用函数，可以在这个副作用函数里注册事件，然后这个副作用的返回值如果是一个函数，就会在组件卸载时执行，所以可以在返回的时候写一个函数移除事件回调。
3. 这样把相关逻辑都集中到 useEffect 的第 1 个参数中，使得维护起来更清晰了。
**用途3.拥抱函数式编程**
1. React团队发现 class 是学习 React 的一大屏障。因为:
  - 开发者必须理解 this 的工作方式
  - 开发者必须正确绑定事件处理器
  - class 的语法提案不够稳定
2. React团队发现使用 class 组件会使得一些优化措施无效，比如 class 不能很好的压缩，并且会使热重载出现不稳定的情况等。
所以，React 选择拥抱函数式编程。
而 16.8版本 之前函数组件支持的 React 特性较少，所以出现了 hook, 它使得开发者在非 class 的情况下可以使用更多的 React 特性。


# fhooks原理
1. hooks 本质上是一条单向链表，挂载在 fiber.memoizedState 上，函数组件 mount 时会把 这条链表 新建出来。
2. 源码里有一个 workInProgressHook 指针，每次函数组件重新渲染时，指针会复位到 fiber 的第 1 个 hook 上。
3. 函数组件执行，遇到 useState 等 hook 语句，开始执行 hook: 找到 workInProgressHook, 然后让 workInProgressHook 走到 next, 这样下一个 hook 语句执行的时候就能准确取到自己的 hook 对象。(前提是hook语句执行顺序不变)
4. 某一个 hook 语句获取到自己的 hook 对象以后，执行自己的逻辑。比如:
  1. useState 会计算 state, 返回 新的state 和 dispatchAction; 
  2. useRef 会在创建/返回一个只有 current 属性的对象，挂载在自己 hook 的 memoizedState 属性上。
  3. useMemo 会在 mount 时执行 create 存储缓存值; update 时检查 deps 是否变更，有变更重新执行 create 缓存，无变更返回缓存。
5. hook 有一个共同点，它们都会把 hook 的状态挂载在 hook.memoizedState 上。
**Hook结构**
```ts
type Hook = {
  // 当前 hook 的状态, 比如 useState 的 state， useRef 的 { current: value }。
  memoizedState: any,
  // 用于计算的 state
  baseState: any,
  baseQueue: Update,
  // queue.pending 是最后一个 update，queue.pending.next 是第一个 update。
  queue: any,
  // 下一个 hook
  next: Hook,
};
```
**为什么hook不能放到条件语句里**
1. hook 的执行顺序是遍历链表实现的，是固定的。如果一个函数组件有多个 useState, 而某些 useState 在条件语句中，这样重新渲染的话 useState 的执行顺序就不是固定的了，可能会使某些 useState 取到错误的 hook, 从而执行出错。
```jsx
function Demo() {
  const [x1,setX1] = useState(0);    // fiber.memoizedState
  if (condition) {
    const [x2,setX2] = useState(1);  // fiber.memoizedState.next  
  }
  // 错误❌: 这里可能会取到 fiber.memoizedState.next, 因为上一个 useState 可能没执行!
  const [x3,setX3] = useState(2);    // fiber.memoizedState.next.next 
}
```

# f自定义hook  f状态逻辑 
**讲概念**
1. 从组件中抽离出来的只关注如何维护 state 的逻辑。
**如何封装自定义hooks**  [f封装自定义hook]
1. 自定义 hook 是一个函数，其名称以`use`开头，函数内部可以调用其他的 hooks。
2. 自定义 hook 的 state 是完全独立的，hook 的每次调用都有一个完全独立的 state，因为在同一个组件中多次调用同一个自定义hook，它们的状态也互不影响。
**举例子**
1. 自定义hook 里用自己的 useState + useEffect 来管理状态，最后返回 state, 外部直接使用这个被管理的 state。
```jsx
// 抽离状态逻辑，形成自定义hook
function useFriendStatus(id) {
  const [isOnline, setIsOnline] = useState(null);
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsOnline(props.friend.id % 2 === 0 ? true : false);
    }, 1000)

    return () => {
      clearTimeout(timer);
    };
  });
  return isOnline;
}
// 这 2 个组件复用状态逻辑
function ComponentFriendStatus(props) {
  const isOnline = useFriendStatus(props.friend.id);
  return isOnline ? 'Online' : 'Offline';
}
function ComponentFriendListItem(props) {
  const isOnline = useFriendStatus(props.friend.id);
  return (
    <li style={{ color: isOnline ? 'green' : 'black' }}>
      {props.friend.name}
    </li>
  );
}
```

# fuseEffect
**讲概念**
1. React.useEffect 接收一个 create 函数，以及一个 deps 依赖数组。
2. 当 deps 中的任何一项改变时，React 会在组件更新完成后，异步执行 create 函数，并返回一个 destory 函数。
3. destory 函数和 create 函数一一对应，执行 destory 应该清除 create 造成的 effect。
4. React 会保证所有的 destory 都执行以后，再执行任意一个 create。
**说用途**
1. create 函数一般用来执行一些副作用，如设置定时器, 请求数据, 订阅数据 等，destory 函数用来作清除工作，如退订数据。
2. 通常情况下组件会多次渲染，那么在执行下一个 effect 之前，上一个 effect 的 destory 函数执行，清除上一次的副作用。
3. 对于某些特定值 x 应该单独给予一个 useEffect, 并将 x 作为 deps 的唯一元素，每次渲染时只关注 x 是否改变来决定是否产生副作用。
4. 如果想要执行只运行一次的 effect, 可以传递一个空的 deps 数组。
**执行时机**
1. create 函数会在 commit 阶段完成后异步执行(宏任务)，这时候浏览器已经完成了`布局`与`绘制`，可以获取到最新的 DOM 结点。 
2. 之所以设置成异步，是因为请求、订阅这种副作用操作，不应该阻塞浏览器的对屏幕的更新。
**产生背景**
1. 在 class 组件中，我们希望在组件`加载`和`更新`时执行同样的操作时，就要在 componentDidMout 和 componentDidUpdate 都调用，有些繁琐。
2. 如果使用 useEffect，就能使相关的逻辑在组件中能更加集中，便于维护。
**函数签名**
```ts
function mountEffect(create: () => (() => void) | void, deps?: Array<any>): void;
function updateEffect(create: () => (() => void) | void, deps?: Array<any>): void;
```
**举例子**
```jsx
function UseEffectDemo1() {
  // 组件重新渲染
  const [x, setX] = useState(0);
  // 定义副作用
  useEffect(() => {
    // 每次 x 改变就 create 一个 effect
    console.log('create执行');
    return () => {
      // 每次 x 改变，destory 上一次的 effect
      console.log('destory执行~');
    }
  }, [x]);
  return (
    <>
      <button onClick={() => setX(v => v + 1)}>更新x</button>
    </>
  )
}
```



**五、什么是高阶组件？有什么优缺点？**

# f高阶组件 fHOC  
**讲概念**
1. 高阶组件是一个函数，接收的参数为组件，返回值是一个新组件，组件将 props 转换为 UI，而高阶组件是将组件转换为另一个组件。
2. 高阶组件又称为 HOC, 是 React 中用于复用组件逻辑的一种高级技巧。 (Higher-Order Components)
3. HOC 自身不是 React API 的一部分，它是一种基于 React 的组合特性而形成的设计模式。
**优缺点**
HOC 的优点是:
1. 逻辑复用。
2. 不影响被包裹组件的内部逻辑。
HOC 的缺点是:
1. HOC 传递给被包裹组件的 props 容易和被包裹后的组件重名，进而被覆盖。
**说用途**
1. 抽离逻辑使代码复用。
2. 增强组件的功能。
**说用途1 抽离逻辑使代码复用**
比如说`添加日志功能`这个场景:
系统中各个业务模块往往都需要日志功能，那么就可以定义一个高阶组件，负责把传给它的组件都包装上一个日志功能，再返回包装完成的组件出来。
```jsx
function logProps(WrappedComponent) {
  return class extends React.Component {
    componentDidUpdate(prevProps) {
      console.log('Current props: ', this.props);
      console.log('Previous props: ', prevProps);
    }
    render() {
      return <WrappedComponent {...this.props} />;
    }
  }
}
```
**说用途2 增强组件的功能**
比如给某个组件增加一个统计自己渲染时间的功能:
方法是新建一个子类组件，监听父组件的 componentWillMount 和 componentDidMount，计算出时间间隔。
```jsx
class Home extends React.Component {
    render() {
        return <h1>Hello World</h1>;
    }
}
function withTiming(WrappedComponent) {
    return class extends WrappedComponent {
        constructor(props) {
            super(props);
            this.start = 0;
            this.end = 0;
        }
        UNSAFE_componentWillMount() {
            super.componentWillMount && super.componentWillMount();
            this.start = Date.now();
        }
        componentDidMount() {
            super.componentDidMount && super.componentDidMount();
            this.end = Date.now();
            console.log(`${WrappedComponent.name} 组件渲染时间为 ${this.end - this.start} ms`);
        }
        render() {
            return super.render();
        }
    };
}
export default withTiming(Home); 
```
**三方库**
1. HOC 在第三方库中很常见，比如 Redux 的 connect 函数、Relay 的 createFragmentContainer。
```jsx
// redux 的 connect 函数
const ConnectedComment = connect(commentSelector, commentActions)(CommentList);
// 刚刚发生了什么？！如果你把它分开，就会更容易看出发生了什么:
// connect 是一个函数，它的返回值为另外一个函数。
const enhance = connect(commentListSelector, commentListActions);
// 返回值为 HOC，它会返回已经连接 Redux store 的组件
const ConnectedComment = enhance(CommentList);
```




# f架构 React的架构
**讲概念**
1. 16 之前，React 只有 协调器 和 渲染器; 
2. 16 之后，React 有 调度器、协调器、渲染器。
各模块功能如下:
* 调度器: 调度任务的优先级，高优任务优先进入协调器。
* 协调器: 负责找出变化的组件。
* 渲染器: 负责将变化的组件渲染到页面上。


# fFiber
**讲概念**
Fiber 可以从 3 个方面来理解:
1. 作为架构来说，之前 React15 的`协调器`采用递归的方式执行，数据保存在递归调用栈中，所以被称为 Stack Reconciler。React16的`协调器`基于 Fiber 节点实现，被称为 Fiber Reconciler。
2. 作为静态的数据结构来说，每个 Fiber 结点对应一个 React组件, Fiber结点保存了该组件的类型（函数组件/类组件/原生组件...）、对应的DOM节点等信息。
3. 作为动态的工作单元来说，每个 Fiber 节点保存了本次更新中该组件改变的状态、要执行的工作（需要被删除/被插入页面中/被更新...）。
**React为什么需要fiber** [f为什么需要fiber]
1. 在 React15 以前，`协调器`采用`同步的`、`递归的`方式创建`虚拟DOM`, 递归过程一旦开始就不能中断。如果组件树的层级很深，这中同步的`协调`过程会占用浏览器的`渲染主线程`很多时间, 导致浏览器没有时间更新视图, 造成卡顿。
2. 为了解决这个问题，16版本以后，React 将`同步的无法中断的更新`重构为`异步的可中断的更新`。实际上就是将一次大的更新划分为多个小的工作单元，每个工作单元称为 Fiber, 执行完一个 Fiber 就检查一下是否超过时间，超过了就暂停工作，把一帧中的剩余时间交还给浏览器去渲染视图，然后在下一次宏任务中继续执行下一个 Fiber，实现了一次大更新的`中断`与`恢复`，这种不阻塞浏览器渲染的更新机制，符合 React `快速响应`的理念。
**Fiber解决了哪些问题**
1. 解决了 React15 同步更新造成的用户卡顿问题。
2. 支持高优先级任务插队低优先级任务。
3. 任务中断以后可以恢复，复用之前的中间状态。
**Fiber的数据结构**
```js
function FiberNode(tag, pendingProps, key, mode) {
  
  /* 1. 作为静态数据结构的属性 */
  // Fiber对应组件的类型 Function/Class/Host...
  this.tag = tag;
  // key属性, 用户提供, 主要用于 DOM DIFF。
  this.key = key;
  // 大部分情况同type，某些情况不同，比如FunctionComponent使用React.memo包裹
  this.elementType = null;
  // 对于 FunctionComponent，指函数本身，对于ClassComponent，指class，对于HostComponent，指DOM节点tagName
  this.type = null;
  // Fiber对应的真实DOM节点
  this.stateNode = null;

  /* 2. 用于连接其他Fiber节点形成Fiber树 */
  // 指向父级Fiber节点
  this.return = null;
  // 指向子Fiber节点
  this.child = null;
  // 指向右边第一个兄弟Fiber节点
  this.sibling = null;
  // 结点`在同级结点形成的数组中`的索引
  this.index = 0;

  this.ref = null;

  /* 3. 作为动态的工作单元的属性 */
  // 在一次更新中，代表element创建
  this.pendingProps = pendingProps;
  // 记录上一次更新完毕后的props
  this.memoizedProps = null;       
  // 类组件存放setState更新队列，函数组件存放
  this.updateQueue = null;         
  // 类组件保存state信息，函数组件保存hooks信息，dom元素为null
  this.memoizedState = null;       
  // context或是时间的依赖项
  this.dependencies = null;        

  // 描述fiber树的模式，比如 ConcurrentMode 模式
  this.mode = mode;                

  // effect标签，用于收集effectList
  this.effectTag = NoEffect;
  // effect标签，用于收集effectList
  this.nextEffect = null;

  // 第一个effect
  this.firstEffect = null;
  // 最后一个effect
  this.lastEffect = null;

  /* 调度优先级相关 */
  this.lanes = NoLanes;
  this.childLanes = NoLanes;

  /* 指向该fiber在另一次更新时对应的fiber */
  this.alternate = null;
}
```



# f虚拟DOM fvDom
**讲概念**
1. 虚拟DOM本质上就是一个对象，该对象描述了一个UI结点所对应的一些必要信息。
2. React 的虚拟DOM 可以理解为 ReactElement 和 Fiber，因为 DIFF 是比较这两者。
**为什么需要虚拟DOM**
1. 真实DOM的属性太多了，如果直接对真实DOM进diff，消耗性能非常大。
比如，可以在控制台写 document.createElement('div') 得到一个结点，打开这个结点，会看到上面的属性非常多，如果直接做 diff，要对比这么多属性，消耗的性能就非常大。而虚拟 dom 一般就是 { type: 'div', props: {} }, 只需要对比这几个属性，性能损耗大幅降低。
2. 对真实DOM进行curd很消耗性能，可以用虚拟DOM代替。

# fDOM DIFF  fDiff
**讲概念**
1. Diff算法的本质是对比`更新前虚拟dom树`和`更新后虚拟dom树`，找出两者之间的差异。
2. React 原理中，是在对比`当前结点的大儿子`和`新产生的React元素`, 从而产生`workInProgress的大儿子`。
3. 如果是
**说实现**
1. React 的 DIFF 算法分为 单结点DIFF 和 多结点DIFF。
2. 这里的`单结点`或`多结点`指的是新结点，新结点只有单个就是单结点diff，新结点有多个就是多结点diff。
**实现一、单结点**
单结点DIFF执行的是 reconcileSingleElement 函数。

因为只有一个新结点，所以通过 sibling 指针遍历老结点即可。遍历过程比较新老结点的 type 和 key, 有三种情况:
  1. 如果 type 和 key 都相同，说明这个`老结点`可以复用，标记`剩余的老结点`为`删除`，返回这个可复用的老结点。
  2. 如果 key 相同，但是 type 不同，`老结点`和`老结点的弟弟们`都标记为删除，跳出遍历，直接新建一个结点，标记`插入`。
  3. 如果 key 不同，删除这个老结点，继续遍历下一个老结点。如果遍历完了还是没有结点可复用，那就新建一个结点，标记`插入`。
  
  **单结点[例子]**
  比如: liA,liB,liC => liB
  DIFF过程就是:  
  liA => liB ❌ Deletion
  liB => liB ✅ 复用
  liC        ❌ Deletion


**实现二、多结点**
多结点DIFF执行的是 reconcileChildrenArray 函数, 主要分 3 步:
1. 建立老结点的查询表。
2. 遍历更新后的结点数组, 重点在于比较老结点索引。
3. 标记不可复用的老结点为删除。
**实现二、多结点 1.遍历前建立老结点的查询表**
1. 新建一个 Map, 将`老结点数组`中每个结点保存在以`结点key`为`key`，`结点本身`为`value`的 Map 中。
2. 这样就能在 O(1) 的时间复杂度内通过 key 找到老结点，这也是我们要写 key 的原因。
**实现二、多结点 2.遍历更新后的结点数组, 重点在于比较老结点索引**
遍历`新结点数组`, 用新结点的 key 去 Map 中查找:

  - 如果能找到一个值，说明这个新结点有一个`可复用的老结点`。
    这个`可复用的老结点`只有 2 种可能: 1 种是更新后它移动了，1种是更新后它没移动。
    React在Diff里做的就是判断`可复用的老结点`是否移动了:
    
      1. React 把最近的一个`可复用老结点在老数组中的索引`记录到 lastPlacedIndex 里。
         由于遍历`新结点数组`是从左往右的，如果后续的`可复用老结点`在更新前后没有移动，那么`可复用老结点的索引`应该始终大于`lastPlacedIndex`。
      
      2. 接下来判断`可复用老结点的索引`是否大于`lastPlacedIndex`:
          1. 如果大于或等于, 说明这个结点没有移动, 但是要更新 lastPlacedIndex = oldNode.index。
          2. 如果小于, 说明这个结点在更新后向右移动了，标记为`Placement`, Placement 对应 parent.appendChild, 会添加到最右边。

  - 如果找不到值，说明新结点是新增的，标记为`Placement`, 等待 commit 阶段新建对应的`DOM结点`插入页面。
**实现二、多结点 3.遍历后删除不可复用的老结点**
1. 查询表中的结点，一旦发现是`可复用的`，就会被删除。
2. 如果遍历新结点数组完成后，查询表还有结点，那就全部标记为`Deletion`，因为新结点里面没有它们，不能复用的。

  **多结点[例子]**
  老结点            A        B       C              D                   E                   F(不可复用,删除,Deletion)   
  新结点            A        C       E              B                   G                       D
                  复用     复用     复用         复用(老B右移)    不可复用(插入,Placement)    复用(老D右移,Placement)
  lastPlaceIndex   0        2       4              4                   4                       4
                  >=       >=      >=    B.oldIndex < lastPlacedIndex              D.oldIndex < lastPlacedIndex

**DIFF注意点**
1. 在多结点DIFF中，React只会将结点往后移动，如果我们要将节点从后往前移，实际上是把目标结点前面的结点全部往后移动了。这会影响性能，所以尽量不要把结点从后往前移动。
2. 如果用户没有写 key, 那么 React 认为 key 是 null, 在更新前后对比时，就会得出 key 相同的结论。
3. 检查出 key, type 都相同, 会复用 current 的属性，如 flags, childLanes, lanes, child, memoizedProps, memoizedState, updateQueue, sibling, index, ref。
4. 当 key, type 都不变，只有常规属性改变时，React 会复用 current.alternate 作为 workInProgress，把 pendingProps 放到 workInProgress.pendingProps 上，进行后续状态更新。


# fscheduler
**讲概念**
1. Scheduler 是一个在浏览器环境中实现`调度功能`的包。
2. 它提供了 2 个功能，一个是时间切片，一个是优先级调度。
3. 当前 Scheduler 用于 react 内部，但是 react 团队计划将它作为一个独立的包。
**说用途**
1. 时间切片
2. 优先级调度
**时间切片** [f时间切片]
1. 时间切片的目的是在浏览器一帧的空闲时间执行 React 的任务，不去占用`重排重绘`的时间，从而以提供快速响应的效果。
2. 主流浏览器的刷新频率是 60 Hz, 也就是一帧 16.6 ms。
3. 时间切片默认的任务执行时间是 5ms, 超过执行时间后, 会通过 shouldYield 退出 while 循环, 中断任务, 重新进入`调度`阶段。
4. 调度完成的下个任务被放到`宏任务`里等`下一帧`执行，那么在`这一帧`中浏览器就取回了控制权，可以在这一帧的剩余时间执行`渲染视图`等操作。
5. 所以，在执行一个耗时很长的 React任务时，会看到任务被切分在一片一片的 5ms 多一点的时间里执行，这就是`时间切片`。
**优先级调度** [f优先级调度]
1. 调度器提供了 2 个队列，一个存放`已就绪任务`，一个存放`未就绪任务`，分别叫 taskQueue 和 timerQueue, 都是用`小根堆`实现。
2. 当一个 task 到来时，先通过优先级计算出它的`过期时间`, 然后根据`过期时间`插入`小根堆`里, 再维持住`小根堆`。
3. 同时把 timerQueue 里已经就绪的任务加入 taskQueue。
4. 开始调度后，在 MessageChannel 里调度的是 flushWork, 代表把 task 刷到执行区准备执行, 它会弹出 taskQueue 堆顶的任务并执行，循环这个过程直到被 shouldYieldToHost 中断。
**高优任务如何打断低优任务** [f打断] [f高优打断低优]
1. 比如说，一个耗时很长的低优任务正在执行，源码里是一个 while 循环里不断执行 performUnitOfWork。 [低优render100个]
2. 但是每过 5ms, performUnitOfWork 就会被 shouldYield 中断, 退出 while 循环。
3. 退出以后，会执行`调度器`提供的调度 API 调度任务，调度时会根据`优先级`决定下个任务。
4. 如果没有`高优任务`，`调度器`会让这个`低优任务`在下次浏览器时宏任务执行时恢复执行，也就是[f时间切片], 宏任务用的是 MessageChannel。
5. 如果有`高优任务`，`调度器`会让低优任务暂停(cancelCallback), 然后优先调度高优任务(scheduleCallback)，于是这次的宏任务让高优任务先执行，这就是`低优任务被打断`的情况。 [被打断时render了80个]
6. 当高优任务完整地结束以后，`调度器`再次调度所有任务，发现之前的低优任务还存在，于是让它继续执行，这就是`恢复`的情况。 [恢复执行render20个]
7. 值得注意的是，高优任务执行前，需要清除低优任务产生的影响，调用 prepareFreshStack, 将 workInProgress 重置为 rootFiber，清空上一次更新产生的 fiber 树，重新开始协调。
**React的调度流程是什么样的**
1. 一次状态变化如 setState 会产生一个任务，这个任务会交给`调度器`。
2. `调度器`中有 2 个队列，一个 taskQueue (就绪任务), 一个 timerQueue (未就绪任务), 都是小根堆。
3. 根据`优先级`计算出过期时间，然后将 task 排序，取出最早过期的任务开始执行。

# fMessageChannel
**讲概念**
1. MessageChannel 接口允许我们创建一个新的消息通道，并通过它的两个 MessagePort 属性发送数据。
2. onmessage 指定的回调函数将在`宏任务`中执行。
**举例子**
```js
/* 建立一个消息通道 */
const channel = new MessageChannel();
/* 建立一个port发送消息 */
const port = channel.port2;
/* 接收消息 */
channel.port1.onmessage = function(){
  /* 宏任务中, 执行 React 任务 */
  scheduledHostCallback();
};
/* 向浏览器请求执行更新任务 */
port.postMessage();
```
**React为什么用MessageChannel**
1. MessageChannel 比 setTimeout 执行时机更加靠前，能让任务更早触发。
2. 递归执行 setTimeout 时，最后间隔时间会变成 4ms 左右，而不是最初的 1ms，一帧才 16ms，这就造成了浪费。
```js
// setTimeout 间隔时间变长的问题
let time = 0
let nowTime = +new Date()
let timer = null;
const poll = function(){
    timer = setTimeout(()=>{
        const lastTime = nowTime
        nowTime = +new Date()
        console.log( '递归setTimeout(fn,0)产生时间差：' , nowTime -lastTime )
        poll()
    },0)
    time++
    if(time === 20) clearTimeout(timer)
}
poll();
```

# fSuspense
**讲概念**
1. Suspense 是 React 的 IO 瓶颈的解决方案，它在子组件尚未具备渲染条件时显示加载中的状态指示，子组件准备就绪时再渲染子组件。
2. Suspense 通过 fallback 属性指定 Loading 状态展示的组件。
**说用途**
```jsx
// 该组件是动态加载的
const DynamicComponent = React.lazy(() => import('./DynamicComponent'));
function MyComponent() {
  return (
    // 显示 loading 组件直至 DynamicComponent 加载完成。
    <Suspense fallback={<h1>loading...</h1>}>
      <DynamicComponent />
    </Suspense>
  );
}
```
**说原理**
1. Suspense 组件进入协调阶段，执行 updateSuspenseComponent，返回一个`离屏Fiber结点`作为子结点。
2. 这个离屏 fiber 的 pendingProps 里有一个 childern 属性代表 Suspense 子组件的集合，还有一个 mode 属性代表子组件当前是否可见。
3. 如果可见就渲染真实的子组件，如果不可见就渲染 Suspense 的 fallback 属性里定义的组件。
4. SuspenseFiber.elementType = Symbol.for('react.offscreen');
**源码**
1. renderRootConcurrent 捕获到 Promise 对象，当成一个 Error 抛出。
2. handleError 捕获到这个 Error, 发现是一个 thenable 对象，于是找到最近的 Suspense 组件，去渲染 fallback 组件 -> 
3. attachPingListener 监听抛出的 Promise 对象，Promise.then 回调里执行 pingSuspendedRoot, 然后通过 ensureRootIsScheduled 更新 React 应用，渲染 Suspense 的子组件。
```js
function renderRootConcurrent() {
  // ...
  do {
    try {
      workLoopConcurrent();
      break;
    } catch (thrownValue) {
      handleError(root, thrownValue);
    }
  } while (true);
  // ...
}
```


# flane
**讲概念**
1. lane 是 React 内部的优先级模型，和 Scheduler 的优先级模型是分隔开的。
2. 源码位于 ~/react-reconciler/src/ReactFiberLane.js
**说用途**
1. lane 能够表示不同的优先级 [lane用途1]
2. lane 存在多个相同优先级的更新，能够表示`批`的概念  [lane用途2]
3. lane 是用二进制来表示的，二进制运算速度快，能方便地进行优先级的运算  [lane用途3]
**说用途1. lane 能够表示不同的优先级**
1. lane 模型借鉴了卡丁车比赛的原理，赛场上有多个赛道，React 用 31 个不同的二进制位，来表示不同的赛道，不同赛道就表示不同的优先级。
2. 比如 SyncLane 占领第 1 位，是比较高的优先级，越往下的位，优先级越低。
**说用途2. lane 存在多个相同优先级的更新，能够表示`批`的概念**
1. 除了 Lane 类型的变量，React 还定义了 Lanes 类型的变量，它们会占领多个连续的二进制位，表示这些优先级在同一个批次里。
**说用途3. lane 是用二进制来表示的，二进制运算速度快，能方便地进行优先级的运算**
1. lane 优先级的计算，其实就是二进制位的计算，比如`按位与`、`按位或`等。位运算是非常快速的。


# f开发环境调试React源码  fcreate-react-app调试技巧
在 ～YourProject/scripts/start.js 里，写上如下配置, 即可在运行时监听 react 库文件动态调试:
```js
const serverConfig = {
    host: HOST,
    port,
    // 便于开发环境调试源码!!!
    watchFiles: [
      'src/**/*',
      'node_modules/react/cjs/react.development.js',
      'node_modules/react-dom/cjs/react-dom.development.js',
      'node_modules/scheduler/cjs/scheduler.development.js',
    ],
  };
```


# f代码分割 fReact代码分割 fimport()
**讲概念**
1. 代码分割是由如 Webpack 等打包器支持的一项技术，能够在运行时动态加载包。
2. 通过`动态import`语法如 `import('lodash').then(({ default: _ }) => { _.join(..); })` 来使用。
**说用途**
1. 对你的应用进行代码分割能够帮助你“懒加载”当前用户所需要的内容，能够显著地提高你的应用性能。
2. 尽管并没有减少应用整体的代码体积，但你可以避免加载用户永远不需要的代码，并在初始加载的时候减少所需加载的代码量。
**举例子**
1. 当 Webpack 解析到`动态import`语法时，会自动进行代码分割。如果你使用 Create React App，该功能已开箱即用，你可以立刻使用该特性。
2. 当使用 Babel 时，你要确保 Babel 能够解析`动态import`语法而不是将其进行转换。对于这一要求你需要 babel-plugin-syntax-dynamic-import 插件。
```jsx
import("./math").then(math => {
  console.log(math.add(16, 26));
});
```

# flazy f懒加载
**讲概念**
React.lazy 函数能让你像渲染常规组件一样处理动态引入的组件。
**说用途**
1. 懒加载组件
**举例子**
1. 懒加载组件
2. 基于路由的代码分割
**举例子1. 懒加载组件**
1. React.lazy 接受一个函数，这个函数需要使用动态import语法。
2. 动态import 的函数必须返回一个 Promise 对象，该 Promise 需要 resolve 一个 defalut export 的 React 组件。
3. 在 Suspense 组件中渲染 lazy 组件，如此使得我们可以使用在等待加载 lazy 组件时展示 loading 状态。
```jsx
import React, { Suspense } from 'react';
const OtherComponent = React.lazy(() => import('./OtherComponent'));
function LazyDemo() {
  const [showLazy, setShowLazy] = React.useState(false);
  const load = () => { setShowLazy(true) }
  return (
    <div>
      <button onClick={load}>点击按钮加载组件</button>
      {
        showLazy ? (
          <Suspense fallback={<h1>正在加载...</h1>}>
            <OtherComponent />
          </Suspense>
        ) : <h1>未加载组件</h1>
      }
    </div>
  );
}
```
**举例子2. 基于路由的代码分割**
```jsx
import React, { Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
const Home = React.lazy(() => import('./routes/Home'));
const About = React.lazy(() => import('./routes/About'));
const ReactRouterDemo = () => (
  <Router>
    <Suspense fallback={<div>loading...</div>}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
      </Routes>
    </Suspense>
  </Router>
)
```


# fContext
**讲概念**
1. Context 是一个共享`全局数据`的解决方案，例如共享全局的用户、主题、语言等。
**背景**
1. 在一个典型的 React 应用中，数据是通过 props 属性由父到子进行传递的，但此种用法对于某些类型的属性而言是极其繁琐的，比如当前用户、应用语言、UI主题，这种属性是应用程序中许多组件都需要的。
**说用途**
1. Context 提供了一种在组件之间共享此类值的方式，而不必显式地通过组件树的逐层传递 props。
**优缺点**
**优缺点1. 优点**
1. 将全局数据直接送达目标组件，避免了 props 在组件树的层层传递。
**优缺点2. 缺点**
1. Context 会使得组件的复用性变差，因为它依赖于全局 context 对象。
**举例子**
1. React.createContext 初始化 Context 对象。
2. Context.Provider 提供一棵包含 context 全局对象的树。
3. useContext/静态属性contextType 接收 context 全局对象。
```jsx
const ThemeContext = React.createContext('light');
class App extends React.Component {
  render() {
    return (
      <ThemeContext.Provider value="dark">
        <Middle />
      </ThemeContext.Provider>
    );
  }
}
// 中间的组件再也不必指明往下传递 theme 了。
function Middle() {
  return <ThemedButton />;
}
// 在需要使用 Context 的组件中，指定 contextType 读取当前的 theme context。
// React 会往上找到最近的 theme Provider，然后使用它的值。
class ThemedButton extends React.Component {
  static contextType = ThemeContext;   // 跨组件接收数据
  render() {
    return <Button theme={this.context} />;  // 找到 ThemeContext.Provider value="dark"
  }
}
```

# fcreateContext
**讲概念**
1. React.createContext 接收一个 defaultValue，返回一个 Context 对象。
2. 当 React 渲染一个订阅了这个 Context 对象的组件，这个组件会从组件树中离自身最近的那个匹配的 Provider 中读取到当前的 context 值。
3. 只有当组件所处的树中没有匹配到 Provider 时，其 defaultValue 参数才会生效。此默认值有助于在不使用 Provider 包装组件的情况下对组件进行测试。
```jsx
const ThemeContext = React.createContext('light');
```

# fProvider
**讲概念**
1. 每个 Context 对象都会返回一个 Provider React 组件，它允许消费组件订阅 context 的变化。
2. Provider 接收一个 value 属性，传递给消费组件。一个 Provider 可以和多个消费组件有对应关系。
3. 多个 Provider 也可以嵌套使用，里层的会覆盖外层的数据。
4. 当 Provider 的 value 值发生变化时，它内部的所有消费组件都会重新渲染。比如 使用了contextType的类组件 和 使用了useContext的函数组件。
5. 通过新旧值检测来确定变化，使用了`Object.is`算法。
```jsx
<ThemeContext.Provider value={/* 全局数据 */}>
  {/* 全局context起作用 */}
</ThemeContext.Provider>
```

# fConsumer
**讲概念**
1. Context.Consuer 是一个 React 组件，它可以订阅 context 的变更。
**说用法**
1. 它需要一个函数作为子元素。这个函数接收当前的 context 值，并返回一个 React 节点。
2. 传递给函数的 value 值等价于组件树上方离这个 context 最近的 Provider 提供的 value 值。
3. 如果没有对应的 Provider，value 参数等同于传递给 createContext() 的 defaultValue。
```jsx
<ThemeContext.Provider value={theme}>
  <ThemeContext.Consumer>
    {theme => /* 基于 `全局主题` 进行渲染*/}
  </ThemeContext.Consumer>
</ThemeContext.Provider>
```

# fcontextType fClass.contextType
**讲概念**
1. 类组件上的静态属性 contextType 可以赋值为由 React.createContext() 创建的 Context 对象。
2. 此属性可以让你使用 this.context 来获取最近 Context 上的值。你可以在任何生命周期中访问到它，包括 render 函数中。
```jsx
class MyClass extends React.Component {
  static contextType = MyContext;
  render() {
    const value = this.context;  // MyContext.Provider 的 value 值
  }
}
```

# fuseContext
**讲概念**
1. React.useContext 接收一个 context 对象，返回该 context 对象的当前值。
2. context 对象一般是 React.createContext(默认全局对象) 的返回值。
3. 当前的 context 值由上层组件中距离当前组件最近的`Context.Provider`的`value`属性决定。
4. 更新`Context.Provider`的`value`会触发一次Fiber树更新, 更新会遍历整棵树, 当遍历到 useContext 组件时，React会让该组件重新渲染。
5. 重新渲染使 useContext 返回最新的`Context.Provider`的全局数据`value`值。
6. 即使祖先使用 React.memo 或 shouldComponentUpdate，也会在组件本身使用 useContext 时重新渲染。
**举例子1. 切换主题**
```jsx
const themes = { light: '#fff', dark: '#000' };
const ThemeContext = React.createContext(themes.light);
function App() {
  const [theme, setTheme] = useState(themes.dark);
  const onChangeTheme = () => setTheme(theme === themes.dark ? themes.light : themes.dark);
  return (
    <ThemeContext.Provider value={theme}>
      <Middle />
      <button onClick={onChangeTheme}>切换主题</button>
    </ThemeContext.Provider>
  );
}
function Middle(props) {
  return <ThemedButton />;
}
function ThemedButton() {
  const theme = useContext(ThemeContext);
  return <h1 style={{ color: theme }}>网站标题</h1>;
}
```


# f更新 f状态更新
**说原理**
React应用`状态更新`的流程:
1. 触发状态更新 (如 setState, useState的dispatchAction, forceUpdate, ReactDOM.render等)
2. 创建 Update 对象 [fUpdate,fUpdateQueue]
3. 从 触发更新的fiber 开始，往上回到 rootFiber (`markUpdateLaneFromFiberToRoot`)
4. 从 rootFiber 开始调度更新（`ensureRootIsScheduled`）
5. render阶段（`performSyncWorkOnRoot` 或 `performConcurrentWorkOnRoot`）
6. commit阶段（`commitRoot`）

# fUpdateQueue
**讲概念**
1. fiber.updateQueue 是一条记录当前组件发生 update 的链表。
**UpdateQueu的结构**
```js
const updateQueue = {
  // 本次更新前该Fiber节点的state，Update基于该state计算更新后的state。
  baseState: fiber.memoizedState,
  // 本次更新前该 Fiber节点已保存的 Update。
  // 以链表形式存在，链表头为 firstBaseUpdate，链表尾为 lastBaseUpdate。
  // 之所以在更新产生前该 Fiber节点内就存在 Update，是由于某些 Update优先级较低所以在上次 render阶段由 Update计算 state 时被跳过。
  firstBaseUpdate: null,
  lastBaseUpdate: null,
  shared: {
    // 触发更新时，产生的 Update会保存在s hared.pending中形成单向环状链表。
    // 当由 Update 计算 state 时这个环会被剪开并连接在 lastBaseUpdate 后面。
    pending: null,
  },
  // 数组。保存 update.callback !== null 的Update。
  effects: null,
};
```
**举例子**
1. 一个 Fiber节点 存在多个 Update 对象的例子。
```jsx
class Demo extends React.Component {
  onClick() {
    this.setState({ a: 1 });
    this.setState({ b: 2 });
  }
}
```

# fUpdate
**讲概念**
1. `状态更新`会创建一个保存更新状态相关内容的对象，我们叫他 Update。
2. 一个 update 是 fiber.updateQueue 这条链表上的一个结点，通过 next 连接。
3. 在 render 阶段的 beginWork 中会根据 Update 计算新的 state。
**Update的结构**
```js
const update = {
  // 任务时间，通过performance.now()获取的毫秒数。由于该字段在未来会重构，当前我们不需要理解他。
  eventTime,
  // 优先级相关字段, 不同 Update优先级可能是不同的。
  lane,
  // Suspense相关。
  suspenseConfig,
  // 更新的类型，包括 UpdateState | ReplaceState | ForceUpdate | CaptureUpdate。
  tag: UpdateState,
  // 更新挂载的数据，不同类型组件挂载的数据不同。
  // 对于ClassComponent，payload为this.setState的第一个传参。对于HostRoot，payload为ReactDOM.render的第一个传参。
  payload: null,
  // 更新的回调函数。比如 setState 的第 2 个参数。
  callback: null,
  // 与其他Update连接形成链表。
  next: null,
};
```

# fref
**讲概念**
1. ref 属性用于获取原生React元素的 DOM 结点引用。
**说用途**
1. 通过 React.createRef, React.useRef 来获取 ref 引用。
2. 通过 React.forwardRef, 用传递给父组件的`ref对象`获取子孙组件的`DOM结点引用`。


# fuseRef
**讲概念**
1. useRef 返回一个 ref 对象 { current: initialValue },  其中 initialValue 是 useRef 接收的第 1 个参数。
2. 这个 ref 对象在组件的整个生命周期内持续存在，这代表重新渲染组件，ref.current 的数据不会丢失。
**原理**
1. useRef 返回的其实是 hook.memoizedState, 它是一个缓存值，只要组件没被卸载，怎么更新都不会丢失的。 (hook = fiber.memoizedState)
**函数签名**
```ts
function mountRef<T>(initialValue: T): { current: T }
function updateRef<T>(initialValue: T): { current: T }
```
**举例子1 获取DOM引用**
1. 利用 useRef 获取原生React元素的DOM结点引用。
```jsx
function Demo() {
  const inputEl = useRef(null);
  const onButtonClick = () => {
    inputEl.current.focus();  // `current` 指向已挂载到 DOM 上的文本输入元素
  };
  return (
    <>
      <input ref={inputEl} type="text" />
      <button onClick={onButtonClick}>点击使文本框获取焦点</button>
    </>
  );
}
```
**举例子2 无视渲染特性**
1. 利用 useRef 得到的对象缓存在 fiber 上的特性，统计组件的渲染次数。
```jsx
function Demo() {
  // 让组件重新渲染
  const [x, setX] = useState(0);
  // 记录 UseRefDemo1 组件的渲染次数, 初始化为0
  // 得到的就是一个 { current: 0 } 对象。
  const renderCountRef = useRef(0);
  // 每次更新计数+1
  renderCountRef.current++;
  // 渲染次数是不是奇数次
  const isOdd = renderCountRef.current % 2 !== 0;
  return (
    <>
      <h1>{isOdd ? '奇数次更新' : '偶数次更新'}</h1>
      <p>x: {x}</p>
      <button onClick={() => setX(v => v + 1)}>更新</button>
    </>
  )
}
```

# fcreateRef
**讲概念**
1. React.createRef 创建一个能够通过 ref 属性附加到 React 元素的 ref 对象，通过 current 取得实例，比如 DOM 结点的引用。
```jsx
class MyComponent extends React.Component {
  constructor(props) {
    super(props);
    this.inputRef = React.createRef();
  }
  render() {
    return <input type="text" ref={this.inputRef} />;
  }
  componentDidMount() {
    this.inputRef.current.focus();
  }
}
```

# fforwardRef
**讲概念**
React.forwardRef 是一个 React顶层API, 它能用传递给父组件的`ref对象`获取子孙组件的`DOM结点引用`。
**背景**
直接通过 props 传递 ref 是不行的，React 对 ref 进行了特殊处理，它不在 props 的属性中。
**说用法**
1. React.forwardRef 会创建一个React组件，这个组件有一个 ref 属性, 这个 ref 属性的值将传递给 forwardRef 的回调函数。
**举例子**
```jsx
const FancyButton = React.forwardRef((props, ref) => (
  <button ref={ref}>{props.children}</button>
));
const reference = React.createRef();
<FancyButton ref={reference}>Click me!</FancyButton>;
```

# fRefs转发
**讲概念**
1. Refs 转发允许某些组件接收 ref，并将其向下传递给子组件。
**说用途**
1. 转发 refs 到 DOM 组件。
2. 在高阶组件中转发 refs。
**说用途1. 转发refs到DOM组件**
1. 通过 React.createRef 创建一个 ref 对象。
2. 通过 ref 属性传递给 React.forwardRef 返回的组件，React 内部将 ref 传递给 forwardRef 接收的函数的第 2 个参数。
3. 在 forwardRef 接收的函数中，将 ref 传递给原生 button 元素，DOM渲染完成后, ref.current 拿到 button 的 DOM 引用。
4. 这样在父组件那一层的 ref 对象，就拿到了 FancyButton 内部的 button 的 DOM 引用。
```jsx
const refObject = React.createRef();
// refObject 属性会获取到 FancyButton 中原生 button 的 DOM 引用
<FancyButton ref={refObject}>Click me!</FancyButton>;
// 
const FancyButton = React.forwardRef((props, ref) => (
  <button ref={ref}>{props.children}</button>
));
```
**说用途2. 在高阶组件中转发refs**
1. ref 不是 prop 属性。就像 key 一样，其被 React 进行了特殊处理。如果你对 HOC 添加 ref，该 ref 将引用最外层的容器组件，而不是被包裹的组件。
2. 我们可以使用 React.forwardRef API 明确地将 refs 转发到内部的 FancyButton 组件。
3. React.forwardRef 接受一个渲染函数，其接收 props 和 ref 参数并返回一个 React 节点。例如:
```jsx
function logProps(Component) {
  class LogProps extends React.Component {
    componentDidUpdate(prevProps) {
      console.log('old props:', prevProps);
      console.log('new props:', this.props);
    }
    render() {
      const {forwardedRef, ...rest} = this.props;
      // 将自定义的 prop 属性 “forwardedRef” 定义为 ref
      return <Component ref={forwardedRef} {...rest} />;
    }
  }
  // 注意 React.forwardRef 回调的第二个参数 “ref”。
  // 我们可以将其作为常规 prop 属性传递给 LogProps，例如 “forwardedRef”
  // 然后它就可以被挂载到被 LogProps 包裹的子组件上。
  return React.forwardRef((props, ref) => {
    return <LogProps {...props} forwardedRef={ref} />;
  });
}
```


# fProfiler
**讲概念**
1. React.Profiler 是一个 React 组件，用于测量渲染一个 React 应用多久渲染一次以及渲染一次的“代价”。 
2. 它的目的是识别出应用中渲染较慢的部分，从而使用 React 性能优化 API 来优化应用。
**说用法**
1. Profiler 接收 2 个参数，一个是子树的 id，一个是当组件树中的组件“提交”更新的时候被React调用的回调函数 onRender(function)。
2. 在 commit 阶段的 layout 阶段触发。
3. Profiler 需要一个 onRender 函数作为参数。 React 会在 profile 包含的组件树中任何组件 “提交” 一个更新的时候调用这个函数。 它的参数描述了渲染了什么和花费了多久。主要的指标是 actualDuration, 它代表本次更新 committed 花费的渲染时间，使用 React 性能优化 API 之后，对比更新前后的 actualDuration 能得到提升的效率。
**举例子 fReact.Profiler**
```jsx
function App() {
  const onRenderCallback = (
    id, // 发生提交的 Profiler 树的 “id”
    phase, // "mount" 或 "update" 
    actualDuration, // 本次更新 committed 花费的渲染时间
    baseDuration, // 估计不使用 memoization 的情况下渲染整颗子树需要的时间
    startTime, // 本次更新中 React 开始渲染的时间
    commitTime, // 本次更新中 React committed 的时间
    interactions // 属于本次更新的 interactions 的集合
  ) => {
    // 合计或记录渲染时间。。。
  }
  return (
    <div>
      <React.Profiler id="Middle" onRender={onRenderCallback}>
        <Middle />
      </React.Profiler>
    </div>
  );
}
```


# fPortals
**讲概念**
Portal 是 React 官方提供的一种`将子节点渲染到父组件以外DOM节点`的方案。通过 ReactDOM.createPortal 来使用。
**说用途**
1. Portal 适用于需要子组件在视觉上`跳出`其容器的场景，例如，对话框、悬浮卡以及提示框。
**举例子**
```jsx
class Modal extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return ReactDOM.createPortal(this.props.children, document.getElementById('modal-root'));
  }
}
function App() {
  return (
    <Modal>
      {/* 对话框中的内容.. */}
    </Modal>
  )
}
```
**注意点**
1. Portal 组件的事件冒泡仍会到达 React 父组件。
2. 尽管组件存在于外部 DOM 下，但它仍处于 React 树中，所以其内部触发的事件仍会冒泡到 React 祖先组件上。


## fcreatePortal
**讲概念**
ReactDOM.createPortal(child, container) 接收 2 个参数, 返回一个 React组件。
1. 第 1 个参数 child 是任何可渲染的 React 子元素，例如一个元素，字符串或 fragment。
2. 第 2 个参数 container 是一个 DOM 元素，child 对于的真实DOM结点，将被挂载到 container 下。


# fJSX
**讲概念**
1. JSX 是 React.createElement(component, props, ...children) 函数的语法糖。
2. JSX 是 JS 语法的扩展，它可以让我们在编写 React组件的时候，类似于编写 HTML 一样编写视图代码。
**举例子1 编译单个子结点**
```jsx
<MyButton color="blue" shadowSize={2}>Click Me</MyButton>
// 编译为
React.createElement(MyButton, {color: 'blue', shadowSize: 2}, 'Click Me');
```
**举例子2 编译子结点数组**
```jsx
<MyUl title="demo">
  <MyLi>1</MyLi>
  <MyLi>2</MyLi>
  <MyLi>3</MyLi>
</MyUl>
// 编译为
React.createElement(MyUl, { title: "demo"}, 
  React.createElement(MyLi, null, "1"), 
  React.createElement(MyLi, null, "2"), 
  React.createElement(MyLi, null, "3")
);
```
**注意点**
1. 必须引入React库
2. 用户组件用大写字母开头，原生组件用小写字母开头
3. 返回一个数组是可行的
React 组件也能够返回存储在数组中的一组元素。
4. {} 中的子元素
我们可以将包裹在 {} 中的 JS 表达式、函数、布尔值、Null、Undefined 作为子元素。
**注意点1. 必须引入React库**
1. 我们在使用 JSX 时，必须引入 React，虽然从写法上看不出来用了 React 这个库，但是编译后用到了 React.createElement，所以 React 库也必须包含在 JSX 代码作用域内。
2. 如果你不使用 JavaScript 打包工具而是直接通过 script 标签加载 React，则必须将 React 挂载到全局变量中。
**注意点2. 用户组件用大写字母开头，原生组件用小写字母开头**
1. 小写字母开头的元素代表一个 HTML 原生结点，比如 div 或 span，他们会生成相应的字符串'div'或者'span'，传递给 React.createElement 作为参数。
2. 大写字母开头的元素则对应着在 JavaScript 引入或自定义的组件，如 Foo 会编译为 React.createElement(Foo)。
**注意点3. 返回一个数组是可行的**
```jsx
function List() {
  return [
    // 不要忘记设置 key :)
    <li key="A">First item</li>,
    <li key="B">Second item</li>,
    <li key="C">Third item</li>,
  ];
}
```
**注意点4. {} 中的子元素**
```jsx
// JavaScript 表达式可以被包裹在 {} 中作为子元素。例如，以下表达式是等价的：
<MyComponent>foo</MyComponent>
<MyComponent>{'foo'}</MyComponent>
// false, null, undefined, and true 是合法的子元素。但它们并不会被渲染。以下的 JSX 表达式渲染结果相同：
<div>{true}</div>
<div />
<div></div>
<div>{false}</div>
<div>{null}</div>
<div>{undefined}</div>
// 值得注意的是有一些 “false” 值，如数字 0，仍然会被 React 渲染。例如，当数组为空时以下代码会渲染为数字 0
<div>
  {props.messages.length && <MessageList messages={props.messages} />}
</div>
// 要解决这个问题，确保 && 之前的表达式总是布尔值
<div>
  {props.messages.length > 0 && <MessageList messages={props.messages} />}
</div>
// 反之，如果你想渲染 false、true、null、undefined 等值，你需要先将它们转换为字符串
<div>
  My JavaScript variable is {String(myVariable)}.
</div>
```


# f错误边界 fErrorBoundary
**讲概念**
1. 错误边界是一种 React 组件，这种组件可以捕获并打印发生在其子组件树任何位置的 JavaScript 错误，并且，它会渲染出备用 UI，而不是渲染那些崩溃了的子组件树。
2. 错误边界在渲染期间、生命周期方法和整个组件树的构造函数中捕获错误。
**说用途**
1. 部分 UI 的 JavaScript 错误不应该导致整个应用崩溃，为了解决这个问题，React16 引入了这个新的概念——错误边界。
**优缺点**
**优缺点1. 优点**
1. 提供了对错误处理的优雅的控制方案。
**优缺点2. 缺点**
1. 只能在类组件上使用 (包裹的子组件没有限制)
2. 注意错误边界仅可以捕获其子组件的错误，它无法捕获其自身的错误。
3. 只能捕获`渲染期间、生命周期方法、整个组件树的构造函数`发生的错误，无法捕获以下场景中产生的错误:
  1. 事件处理
  2. 异步代码（例如 setTimeout 或 requestAnimationFrame 回调函数）
  3. 服务端渲染
  4. 它自身抛出来的错误，并非它的子组件
对于这些场景，使用常规的 try/catch 语法来捕获错误。
**如何使用**
1. 在类组件中，使用 `static getDerivedStateFromError`或`componentDidCatch` 这两个生命周期方法。
2. 当抛出错误后，使用`static getDerivedStateFromError`设置降级UI的数据，使用`componentDidCatch`打印错误信息。
```jsx
// 定义
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true };  // 更新 state 使下一次渲染能够显示降级后的 UI
  }
  componentDidCatch(error, errorInfo) {
    logErrorToMyService(error, errorInfo);  // 将错误日志上报给服务器
  }
  render() {
    if (this.state.hasError) {
      return <h1>Something went wrong.</h1>;  // 渲染降级后的 UI
    }
    return this.props.children; 
  }
}
// 使用
<ErrorBoundary>
  <App />
</ErrorBoundary>
```


# Transition
**讲概念**
Transition 是 React18 提出的一个改善用户交互的解决方案。它可以将更新标记为一个 transitions，transitons 可以被中断执行。也就是说，它将更新分为`紧急更新`和`过渡更新`。
1. 紧急更新如输入文本、选中下拉列表一项产生的更新，需要快速给用户反馈，所以会优先渲染。
2. 过渡更新是指从一个视图过渡到另一视图，中间产生的一系列更新，用户不关心这些更新产生的中间状态，只关心最终结果，所以它们`可被中断`且只渲染最终结果。
**举例子** [fstartTransition]
1. 比如有一个搜索框，快速输入关键词会实时展示大量搜索结果。每次用户输入都会产生 2 个更新，一个是更新输入框的值(紧急更新)，另一个是更新搜索结果。
2. 由于`更新搜索结果`要花费大量时间，且用户更关心输入完成后的结果而不是输入过程中的结果，所以更新搜索结果可以定义为`过渡更新`，它在中间过程会被快速发生的一系列`紧急更新`打断，直到所有的`紧急更新`完毕，`过渡更新`渲染最终的视图。
**说用途**
1. 在大数据量的情况下，一次更新可能引起视图的巨大变化，浏览器需要花费大量时间处理视图而无法响应用户交互，造成卡顿。
2. 过渡更新可以把渲染权交给紧急更新，使得交互变得流畅。
**优缺点**
**优缺点1. 优点**
在以往的方案中，我们常常使用 setTimeout，即使防抖和节流也是如此。下面对比 transition 和 setTimeout 的不同，以展现其优点:
1. 执行时间更早
2. 不会阻塞用户交互
3. 更精确地跟踪loading状态
**优缺点1. 优点1. 执行时间更早**
React.startTransition 包裹状态更新的函数是同步执行的，如果放在 setTimeout 中就是异步执行，所以执行时间更早。
**优缺点1. 优点2. 不会阻塞用户交互**
1. setTimeout 本质上是将`大数据量的那个更新`延迟了，让本次`紧急更新`先渲染，但是延迟的`大数据量的那个更新`终将到来，那时候也会占用浏览器大量时间进行渲染，而无法响应用户交互，所以还是阻塞了用户交互。防抖/节流也是一样的，只是把大量的更新降低为少量的更新，当一次更新非常巨大的时候，无法中断它，也会造成卡顿。
2. 而 transition 的`过渡更新`是可以中断的，`用户交互`到来时优先渲染用户交互，所以不会阻塞。
**优缺点1. 优点3. 更精确地跟踪loading状态**
transition 方案提供了 useTransiton 这个 hook, 它返回一个数组，数组第一项 isPending 代表过渡更新是否正在过渡中, 如果是就是true, 不是就是false, 这可以精确追踪过渡更新的状态，这是 setTimeout 没有实现的。

# fstartTransition
**讲概念**
1. React.startTransition 接收一个函数 fallback，把 fallback 里面的更新标记为 transitions，它的返回值类型是 void。
2. 这个方法是为了在 React.useTransition 不可用时使用。
**说用途**
1. 过渡期的更新会被更紧急的更新取代，如点击操作。
2. 过渡期的更新不会显示重新挂起内容的 fallback，允许用户在渲染更新时继续进行交互。
3. React.startTransition 不提供 isPending 的标志。要跟踪过渡的待定状态，请使用 React.useTransition。
```jsx
// 紧急的更新: 展示用户输入了什么
setInputValue(e.target.value);
// 将包裹到的更新都标记为`过渡`
React.startTransition(() => {
  // 不紧急的更新: 展示搜索结果
  setSearchQuery(e.target.value);
})
```


# fuseTransition
**讲概念**
React.useTransition 接收 0 个参数，返回一个数组:
1. 数组第一项是一个状态值isPending，表示过渡任务的等待状态。
2. 数组第二项是一个函数startTransition，startTransition接收一个函数，将里面的状态更新标记`过渡任务`, `过渡任务`意味着不紧急。
```jsx
function App() {
  const [isPending, startTransition] = React.useTransition();
  const [count, setCount] = React.useState(0);
  function handleClick() {
    // 将`设置count为count+1`标记为`过渡任务`
    startTransition(() => {
      setCount(c => c + 1);
    })
  }
  return (
    <div>
      {isPending && <Spinner />}
      <button onClick={handleClick}>{count}</button>
    </div>
  );
}
```
**注意**
* startTransition 允许你通过标记更新将提供的回调函数作为一个过渡任务
* isPending 指示过渡任务何时活跃以显示一个等待状态
* 过渡任务中触发的更新会让更紧急地更新先进行，比如点击。
* 过渡任务中的更新将不会展示由于再次挂起而导致降级的内容。这个机制允许用户在 React 渲染更新的时候继续与当前内容进行交互。
**参考**
React工作组的讨论: [https://github.com/reactwg/react-18/discussions/41]


# fAPI fReact顶层API
**组件**
* React.Component [fComponent]
* React.PureComponent [fPureComponent]
* React.memo [fmemo]
**创建React元素**
* React.createElement [fcreateElement]
* React.createFactory  [已废弃]
**转换元素**
* React.cloneElement [fcloneElement]
* React.isValidElement [fisValidElement]
* React.Children [fChildren]
**Fragments**
* React.Fragment [fFragment]
**Refs**
* React.createRef [fcreateRef]
* React.forwardRef [fforwardRef]
**Suspenses**
* React.lazy [flazy]
* React.Suspense [fSuspense]
**Transitions**
* React.startTransition [fstartTransition]
* React.useTransition [fuseTransition]
**Context**
* React.createContext [fcreateContext]
**Hooks**
**基础Hook**
* React.useState [fuseState]
* React.useEffect [fuseEffect]
* React.useContext [fuseContext]
**额外的Hook**
* React.useReducer [fuseReducer]
* React.useCallback [fuseCallback]
* React.useMemo [fuseMemo]
* React.useRef [fuseRef]
* React.useImperativeHandle [fuseImperativeHandle]
* React.useLayoutEffect [fuseLayoutEffect]
* React.useDebugValue [fuseDebugValue]
* React.useDeferredValue [fuseDeferredValue]
* React.useTransition [fuseTransition]
* React.useId [fuseId]
**Library Hooks**
* React.useInsertionEffect [fuseInsertionEffect]
* React.useSyncExternalStore [fuseSyncExternalStore]


# fuseState
**讲概念**
1. React.useState 接收一个初始值或一个初始化函数, 返回一个数组，数组第一项是状态值state，第二项是改变状态的函数setState。
**函数签名**
```jsx
const [state, setState] = React.useState(initialState);
```
**说用途**
1. 初始化的时候，返回的 state 和 initialState 相同。
2. setState 接收一个值或者一个函数，调用后，将一次更新任务加入队列。
3. 如果使用 setState 更新的 state 和之前的 state 相同，React 不会重新渲染组件。
**举例子**
```jsx
function Counter({initialCount}) {
  const [count, setCount] = useState(initialCount);
  return (
    <>
      数量: {count}
      <button onClick={() => setCount(initialCount)}>重置</button>
      <button onClick={() => setCount(prevCount => prevCount - 1)}>减少</button>
      <button onClick={() => setCount(prevCount => prevCount + 1)}>增加</button>
    </>
  );
}
```


# fuseEffect
**讲概念**
1. React.useEffect 接收一个create函数，以及一个 deps 依赖数组。
2. 当依赖数组中的任何一项改变时，React会在组件更新完成后，异步执行 create 函数，并返回一个 destory 函数, destory 函数会在组件卸载前执行。
**说用途**
1. create 函数会在 commit 阶段完成后异步执行(宏任务)，这时候浏览器已经完成了`布局`与`绘制`，可以获取到最新的 DOM 结点。之所以设置成异步，是因为请求、订阅这种副作用操作，不应该阻塞浏览器的对屏幕的更新。
2. create 函数一般用来执行一些副作用，如设置定时器, 请求数据, 订阅数据 等，destory 函数用来作清除工作，如退订数据。
3. 通常情况下组件会多次渲染，那么在执行下一个 effect 之前，上一个 effect 的 destory 会执行，用来清除上一次的 effect。
4. 如果想要执行只运行一次的 effect, 可以传递一个空数组。
**函数签名**
```jsx
function useEffect(create, deps): void;
```
**举例子**
```jsx
useEffect(() => {
    const subscription = props.source.subscribe();
    return () => {
      subscription.unsubscribe();
    };
  }, [dep1, dep2, props.source],
);
```

# fuseLayoutEffect
**讲概念**
1. React.useLayoutEffect 会在所有的 DOM 变更之后同步调用 effect, 执行时机是 commit 阶段的 layout 步骤。
**说用途**
1. 可以使用它来读取 DOM 布局并同步触发重渲染。
2. 在浏览器执行绘制之前，useLayoutEffect 内部的更新计划将被同步刷新。
3. 官网建议尽可能使用 useEffect 以避免阻塞视觉更新。
**函数签名**
```ts
function useLayoutEffect(create, deps): void;
function mountLayoutEffect(create: () => (() => void) | void, deps?: Array<any>): void;
function updateLayoutEffect(create: () => (() => void) | void, deps?: Array<any>): void;
```

# fuseEffect vs fuseLayoutEffect
1. useEffect 的 create 会在 commit 阶段完成以后异步执行; useLayoutEffect 的 create 在 commit 阶段的最后一个步骤 layout 阶段同步执行。
2. 所以，useLayoutEffect 的 DOM 更改会阻塞视觉更新，尽量要使用 useEffect 来避免这种情况。
3. 并非所有的副作用都可以被延迟执行，例如，一个对用户可见的 DOM 操作就必须同步执行，这时候就应该用 useLayoutEffect。

# fcomponentDidMount
**讲概念**
1. componentDidMount 是一个类组件的生命周期。
2. componentDidMount 会在 mutation 阶段完成视图更新后，在layout阶段同步执行，也就是在组件插入 DOM 树后立即调用。
3. 它和 useLayoutEffect 的 create 调用时机一致。
**说用途**
1. 依赖于 DOM 节点的初始化应该放在这里。如需通过网络请求获取数据，此处是实例化请求的好地方。
2. 这个方法是比较适合添加订阅的地方。如果添加了订阅，请不要忘记在 componentWillUnmount() 里取消订阅。

# fuseReducer
**讲概念**
React.useReducer 类似于 React.useState, 都是管理函数组件状态的 API, 不过 useReducer 把 reducer 函数交给用户自己实现。
**说用法**
1. React.useReducer 接收三个参数，返回一个数组, 
* 三个参数分别是:
  1. reducer       一个调度函数，传入当前状态state和改变状态的方法action, 返回全新的状态。
  2. initFuncArg   传递给第三个参数init函数的值，一般是state的初始值
  3. initFunc      初始值生成函数，接收第二个参数 initialArg, 返回值作为 state 的初始值。
* 返回值是一个数组，包含两项:
  1. state        当前的状态
  2. dispatch     一个函数，代表改变状态的方法，接收 action，从 reducer 里得到相应的状态。
**注意**
1. 如果 Reducer Hook 的返回值与当前 state 相同，React 将跳过子组件的渲染及副作用的执行，React 内部通过 Object.is 这个 API 来决定前后 state 是否相同。
**函数签名**
```jsx
const [state, dispatch] = useReducer(reducer, initialArg, init);
```
**举例子**
```jsx
function init(initialCount) {
  return {count: initialCount};
}
function reducer(state, action) {
  switch (action.type) {
    case 'increment':
      return {count: state.count + 1};
    case 'decrement':
      return {count: state.count - 1};
    case 'reset':
      return init(action.payload);
    default:
      throw new Error();
  }
}
function Counter({initialCount}) {
  const [state, dispatch] = useReducer(reducer, initialCount, init);
  return (
    <>
      Count: {state.count}
      <button
        onClick={() => dispatch({type: 'reset', payload: initialCount})}>
        Reset
      </button>
      <button onClick={() => dispatch({type: 'decrement'})}>-</button>
      <button onClick={() => dispatch({type: 'increment'})}>+</button>
    </>
  );
}
```


# fuseCallback
**讲概念**
1. React.useCallback 是一个`原生hook`, 用来缓存一个函数，当依赖项不变时，组件重新渲染始终获取到缓存的函数。
**说用途**
1. 它的作用主要是保持函数的引用不变，这样可以避免一些不必要的`重新渲染`。
2. 比如子组件比较两个引用是否相等，如果父组件用了 useCallback 命中了缓存，那么更新前后传递给子组件的就是同一个引用，子组件就可以不必渲染，提高性能。
**说用法**
1. React.useCallback 接收两个参数，第一个是`可能被缓存的函数`，第二个是`依赖数组`，返回一个`缓存函数`。
2. 这个`缓存函数`仅在`依赖数组`的某一项改变时才会更新。
**函数签名**
```jsx
const memoizedCallback = useCallback(() => { doSomething(a, b) }, [a, b]);
```


# fuseImperativeHandle
**讲概念**
1. 一般情况下，我们不可以直接引用一个函数组件。但是 useImperativeHandle 可以让你使用 ref 调用一些子组件暴露的方法。
2. React.useImperativeHandle 应当与 React.forwardRef 一起使用。
**说用法**
1. useImperativeHandle 接收 3 个参数，1个是ref, 1个是回调函数, 1个是依赖数组。
2. 回调函数返回一个对象，这个对象将暴露给 React.forwardRef 的上层调用者，上层通过 ref.current 来获取这个对象。
**函数签名**
```jsx
function useImperativeHandle(ref, createHandle, [deps]): void;
```
**举例子**
1. 父组件调用子组件暴露的方法`doit`。
```jsx
// 子组件
function Son(props, ref) {
  useImperativeHandle(ref, () => {
    const exportObject = {
      doit: () => console.log('执行doit...');
    }
    return exportObject;
  }, []);
  return <h1>子组件</h1>;
}
const Middle = forwardRef(Son);
// 父组件
function Parent() {
  const ref = useRef();
  useEffect(() => {
    // ref.current 代表 Son 暴露的对象, doit 是对象的方法。
    const son = ref.current;
    son.doit();
  },[]);
  return <Middle ref={ref}>;
}
```


# fuseDebugValue
**讲概念**
1. React.useDebugValue 可用于在 React 开发者工具中显示自定义 hook 的标签。
**说用途**
1. React.useDebugValue 可用于在 React 开发者工具中显示自定义 hook 的标签。
2. 在某些情况下，格式化值的显示可能是一项开销很大的操作。除非需要检查 Hook，否则没有必要这么做。
3. 因此，useDebugValue 接受一个格式化函数作为可选的第二个参数。
4. 该函数只有在 Hook 被检查时才会被调用。它接受 debug 值作为参数，并且会返回一个格式化的显示值。
**函数签名**
```jsx
useDebugValue(date, formatFn): void;
```
**举例子1 常规用法**
```jsx
function useFriendStatus(friendID) {
  const [isOnline, setIsOnline] = useState(null);
  // 在开发者工具中的这个 Hook 旁边显示标签
  // e.g. "FriendStatus: Online"
  useDebugValue(isOnline ? 'Online' : 'Offline');
  return isOnline;
}
```
**举例子2 延迟格式化Debug值**
```jsx
function useDate(id) {
  const [date, setDate] = useState('');
  useDebugValue(date, date => date.toDateString());
  return date;
}
```


# fuseDeferredValue
**讲概念**
1. React.useDeferredValue 接受一个值，并返回该值的副本。
2. 当原始值更新后，useDeferredValue 往往不会立即拷贝新值，而是在`紧急的更新`更新以后，再同步到最新的值。
**说用途**
1. 比如拷贝的是一个紧急更新的结果(如用户输入)，React 将返回之前的值，然后在用户输入渲染以后，再拷贝出最新的值。
2. 该 hook 与使用防抖和节流去延迟更新的用户空间 hooks 类似。
3. 使用 useDeferredValue 的好处是，React 将在其他工作完成后立即进行更新，而不是等待任意时间。
4. 通常配合 React.memo 或 React.useMemo 记忆该子组件来使用。
**举例子 延迟渲染长列表**
```jsx
function DeferSuggestions() {
  const query = useSearchQuery('');
  const deferredQuery = useDeferredValue(query);
  // 当 deferredQuery 改变而不是 query 改变的时候，才渲染 SearchSuggestions 这个长列表。
  const suggestions = useMemo(() => <SearchSuggestions query={deferredQuery} />, [deferredQuery]);
  return (
    <>
      <SearchInput query={query} />
      <Suspense fallback="Loading results...">
        {suggestions}
      </Suspense>
    </>
  );
}
```


# fuseId
**讲概念**
1. React.useId 是一个用于生成横跨服务端和客户端的稳定的 唯一ID 的 hook，它可以避免 hydration 不匹配
**举例子1**
```jsx
// 直接传递 id 给需要它的元素
function Checkbox() {
  const id = useId();
  return (
    <>
      <label htmlFor={id}>Do you like React?</label>
      <input id={id} type="checkbox" name="react"/>
    </>
  );
};
```
**举例子2**
```jsx
// 对于同一组件中的多个 ID，使用相同的 id 并添加后缀
function NameFields() {
  const id = useId();
  return (
    <div>
      <label htmlFor={id + '-firstName'}>First Name</label>
      <div>
        <input id={id + '-firstName'} type="text" />
      </div>
      <label htmlFor={id + '-lastName'}>Last Name</label>
      <div>
        <input id={id + '-lastName'} type="text" />
      </div>
    </div>
  );
}
```


# fcreateElement
**讲概念**
1. React.createElement 创建并返回指定类型的新 React 元素。
2. 其中的类型参数既可以是标签名字符串（如 'div' 或 'span'），也可以是 React 组件 类型 (类组件或函数组件)，或是 React.Fragment 类型。
**函数签名**
```js
function createElement(type, [props], [...children]): ReactElement;
```
**说用途**
1. 使用 JSX 编写的代码将会被转换成使用 React.createElement() 的形式。
2. 如果使用了 JSX 方式，那么一般来说就不需要直接调用 React.createElement()。
**举例子1**
```jsx
<div title="DEMO">Hello {this.props.world}</div>;
// 编译为
React.createElement('div', { title: "DEMO" }, `Hello ${ this.props.world}`);
```
**举例子2 编译子结点数组**
```jsx
<MyUl title="demo">
  <MyLi>1</MyLi>
  <MyLi>2</MyLi>
  <MyLi>3</MyLi>
</MyUl>
// 编译为
React.createElement(MyUl, { title: "demo"}, 
  React.createElement(MyLi, null, "1"), 
  React.createElement(MyLi, null, "2"), 
  React.createElement(MyLi, null, "3")
);
```


# fcreateFactory 
**讲概念**
1. 返回用于生成指定类型 React 元素的函数，如 'div', 'span', React组件等。
[废弃]
此辅助函数已废弃，用 React.createElement 代替它。


# fcloneElement
**讲概念**
1. 以 element 元素为样板克隆并返回新的 React 元素。
2. config 中应包含新的 props，key 或 ref。返回元素的 props 是将新的 props 与原始元素的 props 浅层合并后的结果。
3. 新的子元素将取代现有的子元素，如果在 config 中未出现 key 或 ref，那么原始元素的 key 和 ref 将被保留。
**函数签名**
```jsx
function cloneElement(element, config, ...children): ReactElement;
```
**优缺点**
1. cloneElement 也保留了组件的 ref。这意味着当通过 ref 获取子节点时，不会从祖先节点上窃取它。
2. 相同的 ref 将添加到克隆后的新元素中。如果存在新的 ref 或 key 将覆盖之前的。
3. 引入此 API 是为了替换已弃用的 React.addons.cloneWithProps()。


# fisValidElement
**讲概念**
1. React.isValidElement 用于检查一个对象是否是 React元素。
2. 传入一个对象，验证对象是否为 React 元素，返回值为 true 或 false。
**函数签名**
```js
React.isValidElement(object): void;
```


# fChildren
**讲概念**
1. React.Children 提供了用于处理 this.props.children 的实用方法, 类似于数组的方法。
**React.Children.map**
1. 在 children 里的每个直接子节点上调用一个函数，并将 this 设置为 thisArg，返回一个数组。
2. 如果 children 是一个数组，它将被遍历并为数组中的每个子节点调用该函数。
3. 如果子节点为 null 或是 undefined，则此方法将返回 null 或是 undefined，而不会返回数组。
```js
React.Children.map(children, function[(thisArg)])
```
**React.Children.forEach**
1. 与 React.Children.map() 类似，但它只会遍历，不会返回一个数组。
```js
React.Children.forEach(children, function[(thisArg)])
```
**React.Children.count**
1. 返回 children 中的组件总数量，等同于通过 map 或 forEach 调用回调函数的次数。
```js
React.Children.count(children)
```
**React.Children.only**
1. children 可能是个数组，这个 API 能验证 children 是否只有一个子节点（一个 React 元素），如果有则返回它，否则此方法会抛出错误。
```js
React.Children.only(children)
```
**React.Children.toArray**
1. 将 children 这个复杂的数据结构以数组的方式扁平展开并返回，并为每个子节点分配一个 key。
2. 当你想要在渲染函数中操作子节点的集合时，它会非常实用，特别是当你想要在向下传递 this.props.children 之前对内容重新排序或获取子集时。
```js
React.Children.toArray(children)
```


# fFragment
**讲概念**
1. 函数组件(或类组件render方法)不能直接返回多个元素，必须由一个元素包裹着这多个元素。
2. React.Fragment 组件能够在不额外创建 DOM 元素的情况下，让函数组件(或类组件render方法)返回多个元素。
**注意点**
1. 我们也可以使用其简写语法 <></>。
2. 使用 React.Fragement 语法声明的片段可能具有 key, key 是唯一可以传递给 Fragment 的属性。
**举例子1**
```jsx
class Columns extends React.Component {
  render() {
    return (
      <React.Fragment>
        <td>Hello</td>
        <td>World</td>
      </React.Fragment>
    );
  }
}
// 正确渲染 table
class Table extends React.Component {
  render() {
    return (
      <table>
        <tr>
          <Columns />
        </tr>
      </table>
    );
  }
}
```
**举例子2**
```jsx
function Glossary(props) {
  return (
    <dl>
      {props.items.map(item => (
        // 如果没有`key`，React 会发出一个警告。
        <React.Fragment key={item.id}>
          <dt>{item.term}</dt>
          <dd>{item.description}</dd>
        </React.Fragment>
      ))}
    </dl>
  );
}
```


# fuseSyncExternalStore
**讲概念**
1. React.useSyncExternalStore 是为库作者提供的，用于将库深入集成到 React 模型中，通常不会在应用程序代码中使用。
2. useSyncExternalStore 是一个推荐用于读取和订阅外部数据源的 hook，其方式与选择性的 hydration 和时间切片等并发渲染功能兼容。
**说用法**
此方法返回存储的值并接受三个参数：
* subscribe：用于注册一个回调函数，当存储值发生更改时被调用。
* getSnapshot： 返回当前存储值的函数。
* getServerSnapshot：返回服务端渲染期间使用的存储值的函数
**函数签名**
```jsx
const state = useSyncExternalStore(subscribe, getSnapshot[, getServerSnapshot]);
```


# fuseInsertionEffect
**讲概念**
1. React.useInsertionEffect 是为库作者提供的，用于将库深入集成到 React 模型中，通常不会在应用程序代码中使用。
2. useInsertionEffect 在所有 DOM 突变之前同步触发。也就是在 commit 阶段的 beforeMutation 阶段触发。
3. 使用它在读取 useLayoutEffect 中的布局之前将样式注入 DOM。
4. 由于这个 hook 的作用域有限，所以这个 hook 不能访问 refs，也不能安排更新。
**注意点**
1. useInsertionEffect 应仅限于 css-in-js 库作者使用。优先考虑使用 useEffect 或 useLayoutEffect 来替代。
**用法**
```jsx
useInsertionEffect(didUpdate);
```


