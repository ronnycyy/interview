# fwebpack生命周期 f工作流程 f构建流程
1. 初始化参数
从配置文件和 shell 语句中读取与合并参数，得出最终的参数。
2. 开始编译
用上一步得到的参数初始化 Compiler 对象，加载所有配置的插件，执行对象的 run 方法开始编译。
3. 寻找入口
根据 entry 找到所有 入口文件。
4. 编译模块
从每个入口文件出发，调用所有配置的 loader 对模块进行翻译，再找出该模块依赖的模块，再递归本步骤直到所有入口依赖的文件都经过了本步骤的处理。
5. 输出资源
根据入口和模块之间的依赖关系，组装成一个个包含多个模块的 chunk，再把每个 chunk 转换成一个单独的文件加入到输出列表，这步是可以修改输出内容的最后机会。
6. 写入磁盘
在确定好输出内容后，根据配置确定输出的路径和文件名，把文件内容写入到文件系统。
在以上过程中，webapck 会在特定的时间点广播出特定的事件，插件在监听到感兴趣的事件后会执行特定的逻辑，从而可以改变 webpack 的运行结果。

# fchunk
1. chunk 是 webpack 打包过程中，一系列关联 module 的集合。比如有 3 种方式可以产生 chunk:
*入口 chunk*
webpack 从入口模块开始打包，入口模块引用其他模块，模块再引用模块，从入口开始的一系列模块，就形成了一个 chunk，多个入口就有多个 chunk。
*按需加载*
按需加载的模块，比如 import(..), 也会产生 chunk。
*代码分割*
在 webpack 中配置代码分割，会产生 chunk。
2. chunk 在构建完成时，就呈现为 bundle，一般来说，一个 chunk 对应一个 bundle。但是也有例外，比如 devtool 设置为 source-map 时，一个 chunk 会打包出 2 个 bundle，一个是 main.js，一个是 main.js.map, chunk 是过程中的代码块，bundle 是结果的代码块。
## f入口chunk
下面的例子会生成 2 个 chunk, 使用 entry 的 key 命名，所以一个叫 pageA, 一个叫 pageB。
```js
module.exports = {
  entry: {
    pageA: ...,
    pageB: ...,
  },
  output: {
    filename: '[name].bundle.js'
  }
}
```
## f按需加载
在代码中使用 import(...)按需加载代码，在 webpack 配置中使用 output.chunkFilename 为异步加载的 chunk 命名。
```js
module.exports = {
  entry: ...,
  output: {
    ...,
    chunkFilename: '[name].async.bundle.js'
  }
}
```
## f代码分割 fwebpack代码分割
配置 splitChunks 可以将 entry, 异步 chunk 等 chunk 进一步分割，产生更多 chunk。
```js
module.exports = {
  optimization: {
    splitChunks: {
      ....
    }
  }
}
```

# fTreeShaking f摇树优化
Tree-Shaking 是一种基于 ES Module 规范的 无用代码清除(Dead Code Elimination) 技术，它会在运行过程中静态分析模块之间的导入导出，确定 ESM 模块中哪些导出值未曾其它模块使用，并将其删除，以此实现打包产物的优化。
## f开启TreeShaking  f在 webpack 中开启 TreeShaking
1. 使用 ESM 规范编写模块代码。
2. 配置 optimization.usedExports 为 true，启动标记功能。
3. 启动代码优化功能，可以通过如下方式的任意一种实现:
  - 配置 mode = production
  - 配置 optimization.minimize = true
  - 提供 optimization.minimizer 数组
例如, 在 webpack.config.js 中:
```js
module.exports = {
  entry: "./src/index",
  mode: "production",
  devtool: false,
  optimization: {
    usedExports: true,
  },
};
```
## fES6模块特点 fESM规范
1. 只能作为模块顶层的语句出现。
2. 导入导出的模块名只能是字符串常量。
3. 导入的值是不可变的。
以上三点，决定了 ESM 是完全静态的，跟运行时无关，所以可以在编译时，从代码字面量中就推断出哪些模块值未被使用，这是实现 Tree Shaking 技术的必要条件。
```js
// index.js 主模块
import {bar} from './bar';
console.log(bar);  // 仅使用了 bar, 没有使用 foo
// bar.js 模块
export const bar = 'bar';
export const foo = 'foo';   // foo 未被使用, 会被视作无用代码而删除。
```
## f原理 fTreeShaking原理
Webpack 中，Tree-shaking 分为两步:
1. 第一步、先标记出模块导出值中哪些没有被用过。
2. 第二步、使用 Terser或UglifyJS 等 DCE工具 删掉这些没被用到的导出语句。
标记过程大致可划分为三个步骤:
  - Make 阶段，收集模块导出变量并记录到模块依赖关系图 ModuleGraph 变量中。
  - Seal 阶段，遍历 ModuleGraph 标记模块导出变量有没有被使用。
  - 生成产物时，若变量没有被其它模块使用则删除对应的导出语句。

🌰例子
```js
{
  // bar 模块
  "./src/bar.js":  ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
    __webpack_require__.d(__webpack_exports__, {
      "bar": () => (/* binding */ bar)
      // 这里就没有导出 foo，因为根本没用到。
      // 后面 Terser 插件的 DCE 功能，会把 const foo = 'foo' 摇掉。
    });
    /* unused harmony export foo */
    const bar = 'bar';
    const foo = 'foo';
  })
}
```

# f缓存 fwebpack缓存
1. cache-loader
2. hard-source-webpack-plugin
3. babel-loader
## hard-source-webpack-plugin
模块解析的阶段，用于中间的缓存。
第一次是正常的构建速度，但是会保存缓存数据到 xxx 里。
第二次使用缓存来构建，速度提升。
## babel-loader
运行以后，会增加 node_modules/.cache/babel-loader 这个文件夹，存放缓存的文件
```js
{
  loader: 'babel-loader',
  options: {
    cacheDirectory: true // 开启缓存
  }
}
```

# f热更新🔥 fdevServer
安装 webpack-dev-server, 然后在开发环境下配置:
```js
devServer: {
  contentBase: join(__dirname, '../dist'),
  hot: true,
  port: 3000
}
```
TODO: 原理

## f系统级通知
按下 Ctrl+S, 无需查看 terminal, 系统会通知你成功/失败。只需安装 webpack-build-notifier, 配置插件:
```js
plugins: [
  new WebpackBuildNotifierPlugin({
    title: "My Webpack Project",
    logo: path.resolve("./img/favicon.png"),
    suppressSuccess: true,
  })
]
```